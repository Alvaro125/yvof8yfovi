module.exports = {
    apps: [
      {
        name: "nuxt-app",
        exec_mode: "cluster",
        instances: "1",
        script: ".output/server/index.mjs",
        args: "start"
      }
    ]
  };
  