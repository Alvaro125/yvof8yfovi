export default defineEventHandler(async (event) => {
    const { apiSecret } = await useRuntimeConfig(event);
    const query = await getQuery(event);
    const limit = query.limit || 1;
    const result = await $fetch(
      apiSecret + "/api/v0/inlet/flows?limit=" + limit,
      {
        method: "GET",
      }
    );
    return result;
  });
  