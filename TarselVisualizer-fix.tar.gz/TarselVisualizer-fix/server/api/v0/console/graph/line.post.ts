export default defineEventHandler(async (event) => {
  const {token,id_client }= getQuery(event)
  const { goIServer } = useRuntimeConfig(event);
  const body = await readBody(event);
  const result = await $fetch(goIServer + "/consult/graph", {
    query: {
      token: `${token}`,
      id_client: id_client,
    },
    method: "POST",
    body,
  });
  return result;
});
