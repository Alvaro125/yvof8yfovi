// export default defineEventHandler(async (event) => {
//   const { apiSecret } = useRuntimeConfig(event)
//   const body = await readBody(event)
//   const result = await $fetch(apiSecret+'/api/v0/console/graph/sankey', {
//     method: 'POST',
//     body
//   })
//   return result
// })
export default defineEventHandler(async (event) => {
  const { token, id_client } = getQuery(event);
  const { goIServer } = useRuntimeConfig(event);
  const body = await readBody(event);
  const result = await $fetch(goIServer + "/consult/sankey", {
    query: {
      token: `${token}`,
      id_client: id_client,
    },
    method: "POST",
    body,
  });
  return result;
});
