// types.ts
interface ValidationError {
  message: string;
  line: number;
  column: number;
  offset: number;
}

interface ValidationResult {
  message: string;
  errors?: ValidationError[];
}

interface RequestBody {
  filter?: string;
}

// validators.ts
const ALLOWED_ATTRIBUTES = new Set([
  'Dst1stAS',
  'Dst2ndAS',
  'Dst3rdAS',
  'DstAS',
  'DstASPath',
  'DstAddr',
  'DstCountry',
  'DstGeoCity',
  'DstGeoState',
  'DstNetMask',
  'DstNetName',
  'DstNetPrefix',
  'DstNetRegion',
  'DstNetRole',
  'DstNetSite',
  'DstNetTenant',
  'DstPort',
  'EType',
  'ExporterAddress',
  'ExporterGroup',
  'ExporterName',
  'ExporterRegion',
  'ExporterRole',
  'ExporterSite',
  'ExporterTenant',
  'ForwardingStatus',
  'InIfBoundary',
  'InIfConnectivity',
  'InIfDescription',
  'InIfName',
  'InIfProvider',
  'InIfSpeed',
  'OutIfBoundary',
  'OutIfConnectivity',
  'OutIfDescription',
  'OutIfName',
  'OutIfProvider',
  'OutIfSpeed',
  'PacketSize',
  'Proto',
  'SrcAS',
  'SrcAddr',
  'SrcCountry',
  'SrcGeoCity',
  'SrcGeoState',
  'SrcNetMask',
  'SrcNetName',
  'SrcNetPrefix',
  'SrcNetRegion',
  'SrcNetRole',
  'SrcNetSite',
  'SrcNetTenant',
  'SrcPort',
]);

const patterns = {
  attribute: /^[A-Za-z0-9]+$/,
  operator: /^(=|!=|>|<|>=|<=|LIKE|UNLIKE|IN)$/i,
  value: /^[\w:./'%,\s\d-]+$/,
  singleValue: /^[\w:./'%\d-]+$/,
  conditional: /^(AND|OR|NOT)$/i,
};

function findClosingParenthesis(expr: string, startPos: number): number {
  let count = 1;
  for (let i = startPos; i < expr.length; i++) {
    if (expr[i] === '(') count++;
    if (expr[i] === ')') count--;
    if (count === 0) return i;
  }
  return -1;
}

const validateValue = (
  attr: string,
  value: string,
  operator: string,
  condition: string,
  lineNum: number,
  colOffset: number,
  startOffset: number,
  errors: ValidationError[]
): void => {
  // Remove outer quotes if present
  const strippedValue = value.replace(/^'|'$/g, '');

  if (operator.toUpperCase() === 'IN') {
    value = `(${value})`
    // For IN operator, validate the list format and each value
    if (!/^\(.*\)$/.test(value.trim())) {
      errors.push({
        message: `invalid IN list format: ${value}, expected: (value1,value2,...)`,
        line: lineNum + 1,
        column: condition.indexOf(value) + colOffset + 1,
        offset: startOffset + condition.indexOf(value) + colOffset,
      });
      return;
    }

    // Remove parentheses and split by comma
    const values = value
      .slice(1, -1)
      .split(',')
      .map(v => v.trim());

    for (const val of values) {
      // Check if the value is a number or matches the single value pattern
      if (
        !/^\d+$/.test(val) &&
        !patterns.singleValue.test(val.replace(/^'|'$/g, ''))
      ) {
        errors.push({
          message: `invalid value in IN list: ${val}`,
          line: lineNum + 1,
          column: condition.indexOf(value) + colOffset + 1,
          offset: startOffset + condition.indexOf(value) + colOffset,
        });
      }
    }
  } else {
    // For other operators, validate as single value
    const strippedValue = value;
    console.log(condition)
    // Allow both numeric values and pattern-matched values
    if (
      ["SrcAS", "DstAS", "Dst1stAS", "Dst2ndAS", "Dst3rdAS",'DstNetMask','DstPort', 'SrcPort'].includes(attr) &&
      ['=', '!=', '>', '<', '<=', ">="].includes(operator) &&
      !/^\d+$/.test(strippedValue)
    ) {
      errors.push({
        message: `invalid value number: ${value}`,
        line: lineNum + 1,
        column: condition.indexOf(value) + colOffset + 1,
        offset: startOffset + condition.indexOf(value) + colOffset,
      });
    }
    if (
      ["SrcAS", "DstAS", "Dst1stAS", "Dst2ndAS", "Dst3rdAS"].includes(attr) &&
      ['LIKE', 'UNLIKE'].includes(operator) &&
      !/'([^']*)'/.test(strippedValue)
    ) {
      errors.push({
        message: `invalid value string: ${value}`,
        line: lineNum + 1,
        column: condition.indexOf(value) + colOffset + 1,
        offset: startOffset + condition.indexOf(value) + colOffset,
      });
    }
    if (
      !/^\d+$/.test(strippedValue) &&
      !patterns.singleValue.test(strippedValue)
    ) {
      errors.push({
        message: `invalid value: ${value}`,
        line: lineNum + 1,
        column: condition.indexOf(value) + colOffset + 1,
        offset: startOffset + condition.indexOf(value) + colOffset,
      });
    }
  }
};

const validateSingleCondition = (
  condition: string,
  lineNum: number,
  colOffset: number,
  startOffset: number,
  errors: ValidationError[]
): void => {
  const tokens = condition
    .trim()
    .split(/\s+/)
    .filter(t => t !== '' && t !== '(' && t !== ')');

  if (tokens.length < 3) {
    errors.push({
      message: "invalid condition format: must be 'attribute operator value'",
      line: lineNum + 1,
      column: colOffset + 1,
      offset: startOffset + colOffset,
    });
    return;
  }

  const [attr, op, ...valueParts] = tokens;
  const value = valueParts.join(' '); // Rejoin value parts to handle IN lists

  // Validate attribute
  if (!patterns.attribute.test(attr)) {
    errors.push({
      message: `invalid attribute name: ${attr}, expected: [A-Za-z0-9]`,
      line: lineNum + 1,
      column: condition.indexOf(attr) + colOffset + 1,
      offset: startOffset + condition.indexOf(attr) + colOffset,
    });
  }
  if (!ALLOWED_ATTRIBUTES.has(attr)) {
    errors.push({
      message: `invalid attribute: ${attr}`,
      line: lineNum + 1,
      column: condition.indexOf(attr) + colOffset + 1,
      offset: startOffset + condition.indexOf(attr) + colOffset,
    });
  }

  // Validate operator
  if (!patterns.operator.test(op)) {
    errors.push({
      message: `invalid operator: ${op}, expected: =, !=, >, <, >=, <=, LIKE, UNLIKE, or IN`,
      line: lineNum + 1,
      column: condition.indexOf(op) + colOffset + 1,
      offset: startOffset + condition.indexOf(op) + colOffset,
    });
  }

  // Validate value
  validateValue(attr, value, op, condition, lineNum, colOffset, startOffset, errors);
};

const validateExpression = (expression: string): ValidationResult => {
  if (!expression?.trim()) {
    return { message: 'ok' };
  }

  const errors: ValidationError[] = [];
  const lines = expression.split('\n');
  let totalOffset = 0;

  for (let lineNum = 0; lineNum < lines.length; lineNum++) {
    const line = lines[lineNum].trim();
    if (!line) {
      totalOffset += 1;
      continue;
    }

    let pos = 0;
    let lastConditional: string | null = null;
    let parensStack = 0;

    while (pos < line.length) {
      const char = line[pos];

      // Handle opening parenthesis
      if (char === '(') {
        parensStack++;
        pos++;
        continue;
      }

      // Handle closing parenthesis
      if (char === ')') {
        parensStack--;
        if (parensStack < 0) {
          errors.push({
            message: 'unexpected closing parenthesis',
            line: lineNum + 1,
            column: pos + 1,
            offset: totalOffset + pos,
          });
        }
        pos++;
        continue;
      }

      // Skip whitespace
      if (/\s/.test(char)) {
        pos++;
        continue;
      }

      // Handle conditionals
      if (pos < line.length - 2) {
        const nextThree = line.substring(pos, pos + 3).toUpperCase();
        if (nextThree === 'AND' || nextThree.substring(0, 2) === 'OR') {
          const conditional = nextThree.substring(
            0,
            nextThree === 'AND' ? 3 : 2
          );
          if (lastConditional !== null) {
            errors.push({
              message: 'consecutive conditionals are not allowed',
              line: lineNum + 1,
              column: pos + 1,
              offset: totalOffset + pos,
            });
          }
          lastConditional = conditional;
          pos += conditional.length;
          continue;
        }
      }

      // Handle condition
      if (/[A-Za-z]/.test(char)) {
        let endPos = pos;
        while (
          endPos < line.length &&
          line[endPos] !== ')' &&
          !/\b(AND|OR)\b/i.test(line.substring(endPos, endPos + 3))
        ) {
          endPos++;
        }
        let condition = line.substring(pos, endPos).trim();
        if (condition.includes('(')) {
          condition = condition.replaceAll('(', '');
          parensStack++;
        }
        validateSingleCondition(condition, lineNum, pos, totalOffset, errors);
        lastConditional = null;
        pos = endPos;
      } else {
        pos++;
      }
    }

    if (parensStack > 0) {
      errors.push({
        message: 'unclosed parenthesis',
        line: lineNum + 1,
        column: line.length,
        offset: totalOffset + line.length - 1,
      });
    }

    totalOffset += line.length + 1;
  }

  if (errors.length > 0) {
    return {
      message: `at line ${errors[0].line}, position ${errors[0].column}: ${errors[0].message}`,
      errors,
    };
  }

  return { message: 'ok' };
};
// route.ts
export default defineEventHandler(async (event) => {
  try {
    const body = await readBody<RequestBody>(event);
    const filter = body.filter ?? "";
    
    const validationResult = validateExpression(filter);
    
    if (validationResult.errors) {
      return {
        statusCode: 400,
        ...validationResult
      };
    }

    return {
      statusCode: 200,
      message: "ok",
      parsed: filter
    };
  } catch (error) {
    return {
      statusCode: 500,
      message: "internal server error",
      errors: [{
        message: error instanceof Error ? error.message : "unknown error",
        line: 1,
        column: 1,
        offset: 0
      }]
    };
  }
});