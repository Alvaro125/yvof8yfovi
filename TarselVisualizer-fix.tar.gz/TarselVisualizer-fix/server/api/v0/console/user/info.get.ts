export default defineEventHandler(async (event) => {
  const { apiSecret } = useRuntimeConfig(event);
  const result = await $fetch(apiSecret + "/api/v0/console/user/info", {
    method: "GET",
  });
  return result;
});
