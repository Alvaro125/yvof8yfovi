export default defineEventHandler(async (event) => {
    const { apiSecret } = await useRuntimeConfig(event);
    const result = await $fetch(apiSecret + "/api/v0/console/user/avatar", {
      method: "GET",
    });
    return result;
  });
  