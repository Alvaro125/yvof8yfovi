export default defineEventHandler(async (event) => {
  const { apiSecret } = await useRuntimeConfig(event);
  const query = await getQuery(event);
  const result = await $fetch(
    apiSecret +
      "/api/v0/console/widget/top/src-country?" +
      Object.keys(query)[0],
    {
      method: "GET",
    }
  );
  return result;
});
