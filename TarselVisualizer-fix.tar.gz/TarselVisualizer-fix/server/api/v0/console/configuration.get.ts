export default defineEventHandler(async (event) => {
  const { apiSecret } = useRuntimeConfig(event);
  const result = await $fetch(apiSecret + "/api/v0/console/configuration", {
    method: "GET",
  });
  result.defaultVisualizeOptions.filter="";
  return result;
});
