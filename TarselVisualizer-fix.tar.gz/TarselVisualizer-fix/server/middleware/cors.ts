export default defineEventHandler((event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*', // Permite todas as origens
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS', // Permite métodos HTTP específicos
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With', // Permite cabeçalhos específicos
        'crossOriginResourcePolicy': 'cross-origin', // Permite requisições de diferentes origens
        'crossOriginOpenerPolicy': 'same-origin',
        'crossOriginEmbedderPolicy': 'require-corp',
        'contentSecurityPolicy': "default-src 'self';base-uri 'self';font-src 'self' https: data:;form-action 'self';frame-ancestors 'self';img-src 'self' data:;object-src 'none';script-src 'self';script-src-attr 'none';style-src 'self' https: 'unsafe-inline';upgrade-insecure-requests",
        'X-XSS-Protection': '1; mode=block'
    };

    setHeaders(event, headers);
});