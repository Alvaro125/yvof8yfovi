import type {
  GraphLineHandlerInput,
  GraphLineHandlerOutput,
  GraphSankeyHandlerInput,
  GraphSankeyHandlerOutput,
} from "@/views/VisualizePage";
import type { ModelType } from "@/views/VisualizePage/OptionsPanel.vue";
import { useFetch, type AfterFetchContext } from "@vueuse/core";
import { omit } from "lodash-es";
import { defineStore } from "pinia";
import { computed, ref, type Ref } from "vue";

export const useFlowStore = defineStore("flow", {
  state: () => ({
    srcAs: null as any,
    data: null as any,
    currentState: null as ModelType | null,
  }),
  actions: {
    async updateState(newState: ModelType) {
      this.currentState = newState;
    },
    async update(data: number) {
      const now = new Date();
      const interval = Number(now.getTime()) - data;
      const before = new Date(interval);
      const state = ref<ModelType>({
        bidirectional: this.currentState.bidirectional ? this.currentState.bidirectional : false,
        dimensions: this.currentState.dimensions ? this.currentState.dimensions : ["Proto"],
        filter: this.currentState.filter ? this.currentState.filter : "InIfBoundary = external",
        limit: this.currentState.limit ? this.currentState.limit : 20,
        points: this.currentState.points ? this.currentState.points : 200,
        "previous-period": false,
        start: before.toISOString(),
        end: now.toISOString(),
        "truncate-v4": this.currentState["truncate-v4"] ? this.currentState["truncate-v4"] : 32,
        "truncate-v6": this.currentState["truncate-v6"] ? this.currentState["truncate-v6"] : 128,
        units: this.currentState.units ? this.currentState.units : "l3bps",
      });
      const request = ref<ModelType>(null);

      const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
        return Object.keys(input)
          .sort()
          .reduce(
            (o, k) => ((o[k] = input[k]), o),
            {} as { [key: string]: any },
          ) as T;
      };

      const jsonPayload = computed(
        (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
          if (state.value === null) return null;
          if (state.value.graphType === "sankey") {
            const input: GraphSankeyHandlerInput = {
              ...omit(state.value, [
                "graphType",
                "bidirectional",
                "previousPeriod",
                "humanStart",
                "humanEnd",
              ]),
            };
            return orderedJSONPayload(input);
          } else {
            const input: GraphLineHandlerInput = {
              ...omit(state.value, [
                "graphType",
                "previousPeriod",
                "humanStart",
                "humanEnd",
              ]),
              points: state.value.graphType === "grid" ? 50 : 200,
              "previous-period": state.value.previousPeriod,
            };
            return orderedJSONPayload(input);
          }
        },
      );

      const { data: fetchedData, execute: exec } = useFetch("", {
        beforeFetch(ctx) {
          const token = useCookie('token')
          const id_client = useCookie('id_client')
          const { cancel } = ctx;
          if (state.value === null) {
            cancel();
            return ctx;
          }
          const url = "line";
          return {
            ...ctx,
            url: `/api/v0/console/graph/${url}?token=${token.value}&id_client=${id_client.value}`,
          };
        },
        async afterFetch(ctx: AfterFetchContext<GraphLineHandlerOutput | GraphSankeyHandlerOutput>) {
          const { data, response } = ctx;
          if (!data || !data.rows) {
            console.error("Unexpected data format", data);
            return ctx;
          }
          request.value = state.value;
        
          return ctx;
        },
        immediate: false,
      })
        .post(jsonPayload, "json")
        .json<
          GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
        >();

      exec().then(async () => {
        this.srcAs = await (fetchedData.value as any).rows;
        this.data = await (fetchedData.value as any);
      });
    },
  },
});

export const flowStore = () => {
  const store = useFlowStore();
  const now = new Date();
  const oneHourBefore = new Date(now);
  oneHourBefore.setHours(now.getHours() - 1);
  const state = ref<ModelType>({
    bidirectional: false,
    dimensions: store.currentState.dimensions ? store.currentState.dimensions : ["Proto"],
    filter: store.currentState.filter ? store.currentState.filter : "InIfBoundary = external",
    limit: store.currentState.limit ? store.currentState.limit : 20,
    points: store.currentState.points ? store.currentState.points : 200,
    "previous-period": false,
    start: oneHourBefore.toISOString(),
    end: now.toISOString(),
    "truncate-v4": store.currentState["truncate-v4"] ? store.currentState["truncate-v4"] : 32,
    "truncate-v6": store.currentState["truncate-v6"] ? store.currentState["truncate-v6"] : 128,
    units: store.currentState.units ? store.currentState.units : "l3bps",
  });
  const request = ref<ModelType>(null);

  const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
    return Object.keys(input)
      .sort()
      .reduce(
        (o, k) => ((o[k] = input[k]), o),
        {} as { [key: string]: any },
      ) as T;
  };

  const jsonPayload = computed(
    (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
      if (state.value === null) return null;
      if (state.value.graphType === "sankey") {
        const input: GraphSankeyHandlerInput = {
          ...omit(state.value, [
            "graphType",
            "bidirectional",
            "previousPeriod",
            "humanStart",
            "humanEnd",
          ]),
        };
        return orderedJSONPayload(input);
      } else {
        const input: GraphLineHandlerInput = {
          ...omit(state.value, [
            "graphType",
            "previousPeriod",
            "humanStart",
            "humanEnd",
          ]),
          points: state.value.graphType === "grid" ? 50 : 200,
          "previous-period": state.value.previousPeriod,
        };
        return orderedJSONPayload(input);
      }
    },
  );

  const { data, execute } = useFetch("", {
    beforeFetch(ctx) {
      const { cancel } = ctx;
      const token = useCookie('token')
      const id_client = useCookie('id_client')

      if (state.value === null) {
        cancel();
        return ctx;
      }
      const url = "line";
      return {
        ...ctx,
        url: `/api/v0/console/graph/${url}?token=${token.value}&id_client=${id_client.value}`,
      };
    },
    async afterFetch(ctx: AfterFetchContext<GraphLineHandlerOutput | GraphSankeyHandlerOutput>) {
      const { data, response } = ctx;
      if (!data || !data.rows) {
        console.error("Unexpected data format", data);
        return ctx;
      }
      request.value = state.value;
    
      return ctx;
    },
    immediate: false,
  })
    .post(jsonPayload, "json")
    .json<
      GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
    >();

  if (!store.srcAs) {
    execute().then(async () => {
      store.srcAs = await (data.value as any).rows;
      store.data = await (data.value as any);
    });
  }

  return {
    store,
    state
  };
};
