import type {
  GraphLineHandlerInput,
  GraphLineHandlerOutput,
  GraphSankeyHandlerInput,
  GraphSankeyHandlerOutput,
} from "@/utils";
import type { ModelType } from "@/components/widgets/VisualizePage/OptionsPanel.vue";
import { useFetch, type AfterFetchContext } from "@vueuse/core";
import { omit } from "lodash-es";
import { defineStore } from "pinia";
import { computed, ref, type Ref } from "vue";

export const filterStore = () => {
  const innerStore = defineStore("filter", {
    state: () => ({
      srcAs: null,
    }),
    getters: {},
    actions: {
      async increment(data: Ref<any>) {
        if (!this.srcAs) {
          this.srcAs = data.value.rows;
        }
      },
    },
  });
  const store = innerStore();
  const state = ref<ModelType>({
    "bidirectional": false,
    "dimensions": [
        "SrcAS"
    ],
    "end": (new Date()).toISOString(),
    "filter": "InIfBoundary = external",
    "limit": 50,
    "points": 200,
    "previous-period": false,
    "start": "2024-07-03T14:21:00.187Z",
    "truncate-v4": 32,
    "truncate-v6": 128,
    "units": "l3bps"
});
  const request = ref<ModelType>(null);

  const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
    return Object.keys(input)
      .sort()
      .reduce(
        (o, k) => ((o[k] = input[k]), o),
        {} as { [key: string]: any },
      ) as T;
  };
  const jsonPayload = computed(
    (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
      if (state.value === null) return null;
      if (state.value.graphType === "sankey") {
        const input: GraphSankeyHandlerInput = {
          ...omit(state.value, [
            "graphType",
            "bidirectional",
            "previousPeriod",
            "humanStart",
            "humanEnd",
          ]),
        };
        return orderedJSONPayload(input);
      } else {
        const input: GraphLineHandlerInput = {
          ...omit(state.value, [
            "graphType",
            "previousPeriod",
            "humanStart",
            "humanEnd",
          ]),
          points: state.value.graphType === "grid" ? 50 : 200,
          "previous-period": state.value.previousPeriod,
        };
        return orderedJSONPayload(input);
      }
    },
  );

  const { data, execute } = useFetch("", {
    beforeFetch(ctx) {
      const { cancel } = ctx;
      if (state.value === null) {
        cancel();
        return ctx;
      }
      const url = "line";
      const token = useCookie('token')
      const id_client = useCookie('id_client')
      return {
        ...ctx,
        url: `/api/v0/console/graph/${url}?token=${token.value}&id_client=${id_client.value}`,
      };
    },
    async afterFetch(
      ctx: AfterFetchContext<GraphLineHandlerOutput | GraphSankeyHandlerOutput>,
    ) {
      const { data, response } = ctx;
      if (data === null || !state.value) return ctx;
      console.groupCollapsed("SQL query");
      console.info(
        response.headers.get("x-sql-query")?.replace(/ {2}( )*/g, "\n$1"),
      );
      console.groupEnd()
      request.value = state.value;

      return ctx;
    },
    immediate: false,
  })
    .post(jsonPayload, "json")
    .json<
      GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
    >();
  if (!store.srcAs) {
    execute().then(async () => {
      store.srcAs = await (data.value as any)?.rows;
    });
  }
  return store;
};
