<template>
  <div class="space-y-7 p-5">
    <div class="w-80 flex-col p-2 bg-zinc-200 dark:bg-zinc-700 rounded">
      <div class="flex justify-between">
        <span class="text-surface-500 dark:text-surface-40 mb-5">
          IP Neighbor:
        </span>
        <InputString v-model="ipNeighbor"></InputString>
      </div>
      <div class="flex justify-between">
        <span class="text-surface-500 dark:text-surface-40 mb-5">
          {{ translations['asn_client'] }}:
        </span>
        <InputString v-model="asnClient"></InputString>
      </div>
      <div class="flex justify-between">
        <span class="text-surface-500 dark:text-surface-40 mb-5">
          {{ translations['password'] }}:
        </span>
        <InputString v-model="password"></InputString>
      </div>
      <InputButton @click="addRouter()" class="justify-center sm:max-lg:order-4 mt-1">
        {{ translations['add'] }}
      </InputButton>
    </div>
    <div class="flex justify-around p-2 w-1/2 h-80 bg-zinc-200 dark:bg-zinc-700 rounded">
      <div ref="routersDiv" @scroll="syncScroll('routersDiv')" class="w-1/4 p-2 bg-zinc-300 dark:bg-zinc-500 rounded overflow-auto">
        <h2 class="text-center">{{ translations['routers'] }}</h2>
          <div
            v-for="(router, index) in routersList" :key="index" @click="toggleRouterSelection(router)"
            :class="{'bg-blue-500 text-white': selectedRouter === router, 'cursor-pointer': true, 'p-2': true, 'rounded': true}"
          >
            {{ router.ipNeighbor }}
          </div>
      </div>
      <div ref="statusDiv" @scroll="syncScroll('statusDiv')" class="w-1/4 p-2 bg-zinc-300 dark:bg-zinc-500 rounded overflow-auto">
        <h2 class="text-center">Status</h2>
        <div class="space-y-1">
          <div v-for="(router, index) in routersList" :key="index" @click="toggleRouterSelection(router)"
          :class="{'bg-blue-500 text-white': selectedRouter === router, 'cursor-pointer': true, 'p-2': true, 'rounded': true}" class="p-2">
            <InputCheckbox v-model="router.status" label="Active"/>
          </div>
        </div>
      </div>
      <div class="w-1/4 p-2 bg-zinc-300 dark:bg-zinc-500 rounded">
        <h2 class="text-center">{{ translations['permitions'] }}</h2>
        <div class="space-y-1 p-1" v-if="selectedRouter">
          <InputCheckbox v-model="selectedRouter.permissions.deviation" label="Deviation"></InputCheckbox>
          <InputCheckbox v-model="selectedRouter.permissions.flowspec" label="Flowspec"></InputCheckbox>
          <InputCheckbox v-model="selectedRouter.permissions.trafficEng" label="Traffic Eng."></InputCheckbox>
        </div>
      </div>
      <div class="flex flex-col space-y-2 justify-center">
        <PrimeButton class="justify-center sm:max-lg:order-4 mt-1">
          {{ translations['save'] }}
        </PrimeButton>
        <PrimeButton @click="deleteRouter()" severity="danger" class="justify-center sm:max-lg:order-4 mt-1">
          {{ translations['delete'] }}
        </PrimeButton>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import getTranslations from '@/utils/translations';
import InputString from './InputString.vue';
import InputCheckbox from './InputCheckbox.vue';
import { indexOf } from 'lodash-es';

const language = useCookie('language');
const translations: any = await getTranslations('connectivity', language.value);

interface Permissions {
  deviation: boolean;
  flowspec: boolean;
  trafficEng: boolean;
}
interface RouterData {
  ipNeighbor: string;
  asnClient: string;
  password: string;
  status: boolean;
  permissions: Permissions;
}
const routersList = ref<RouterData[]>([]);
const ipNeighbor = ref('');
const asnClient = ref('');
const password = ref('');
const routersDiv = ref(null);
const statusDiv = ref(null);
var selectedRouter = ref<RouterData | null>(null);

function addRouter() {
  const permissions = {
    deviation: false,
    flowspec: false,
    trafficEng: false,
  }

  if (!ipNeighbor.value || !asnClient.value || !password.value) {
    return;
  }

  routersList.value.push({
    ipNeighbor: ipNeighbor.value,
    asnClient: asnClient.value,
    password: password.value,
    status: true,
    permissions: permissions,
  });
  cleanInputs();
}

function cleanInputs() {
  ipNeighbor.value = '';
  asnClient.value = '';
  password.value = '';
}

function toggleRouterSelection(router: RouterData) {
  if (selectedRouter.value === router) {
    selectedRouter.value = null;
  } else {
    selectedRouter.value = router;
  }
}

function deleteRouter() {
  const index = indexOf(routersList.value, selectedRouter.value);
  selectedRouter.value = null;
  routersList.value.splice(index, 1);
}

function syncScroll(source: any) {
  const sourceDiv = source === 'routersDiv' ? routersDiv.value : statusDiv.value;
  const targetDiv = source === 'routersDiv' ? statusDiv.value : routersDiv.value;
  targetDiv.scrollTop = sourceDiv.scrollTop;
}

</script>