<template>
  <div :class="$attrs['class']">
    <div class="relative">
      <InputBase v-slot="{ id, childClass }" v-bind="otherAttrs" :error="error">
        <fieldset :class="childClass">
          <div class="space-y-4">
            <div
              v-for="item in filteredItems"
              :key="item.id"
              class="flex items-center"
            >
              <input
                :id="`${id}-${item.id}`"
                v-model="internalValue"
                type="radio"
                :name="id"
                :value="item.id"
                class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500 dark:text-blue-500 dark:focus:ring-blue-600"
                @change="updateValue"
              />
              <label
                :for="`${id}-${item.id}`"
                class="ml-3 block text-sm font-medium text-gray-700 dark:text-gray-300"
              >
                <slot name="item" v-bind="item"></slot>
              </label>
            </div>
          </div>
        </fieldset>
      </InputBase>
    </div>
  </div>
</template>

<script lang="ts">
export default {
  inheritAttrs: false,
};
</script>

<script lang="ts" setup>
import { ref, computed, useAttrs, watch } from "vue";
import InputBase from "@/components/InputBase.vue";

const props = withDefaults(
  defineProps<{
    modelValue: any;
    items: Array<{ id: number; [n: string]: any }>;
    error?: string;
    filter?: string | null;
    legend: string;
  }>(),
  {
    error: "",
    filter: null,
  },
);
const emit = defineEmits<{
  "update:modelValue": [value: typeof props.modelValue];
}>();

const attrs = useAttrs();
const internalValue = ref(props.modelValue);
const query = ref("");

watch(
  () => props.modelValue,
  (newValue) => {
    internalValue.value = newValue;
  },
);

const updateValue = (event: Event) => {
  const target = event.target as HTMLInputElement;
  emit("update:modelValue", props.items[0]);
};

const filteredItems = computed(() => {
  if (props.filter === null) return props.items;
  return props.items.filter((it) =>
    query.value
      .toLowerCase()
      .split(/\W+/)
      .every((w) => `${it[props.filter!]}`.toLowerCase().includes(w)),
  );
});

const otherAttrs = computed(() => {
  const { class: _, ...others } = attrs;
  return others;
});
</script>

<style scoped>
/* Adicione estilos adicionais conforme necessário */
</style>
