<template>
  <div class="w-full h-auto">
    <div class="ml-12 mt-3 text-left">
      <p class="text-lg">{{ translations['bytes_per_hour'] }}</p>
      <p class="text-sm">{{ translations['total'] }}: {{ total_bytes }}</p>
    </div>
    <div ref="chart" class="w-full h-96"></div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { use, type ComposeOption } from "echarts/core";
import { LineChart, type LineSeriesOption } from "echarts/charts";
import { CanvasRenderer } from 'echarts/renderers';
import { GridComponent, type GridComponentOption, TitleComponent, TooltipComponent } from 'echarts/components';
import * as echarts from 'echarts/core';
import getTranslations from '@/utils/translations';

const config = useRuntimeConfig();
const translations: any = await getTranslations('network_explorer_page');

use([LineChart, CanvasRenderer, GridComponent, TitleComponent, TooltipComponent]);
const chart = ref(null);

const total_bytes = ref();

// pt: Função para fazer a requisição e iniciar o gráfico do Network
// es: Función para realizar la solicitud e iniciar el gráfico de Network
async function fetchDataAndInitializeChart() {
  try {
    const token = useCookie("token");
    const id_client = useCookie("id_client");
    const { data, error } = await useFetch(`${config.public.goServer}/consult/network_explorer?token=${token.value}&id_client=${id_client.value}`, {
      method: "POST",
    });
    if (error.value) {
      throw new Error(`Error fetching data: ${error.value}`);
    }
    const parsedData = parseData(data.value);
    if (!parsedData) {
      throw new Error("Data is null");
    }
    const bytes_by_time = parsedData.bytes_by_time;
    total_bytes.value = parsedData.total_bytes;
    const timeReceivedHour: Date[] = bytes_by_time.map((item: { timeReceivedHour: string }) => new Date(item.timeReceivedHour));
    const bytes: number[] = bytes_by_time.map((item: { totalBytes: number }) => item.totalBytes);
    makeChart(timeReceivedHour, bytes);
  } catch (err: any) {
    console.error(err.message);
  }
}

// pt: Função para criar o gráfico usando echarts
// es: Función para crear el gráfico usando echarts
function makeChart(timeReceivedHour: Date[], bytes: number[]) {
  const myChart = echarts.init(chart.value);
  const option: ComposeOption<LineSeriesOption | GridComponentOption> = {
    grid: {
      top: 25,
      right: 5,
      left: 120,
    },
    tooltip: {
      trigger: 'axis'
    },
    xAxis: {
      type: 'category',
      data: timeReceivedHour
        .sort((a, b) => a.getTime() - b.getTime())
        .map(date => `${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`)
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        data: bytes,
        type: 'line'
      }
    ]
  };
  myChart.setOption(option);
}

watchOnce(() => chart.value, () => {
  fetchDataAndInitializeChart();
});
</script>