<template>
  <div>
    <div v-if="!loading" class="h-[300px] flex flex-col items-center">
      <h1 class="font-semibold leading-relaxed">{{ title }}</h1>
      <v-chart :option="option" :theme="isDark ? 'dark' : undefined" autoresize />
    </div>
    <div v-else class="flex items-center flex-col">
      <div class="flex mt-4 w-full h-40 justify-center items-end gap-4">
        <PrimeSkeleton width="4rem" height="40%"></PrimeSkeleton>
        <PrimeSkeleton width="4rem" height="70%"></PrimeSkeleton>
        <PrimeSkeleton width="4rem" height="85%"></PrimeSkeleton>
        <PrimeSkeleton width="4rem" height="50%"></PrimeSkeleton>
        <PrimeSkeleton width="4rem" height="100%"></PrimeSkeleton>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, inject } from "vue";
import { useFetch } from "@vueuse/core";
import { ThemeKey } from "@/components/ThemeProvider.vue";
import { use, graphic, type ComposeOption } from "echarts/core";
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  type TooltipComponentOption,
  type GridComponentOption,
} from 'echarts/components';
import { BarChart, type BarSeriesOption } from 'echarts/charts';
import { LabelLayout } from 'echarts/features';
import { CanvasRenderer } from 'echarts/renderers';
import VChart from "vue-echarts";
import { formatXps } from "@/utils";
import { dataColor } from "@/utils/palette";
import { isEqual, omit, pick } from 'lodash-es';
const { isDark } = inject(await ThemeKey)!;

const props = defineProps<{
  state: any;
  dimensions?: string[];
  title: string
}>()
const cookieToken = useCookie('token')
const cookieIdClient = useCookie('id_client')
type ECOption = ComposeOption<
  BarSeriesOption | TooltipComponentOption | GridComponentOption
>;
use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  BarChart,
  CanvasRenderer,
  LabelLayout,
  GridComponent
]);

const state = ref(props.state)
function arraySum(arr: number[]) {
  return arr.reduce((acc, curr) => acc + curr, 0);
}

const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
  return Object.keys(input)
    .sort()
    .reduce(
      (o, k) => ((o[k] = input[k]), o),
      {} as { [key: string]: any },
    ) as T;
};

const jsonPayload = await computed(
  (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
    if (state.value === null) return null;
    const input: GraphLineHandlerInput = {
      ...omit(state.value, [
        "graphType",
        "previousPeriod",
        "humanStart",
        "humanEnd",
      ]),
      points: 200,
      "previous-period": state.value.previousPeriod,
    };
    if (props.dimensions) {
      input.dimensions = props.dimensions;
    }
    return orderedJSONPayload(input);
  }
);
const loading = ref<boolean>(true);
const { data, execute, isFetching, aborted, abort, canAbort, error } = await useFetch(
  `/api/v0/console/graph/line?token=${cookieToken.value}&id_client=${cookieIdClient.value}`,{
  immediate: true
}
).post(jsonPayload, "json")
  .json<
    GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
  >();

watch(
  () => props.state,
  async () => {
    let newState = await props.state;
    if (props.dimensions) {
      newState.dimensions = await props.dimensions
    }
    state.value = await newState;
  },
  { immediate: true },
);
watch(
  [jsonPayload, state],
  async () => {
    loading.value = true;
    await execute();
    console.log(await state.value.dimensions[0]);
    loading.value = false;
  },
  { immediate: true },
);
const option = computedAsync(
  async (): ECOption => ({
    darkMode: isDark.value,
    backgroundColor: "transparent",
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      valueFormatter(value: number) {
        return formatXps(value * 1_000_000_000);
      },
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: await data.value?.rows
    },
    yAxis: {
      type: 'value',
      boundaryGap: [0, 0.01]
    },
    series: [
      {
        type: "bar",
        label: { show: false },
        data: await data.value?.points?.map((i: number[]) => arraySum(i)),
        itemStyle: {
          color({ name, dataIndex }: { name: string; dataIndex: number }) {
            const theme = isDark.value ? "dark" : "light";
            if (name === "Others") {
              return dataColorGrey(0, false, theme);
            }
            return dataColor(dataIndex, false, theme);
          },
        },
      },
    ],
  }), null
);
</script>
