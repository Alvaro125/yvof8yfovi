<template>
  <div>
    <div v-if="!loading" class="h-[300px] flex flex-col items-center">
      <h1 class="font-semibold leading-relaxed">{{ title }}</h1>
      <v-chart :option="option" :theme="isDark ? 'dark' : undefined" autoresize />
    </div>
    <div v-else class="flex items-center flex-col">
      <PrimeSkeleton shape="circle" size="10rem" class="mr-2"></PrimeSkeleton>
      <div class="flex justify-between mt-4">
        <PrimeSkeleton width="2rem" height="1rem"></PrimeSkeleton>
        <PrimeSkeleton width="2rem" height="1rem"></PrimeSkeleton>
        <PrimeSkeleton width="2rem" height="1rem"></PrimeSkeleton>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, inject } from "vue";
import { useFetch } from "@vueuse/core";
import { ThemeKey } from "@/components/ThemeProvider.vue";
import { use, graphic, type ComposeOption } from "echarts/core";
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  type TooltipComponentOption,
  type GridComponentOption,
} from 'echarts/components';
import { PieChart, type PieSeriesOption } from 'echarts/charts';
import { LabelLayout } from 'echarts/features';
import { CanvasRenderer } from 'echarts/renderers';
import VChart from "vue-echarts";
import { formatXps } from "@/utils";
import { dataColor } from "@/utils/palette";
import { isEqual, omit, pick } from 'lodash-es';
const { isDark } = inject(await ThemeKey)!;
const cookieToken = useCookie('token')
const cookieIdClient = useCookie('id_client')
const props = defineProps<{
  state: any;
  dimensions?: string[];
  title: string
}>()

type ECOption = ComposeOption<
  PieSeriesOption | TooltipComponentOption | GridComponentOption
>;
use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  PieChart,
  CanvasRenderer,
  LabelLayout
]);

const state = ref(props.state)
function formatPorcent(_data: any){
  let rows = _data.rows.map((item: any, key: number) => {
    return { value: _data.points[key].reduce((a: number, b: number) => a + b, 0), name: item[0] }
  })
  let total = rows.reduce(function (acc: number, obj: any) { return acc + obj.value; }, 0)
  rows = rows.map((item: any, key: number) => {
    return { value: item.value/total*100, name: item.name }
  })
  return rows
};

const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
  return Object.keys(input)
    .sort()
    .reduce(
      (o, k) => ((o[k] = input[k]), o),
      {} as { [key: string]: any },
    ) as T;
};

const jsonPayload = await computed(
  (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
    if (state.value === null) return null;
    if (state.value.graphType === "sankey") {
      const input: GraphSankeyHandlerInput = {
        ...omit(state.value, [
          "graphType",
          "bidirectional",
          "previousPeriod",
          "humanStart",
          "humanEnd",
        ]),
      };
      return orderedJSONPayload(input);
    } else {
      const input: GraphLineHandlerInput = {
        ...omit(state.value, [
          "graphType",
          "previousPeriod",
          "humanStart",
          "humanEnd",
        ]),
        points: state.value.graphType === "grid" ? 50 : 200,
        "previous-period": state.value.previousPeriod,
      };
      if (props.dimensions) {
        input.dimensions = props.dimensions;
      }
      return orderedJSONPayload(input);
    }
  },
);
const loading = ref<boolean>(true);
const { data, execute, isFetching, aborted, abort, canAbort, error } = await useFetch(
  '', {
  beforeFetch(ctx) {
    const { cancel } = ctx;
    if (props.state === null) {
      cancel();
      return ctx;
    }
    return {
      ...ctx,
        url: `/api/v0/console/graph/line?token=${cookieToken.value}&id_client=${cookieIdClient.value}`,
    };
  },
  immediate: true
}
).post(jsonPayload, "json")
  .json<
    GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
  >();

watch(
  () => props.state,
  async () => {
    let newState = await props.state;
    if (props.dimensions) {
      newState.dimensions = await props.dimensions
    }
    state.value = await newState;
  },
  { immediate: true },
);
watch(
  [jsonPayload, state],
  async () => {
    loading.value = true;
    await execute();
    loading.value = false;
  },
  { immediate: true },
);
const option = computedAsync(
  async (): ECOption => ({
    darkMode: isDark.value,
    backgroundColor: "transparent",
    tooltip: {
      trigger: "item",
      confine: true,
      valueFormatter(value) {
        return (value.valueOf() as number).toFixed(2) + "%";
      },
    },
    legend: {
      orient: "horizontal",
      bottom: "bottom",
      itemGap: 5,
      itemWidth: 14,
      itemHeight: 14,
      textStyle: {
        fontSize: 10,
        color: isDark.value ? "#eee" : "#111",
      },
      formatter(name: string) {
        return name.split(": ")[0];
      },
    },
    series: [
      {
        type: "pie",
        label: { show: false },
        center: ["50%", "40%"],
        radius: "60%",
        data: await formatPorcent(data.value),
        itemStyle: {
          color({ name, dataIndex }: { name: string; dataIndex: number }) {
            const theme = isDark.value ? "dark" : "light";
            if (name === "Others") {
              return dataColorGrey(0, false, theme);
            }
            return dataColor(dataIndex, false, theme);
          },
        },
      },
    ],
  }), null
);
</script>
