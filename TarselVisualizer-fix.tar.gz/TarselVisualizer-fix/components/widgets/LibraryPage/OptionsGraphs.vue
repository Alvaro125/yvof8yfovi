<template>
  <div class="transition-height transition-width w-full shrink-0 duration-100 lg:h-auto" :class="localOpen ? 'h-80 lg:w-72' : 'h-0 lg:w-0'">
    <form
      class="h-full overflow-y-auto border-b border-gray-300 bg-gray-100 dark:border-slate-700 dark:bg-slate-800 lg:border-b-0 lg:border-r"
      autocomplete="off" spellcheck="false" @submit.prevent="submitOptions()">
      <div v-if="open" class="flex flex-col px-3 py-4 lg:max-h-screen">
        <div class="mb-2 flex flex-row flex-wrap items-center justify-between gap-2 sm:max-lg:flex-nowrap">
          <InputButton attr-type="submit" class="order-2 w-28 justify-center sm:max-lg:order-4" @click="Submit()">{{
            translations_library['submit'] }}</InputButton>
          <InputChoice v-model="units" :choices="[
            { label: 'L3ᵇ⁄ₛ', name: 'l3bps' },
            { label: 'L2ᵇ⁄ₛ', name: 'l2bps' },
            { label: '→%', name: 'inl2%' },
            { label: '%→', name: 'outl2%' },
            { label: 'ᵖ⁄ₛ', name: 'pps' },
          ]" label="Unit" class="order-1" />
          <InputListBox v-model="graphType" :items="graphTypeList"
            class="order-3 grow basis-full sm:max-lg:order-3 sm:max-lg:basis-0"
            :label="translations_visualize['graph_type']">
            <template #selected>{{ graphType.name }}</template>
            <template #item="{ name }">
              <div class="flex w-full items-center justify-between">
                <span>{{ name }}</span>
                <GraphIcon :name="name" class="mr-1 inline h-4 text-gray-500 dark:text-gray-400" />
              </div>
            </template>
          </InputListBox>
          <div
            class="order-4 flex grow flex-row justify-between gap-x-3 sm:max-lg:order-2 sm:max-lg:grow-0 sm:max-lg:flex-col">
            <InputCheckbox v-if="graphType.type === 'stacked' ||
              graphType.type === 'stacked100' ||
              graphType.type === 'lines' ||
              graphType.type === 'grid'
            " v-model="bidirectional" :label="translations_visualize['bidirectional']" />
            <InputCheckbox v-if="graphType.type === 'stacked'" v-model="previousPeriod"
              :label="translations_visualize['previous_period']" />
          </div>
        </div>
        <SectionLabel>{{ translations_visualize['time_range'] }}</SectionLabel>
        <InputTimeRange v-model="timeRange" />
        <SectionLabel>{{ translations_visualize['dimensions'] }}</SectionLabel>
        <InputDimensions v-model="dimensions" :min-dimensions="graphType.name === graphTypes.sankey ? 2 : 0" />
        <SectionLabel>
          <template #default>{{ translations_visualize['filter'] }}</template>
          <template #hint>
            <kbd
              class="rounded border border-gray-300 bg-gray-200 px-1 dark:border-gray-600 dark:bg-gray-900">Ctrl-Enter</kbd>
            {{ translations_visualize['to_execute'] }}
          </template>
        </SectionLabel>
        <!-- <InputFilter v-model="filter" class="mb-2" @submit="submitOptions()" /> -->
        <ModalFilter v-model="filter" @submit="submitOptions()" />
      </div>
    </form>
  </div>
  <!-- <PrimeDrawer v-model:visible="localOpen" :header="translations_library['create_graph']" position="right" class="!w-full">
    <div class="flex h-full flex-col-reverse lg:flex-row">
      <div class="flex-1 overflow-scroll">
        <GraphPieLibrary v-if="obsOption.graphType == 'pie'" :state="obsOption" :title="nameDimensions[obsOption.dimensions[0]]" />
        <GraphBarLibrary v-else-if="obsOption.graphType=='bar'" :state="obsOption" :title="nameDimensions[obsOption.dimensions[0]]"/>
        <GraphLineLibrary v-else :state="obsOption" />
      </div>
      <div class="h-40 w-full lg:w-80 lg:h-full">
        <form
          class="h-full overflow-y-auto border-b border-gray-300 bg-gray-100 dark:border-slate-700 dark:bg-slate-800 lg:border-b-0 lg:border-r"
          autocomplete="off" spellcheck="false" @submit.prevent="submitOptions()">
          <div v-if="open" class="flex flex-col px-3 py-4 lg:max-h-screen">
            <div class="mb-2 flex flex-row flex-wrap items-center justify-between gap-2 sm:max-lg:flex-nowrap">
              <InputButton attr-type="submit" class="order-2 w-28 justify-center sm:max-lg:order-4" @click="Submit()" >{{ translations_library['submit'] }}</InputButton>
              <InputChoice v-model="units" :choices="[
      { label: 'L3ᵇ⁄ₛ', name: 'l3bps' },
      { label: 'L2ᵇ⁄ₛ', name: 'l2bps' },
      { label: '→%', name: 'inl2%' },
      { label: '%→', name: 'outl2%' },
      { label: 'ᵖ⁄ₛ', name: 'pps' },
    ]" label="Unit" class="order-1" />
              <InputListBox v-model="graphType" :items="graphTypeList"
                class="order-3 grow basis-full sm:max-lg:order-3 sm:max-lg:basis-0" :label="translations_visualize['graph_type']">
                <template #selected>{{ graphType.name }}</template>
                <template #item="{ name }">
                  <div class="flex w-full items-center justify-between">
                    <span>{{ name }}</span>
                    <GraphIcon :name="name" class="mr-1 inline h-4 text-gray-500 dark:text-gray-400" />
                  </div>
                </template>
              </InputListBox>
              <div
                class="order-4 flex grow flex-row justify-between gap-x-3 sm:max-lg:order-2 sm:max-lg:grow-0 sm:max-lg:flex-col">
                <InputCheckbox v-if="graphType.type === 'stacked' ||
      graphType.type === 'stacked100' ||
      graphType.type === 'lines' ||
      graphType.type === 'grid'
      " v-model="bidirectional" :label="translations_visualize['bidirectional']" />
                <InputCheckbox v-if="graphType.type === 'stacked'" v-model="previousPeriod" :label="translations_visualize['previous_period']" />
              </div>
            </div>
            <SectionLabel>{{ translations_visualize['time_range'] }}</SectionLabel>
            <InputTimeRange v-model="timeRange" />
            <SectionLabel>{{ translations_visualize['dimensions'] }}</SectionLabel>
            <InputDimensions v-model="dimensions" :min-dimensions="graphType.name === graphTypes.sankey ? 2 : 0" />
            <SectionLabel>
              <template #default>{{ translations_visualize['filter'] }}</template>
              <template #hint>
                <kbd
                  class="rounded border border-gray-300 bg-gray-200 px-1 dark:border-gray-600 dark:bg-gray-900">Ctrl-Enter</kbd>
                  {{ translations_visualize['to_execute'] }}
              </template>
            </SectionLabel>
            <ModalFilter v-model="filter" @submit="submitOptions()" />
          </div>
        </form>
      </div>
    </div>
  </PrimeDrawer> -->
</template>

<script lang="ts" setup>
import { ref, watch, computed, inject, toRaw } from "vue";
import { Date as SugarDate } from "sugar-date";
import {nameDimensions} from '@/utils/dimensions'
import { ChevronDownIcon, ChevronRightIcon } from "@heroicons/vue/solid";
import {
  default as InputTimeRange,
  type ModelType as InputTimeRangeModelType,
} from "@/components/InputTimeRange.vue";
import {
  default as InputDimensions,
  type ModelType as InputDimensionsModelType,
} from "@/components/InputDimensions.vue";
import InputListBox from "@/components/InputListBox.vue";
import ModalFilter from "@/components/ModalFilter.vue";
import InputButton from "@/components/InputButton.vue";
import InputCheckbox from "@/components/InputCheckbox.vue";
import InputChoice from "@/components/InputChoice.vue";
import {
  // default as InputFilter,
  type ModelType as InputFilterModelType,
} from "@/components/InputFilter.vue";
import { ServerConfigKey } from "@/components/ServerConfigProvider.vue";
import SectionLabel from "@/components/widgets/VisualizePage/SectionLabel.vue";
import GraphIcon from "@/components/widgets/VisualizePage/GraphIcon.vue";
import type { Units } from "@/utils";
import { isEqual, omit } from "lodash-es";
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations_library: any = await getTranslations('library', language.value);
const translations_visualize: any = await getTranslations('visualize', language.value);

const props = withDefaults(
  defineProps<{
    modelValue: ModelType | undefined;
    open: boolean;
    loading?: boolean;
  }>(),
  {
    loading: false,
  },
);
const emit = defineEmits<{
  "update:modelValue": [value: typeof props.modelValue];
  'update:open': [value: boolean];
  'update:submit': [value: boolean];
  cancel: [];
}>();
const graphTypes = {
  stacked: "Stacked areas",
  stacked100: "100% stacked",
  lines: "Lines",
  grid: "Grid",
  sankey: "Sankey",
  pie: "Pie",
  bar: "Bar"
}
const graphTypeList = Object.entries(graphTypes).map(([k, v], idx) => ({
  id: idx + 1,
  type: k as keyof typeof graphTypes, // why isn't it infered?
  name: v,
}));

function Submit() {
  emit('update:submit',true)
}

const localOpen = ref<boolean>(props.open)
const state = reactive({
  units: "l3bps",
  filter: ""
})
const graphType = ref(graphTypeList[0]);
const timeRange = ref<InputTimeRangeModelType>(null);
const dimensions = ref<InputDimensionsModelType>(null);
const filter = ref<InputFilterModelType>({ expression: "" });
const units = ref<Units>("l3bps");
const bidirectional = ref(false);
const previousPeriod = ref(false);
const obsOption = computed(() => {
  return {
        ...options.value,
        start: SugarDate.create(options.value?.humanStart).toISOString(),
        end: SugarDate.create(options.value?.humanEnd).toISOString(),
      }
})
const submitOptions = (force?: boolean) => {
  if (!force && props.loading) {
    emit("cancel");
  } else {
    if (options.value !== null && !hasErrors.value) {
      console.log(SugarDate.create(options.value.humanStart).toISOString())
      emit("update:modelValue", {
        ...options.value,
        start: SugarDate.create(options.value.humanStart).toISOString(),
        end: SugarDate.create(options.value.humanEnd).toISOString(),
      });
    }
  }
};
const options = computed((): InternalModelType => {
  console.log("timeRange: ", timeRange.value)
  if (!timeRange.value || !dimensions.value || !filter.value) {
    return options.value;
  }
  return {
    graphType: graphType.value.type,
    humanStart: timeRange.value?.start,
    humanEnd: timeRange.value?.end,
    dimensions: dimensions.value?.selected,
    limit: dimensions.value?.limit,
    "truncate-v4": dimensions.value?.truncate4,
    "truncate-v6": dimensions.value?.truncate6,
    filter: filter.value?.expression,
    units: units.value,
    bidirectional: false,
    previousPeriod: false,
    ...(graphType.value.type === "stacked" && {
      bidirectional: bidirectional.value,
      previousPeriod: previousPeriod.value,
    }),
    ...(graphType.value.type === "stacked100" && {
      bidirectional: bidirectional.value,
    }),
    ...(graphType.value.type === "lines" && {
      bidirectional: bidirectional.value,
    }),
    ...(graphType.value.type === "grid" && {
      bidirectional: bidirectional.value,
    }),
  };
});
const applyLabel = computed(() =>
  isEqual(options.value, omit(props.modelValue, ["start", "end"]))
    ? "Refresh"
    : "Apply",
);
const hasErrors = computed(
  () =>
    !!(
      timeRange.value?.errors ||
      dimensions.value?.errors ||
      filter.value?.errors
    ),
);

const serverConfiguration = inject(ServerConfigKey)!;
watch(
  () =>
    [
      props.modelValue,
      serverConfiguration.value?.defaultVisualizeOptions,
    ] as const,
  async ([modelValue, defaultOptions]) => {
    if (!defaultOptions) return;
    const currentValue: NonNullable<InternalModelType> = modelValue ?? {
      graphType: defaultOptions.graphType,
      humanStart: defaultOptions.start,
      humanEnd: defaultOptions.end,
      dimensions: toRaw(defaultOptions.dimensions),
      limit: defaultOptions.limit,
      "truncate-v4": 32,
      "truncate-v6": 128,
      filter: defaultOptions.filter,
      units: "l3bps",
      bidirectional: false,
      previousPeriod: false,
    };

    // Dispatch values in refs
    const t = currentValue.graphType;
    graphType.value =
      graphTypeList.find(({ type }) => type === t) || graphTypeList[0];
      console.log("timeRange: ", timeRange.value)
    timeRange.value = {
      start: currentValue.humanStart,
      end: currentValue.humanEnd,
    };
    console.log("timeRange: ", timeRange.value)
    dimensions.value = await {
      selected: [...currentValue.dimensions],
      limit: currentValue.limit,
      truncate4: currentValue["truncate-v4"] || 32,
      truncate6: currentValue["truncate-v6"] || 128,
    };
    filter.value = { expression: currentValue.filter };
    units.value = currentValue.units;
    bidirectional.value = currentValue.bidirectional;
    previousPeriod.value = currentValue.previousPeriod;

    // A bit risky, but it seems to work.
    if (
      modelValue === null ||
      !modelValue?.start ||
      !modelValue?.end ||
      !isEqual(omit(modelValue, ["start", "end"]), options.value)
    ) {
      console.log("defaultOptions: ",defaultOptions)
      console.log("modelValue: ",modelValue)
      submitOptions(true);
    }
  },
  { immediate: true, deep: true },
);
watch(() => props.open, (newVal) => {
  localOpen.value = newVal
})

watch(localOpen, (newVal) => {
  emit('update:open', newVal)
})
</script>

<script lang="ts">
import { graphTypes } from "@/utils/graphtypes";

export type ModelType = {
  graphType: keyof typeof graphTypes;
  start: string;
  end: string;
  humanStart: string;
  humanEnd: string;
  dimensions: string[];
  limit: number;
  "truncate-v4": number;
  "truncate-v6": number;
  filter: string;
  units: Units;
  bidirectional: boolean;
  previousPeriod: boolean;
} | null;
type InternalModelType = Omit<NonNullable<ModelType>, "start" | "end"> | null;
</script>
