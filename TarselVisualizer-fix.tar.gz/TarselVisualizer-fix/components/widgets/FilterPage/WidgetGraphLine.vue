<template>
  <div class="grow overflow-y-auto">
    <DataTableFlow v-if="viewFlow" />
    <LoadingOverlay v-if="!viewFlow" :loading="isFetching">
      <RequestSummaryInfo :request="request" class="absolute ml-2 mt-4 z-10" />
      <div class="mx-4 my-2">
        <InfoBox v-if="errorMessage" kind="error">
          <strong>Unable to fetch data!&nbsp;</strong>{{ errorMessage }}
        </InfoBox>
        <ResizeRow :slider-width="10" :height="graphHeight" width="auto" slider-bg-color="#eee1"
          slider-bg-hover-color="#ccc3" class="break-inside-avoid-page">
          <DataGraph :data="fetchedData" :highlight="highlightedSerie" @update:time-range="updateTimeRange" />
        </ResizeRow>
        <DataTable :data="fetchedData" class="my-2 break-inside-avoid-page" @highlighted="(n) => (highlightedSerie = n)"
          :th95="true" :limit="props.state.limit" />
      </div>
    </LoadingOverlay>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, computed } from "vue";
import { useFetch, type AfterFetchContext } from "@vueuse/core";
import { ResizeRow } from "vue-resizer";
import LZString from "lz-string";
import InfoBox from '@/components/InfoBox.vue';
import LoadingOverlay from '@/components/LoadingOverlay.vue';
import RequestSummary from '@/components/widgets/VisualizePage/RequestSummary.vue';
import DataTable from '@/components/widgets/VisualizePage/DataTable.vue';
import DataGraph from '@/components/widgets/VisualizePage/DataGraph.vue';
import DataTableFlow from "@/components/widgets/VisualizePage/DataTableFlow.vue";
import OptionsPanel, { type ModelType } from '@/components/widgets/VisualizePage/OptionsPanel.vue';
import type { GraphType } from '@/utils/graphtypes';
import type {
  GraphSankeyHandlerInput,
  GraphLineHandlerInput,
  GraphSankeyHandlerOutput,
  GraphLineHandlerOutput,
  GraphSankeyHandlerResult,
  GraphLineHandlerResult
} from "@/utils";
import { isEqual, omit, pick } from 'lodash-es';
import { useToast } from 'primevue/usetoast';

const toast = useToast();
const cookieToken = useCookie('token')
const cookieIdClient = useCookie('id_client')

const config = useRuntimeConfig()
const props = defineProps<{ state: any }>();
const emit = defineEmits<{
  'update:fetchedData': [data: GraphLineHandlerResult | GraphSankeyHandlerResult | null]
}>();

const op = ref<boolean>(false);
const nameFilter = ref<string>('');
const viewFlow = ref(false);
const viewOption = ref(false);
const graphHeight = ref(500);
const highlightedSerie = ref<number | null>(null);

// Main state
const state = ref<ModelType>(props.state);

const updateTimeRange = ([start, end]: [Date, Date]) => {
  if (state.value === null) return;
  state.value = {
    ...state.value,
    start: start.toISOString(),
    end: end.toISOString(),
    humanStart: start.toISOString(),
    humanEnd: end.toISOString(),
  };
};
const decodeState = (serialized: string | undefined): ModelType => {
  try {
    if (!serialized) {
      console.debug("no state");
      return null;
    }
    const unserialized = LZString.decompressFromBase64(serialized);
    if (!unserialized) {
      console.debug("empty state");
      return null;
    }
    return JSON.parse(unserialized);
  } catch (error) {
    console.error("cannot decode state:", error);
    return null;
  }
};

const encodeState = (state: ModelType) => {
  if (state === null) return "";
  return LZString.compressToBase64(
    JSON.stringify(state, Object.keys(state).sort()),
  );
};

watch(
  () => props.state,
  async () => {
    let newState = await props.state;
    state.value = await newState;
  },
  { immediate: true },
);

const encodedState = computed(() => encodeState(state.value));

// Fetch data
const fetchedData = ref<
  GraphLineHandlerResult | GraphSankeyHandlerResult | null
>(null);

const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
  return Object.keys(input)
    .sort()
    .reduce(
      (o, k) => ((o[k] = input[k]), o),
      {} as { [key: string]: any },
    ) as T;
};

const jsonPayload = computed(
  (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
    console.log(state.value)
    if (state.value === null) return null;
    if (state.value.graphType === "sankey") {
      const input: GraphSankeyHandlerInput = {
        ...omit(state.value, [
          "graphType",
          "bidirectional",
          "previousPeriod",
          "humanStart",
          "humanEnd",
        ]),
      };
      return orderedJSONPayload(input);
    } else {
      const input: GraphLineHandlerInput = {
        ...omit(state.value, [
          "graphType",
          "previousPeriod",
          "humanStart",
          "humanEnd",
        ]),
        points: state.value.graphType === "grid" ? 50 : 200,
        "previous-period": state.value.previousPeriod,
      };
      return orderedJSONPayload(input);
    }
  },
);

const request = ref<ModelType>(null); // Same as state, but once request is successful
const { data, execute, isFetching, aborted, abort, canAbort, error } = useFetch(
  "",
  {
    beforeFetch(ctx) {
      // Add the URL. Not a computed value as if we change both payload
      // and URL, the query will be triggered twice.
      const { cancel } = ctx;
      if (state.value === null) {
        cancel();
        return ctx;
      }
      const endpoint: Record<GraphType, string> = {
        stacked: "line",
        stacked100: "line",
        lines: "line",
        grid: "line",
        sankey: "sankey",
      };
      const url = endpoint[state.value.graphType];
      return {
        ...ctx,
        url: `/api/v0/console/graph/${url}?token=${cookieToken.value}&id_client=${cookieIdClient.value}`,
      };
    },
    async afterFetch(
      ctx: AfterFetchContext<GraphLineHandlerOutput | GraphSankeyHandlerOutput>,
    ) {
      // Update data. Not done in a computed value as we want to keep the
      // previous data in case of errors.
      const { data, response } = ctx;
      if (data === null || !state.value) return ctx;
      console.groupCollapsed("SQL query");
      console.info(
        response.headers.get("x-sql-query")?.replace(/ {2}( )*/g, "\n$1"),
      );
      console.groupEnd();
      if (state.value.graphType === "sankey") {
        fetchedData.value = {
          graphType: "sankey",
          ...(data as GraphSankeyHandlerOutput),
          ...pick(state.value, ["start", "end", "dimensions", "units"]),
        };
      } else {
        fetchedData.value = {
          graphType: state.value.graphType,
          ...(data as GraphLineHandlerOutput),
          ...pick(state.value, [
            "start",
            "end",
            "dimensions",
            "units",
            "bidirectional",
          ]),
        };
      }

      // Emitir fetchedData para o componente pai
      emit('update:fetchedData', fetchedData.value);

      request.value = state.value;

      return ctx;
    },
    immediate: false,
  },
)
  .post(jsonPayload, "json")
  .json<
    GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
  >();

watch(
  [jsonPayload],
  async () => {
    console.log('jsonPayload', jsonPayload)
    await execute();
  },
  { immediate: true },
);
const errorMessage = computed(() => {
  if (!error.value || aborted.value) return "";
  if (data.value && "message" in data.value) return data.value.message;
  return `Server returned an error: ${error.value}`;
});

function formatJSON(obj: any, from: string, to: string) {
  let object: any = {};

  Object.keys(obj).forEach((key: any) => {
    object[key.toString().replace(from, to)] = parseValue(obj[key]);
  });
  return object;
}

function parseValue(value: string | any) {
  if (value === 'true') return true;
  if (value === 'false') return false;
  return value;
}

async function SaveFilter() {
  try {
    console.log(await state.value)
    let filter = await formatJSON(state.value, "-", "_")
    filter['filterName'] = await nameFilter.value
    filter['code'] = await encodedState.value
    const data = await $fetch(`${config.public.apiFastApi}/save_filter`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json'
      },
      body: filter
    })
    if (data.error) {
      throw data;
    }
    console.log(data)
    toast.add({ severity: 'success', summary: 'Success Message', detail: data.message, life: 3000 });
  } catch (error) {
    if (error.error) {
      toast.add({ severity: 'error', summary: 'Error Message', detail: error.error, life: 3000 });
    } else {
      toast.add({ severity: 'error', summary: 'Error Message', detail: error.data.detail, life: 3000 });
    }
    console.dir(error);
  }
}
</script>
