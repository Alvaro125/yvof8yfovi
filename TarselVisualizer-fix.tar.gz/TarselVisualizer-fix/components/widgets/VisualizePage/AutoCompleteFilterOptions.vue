<template>
    <div class="relative flex flex-col w-52">
        <p>
            <input :type="typeDimensions[props.dimension]" v-model="valueModel" class="h-8">
            <button v-if="!noSearch.includes(props.dimension)" class="pi"
                :class="!isOpen ? 'pi-caret-down' : 'pi-caret-up'" @click="isOpen = !isOpen"></button>
        </p>
        <ul :id="`list-${props.eIndex}-${props.gIndex}`"
            class="absolute z-20 top-8 overflow-y-scroll max-h-40 bg-slate-900 text-gray-100 w-full" v-if="isOpen"
            ref="elNets">
            <li v-for="item in filteredList" class="pl-2" @click="selectValue(item)">{{ item }}</li>
        </ul>
    </div>
</template>

<script setup lang="ts">
import { ThemeKey } from "@/components/ThemeProvider.vue";
const { isDark } = inject(await ThemeKey)!;
const valueModel = defineModel()
const props = defineProps<{
    dimension: string
}>()
const config = useRuntimeConfig()
const token = useCookie('token')
const id_client = useCookie('id_client')
const list = ref<Array<number | string>>([])
const isOpen = ref<boolean>(false);
const page = ref<number>(1);
const limit = ref<number>(50);
const valueInit = ref<string>("");
const noSearch: string[] = ['DstPort', 'SrcPort', 'SrcAddr', 'DstAddr', 'SrcNetName', 'DstNetName', 'SrcNetPrefix', 'DstNetPrefix', 'SrcNetRole', 'DstNetRole', 'PacketSizeBucket', 'Proto', 'ForwardingStatus'];
const elNets = ref<HTMLElement | null>(null)
const { x, y, isScrolling, arrivedState, directions } = useScroll(elNets)

watch([() => [props.dimension]], async ([_data,]: [any]) => {
    valueModel.value = ''
    page.value = 1
    try {
        const data: any = await $fetch(`${config.public.goServer}/consult/filter_column`, {
            method: 'POST',
            mode: 'cors',
            query: {
                "token": `${token.value}`,
                "id_client": id_client.value
            },
            body: {
                "search": valueModel.value,
                "page": page.value,
                "limit": limit.value,
                "target": (_data[0] as string).replace('Out', '').replace('In', '')
            }
        })
        if (props.dimension == "EType") {
            list.value = ["IPv4", "IPv6"]
        } else {
            list.value = data.columns.map((i: any) => {
                if (props.dimension == "Proto") {
                    return protocols[`${i.column}`].keyword
                }
                return i.column
            })
        }
    } catch (error) {
        if (props.dimension == "EType") {
            list.value = ["IPv4", "IPv6"]
        } else if (["SrcCountry", "DstCountry"].includes(props.dimension)) {
            list.value = countries.map(i => i.code)
        } else {
            list.value = []
        }
    }
}, { immediate: false })

const handleClickOutside = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    if (elNets.value && !elNets.value.contains(target) &&
        !target.closest('.relative.flex.flex-col')) {
        isOpen.value = false;
    }
}

// Adiciona e remove o event listener
onMounted(() => {
    document.addEventListener('click', handleClickOutside);
});

onUnmounted(() => {
    document.removeEventListener('click', handleClickOutside);
});
watch(valueModel, async (a, b) => {
    try {
        if (a = !b && !noSearch.includes(props.dimension)) {
            isOpen.value = true
        }
        page.value = 1
        const data: any = await $fetch(`${config.public.goServer}/consult/filter_column`, {
            method: 'POST',
            mode: 'cors',
            query: {
                "token": `${token.value}`,
                "id_client": id_client.value
            },
            body: {
                "search": valueModel.value,
                "page": page.value,
                "limit": limit.value,
                "target": (props.dimension as string).replace('Out', '').replace('In', '')
            }
        })
        if (props.dimension == "EType") {
            list.value = ["IPv4", "IPv6"]
        } else {
            list.value = data.columns.map((i: any) => {
                if (props.dimension == "Proto") {
                    return protocols[`${i.column}`].keyword
                }
                return i.column
            })
        }
    } catch (error) {
        if (props.dimension == "EType") {
            list.value = ["IPv4", "IPv6"]
        } else if (["SrcCountry", "DstCountry"].includes(props.dimension)) {
            list.value = countries.map(i => i.code)
        } else {
            list.value = []
        }
    }

},{immediate:true})
const filteredList = computed(() => {
    try {
        const regex = new RegExp(valueModel.value.toString(), 'i');
        return list.value.filter(item => regex.test(item.toString()));
    } catch (error) {
        console.error('Invalid regex:', error);
        return list.value;
    }
});
watch([arrivedState], async () => {
    let savepage = page.value
    if (arrivedState.bottom) {
        page.value += 1
        const data: any = await $fetch(`${config.public.goServer}/consult/filter_column`, {
            method: 'POST',
            cors: 'cors',
            query: {
                "token": `${token.value}`,
                "id_client": id_client.value
            },
            body: {
                "token": `${token.value}`,
                "id_client": id_client.value,
                "search": valueModel.value,
                "page": page.value,
                "limit": limit.value,
                "target": (props.dimension as string).replace('Out', '').replace('In', '')
            }
        })
        if (data.columns) {
            list.value.push(...data.columns.map((i: any) => i.column))
        } else {
            page.value = savepage
        }
    }
})
function selectValue(content: string): void {
    valueModel.value = isNumeric(content);
    isOpen.value = false
}

function isNumeric(value: string): string | number {
    if (!isNaN(parseFloat(value)) && isFinite(Number(value))) {
        return Number(value)
    }
    return value
}
</script>