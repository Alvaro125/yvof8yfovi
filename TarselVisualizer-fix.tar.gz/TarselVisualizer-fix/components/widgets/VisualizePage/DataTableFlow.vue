<template>
  <div>
    <!-- <DataGraphFlow :data="flows"></DataGraphFlow> -->
    <div class="card flex justify-end">
      <PrimeDrawer v-model:visible="visible" :header="translations['custom_time']" position="right">
          <PrimeListbox v-model="selectedTime" :options="optionsTime" optionLabel="title" class="w-full md:w-56"/>
      </PrimeDrawer>
      <PrimeButton
      class="bg-gray-800 border-[1px] border-gray-50 text-gray-50 hover:bg-gray-50 w-[2rem] h-[2rem]"
      icon="pi pi-hourglass" 
      @click="visible = true"></PrimeButton>
    </div>
    <DataGraph :data="dataFlow" :highlight="highlightedSerie" @update:time-range="updateTimeRange" class="h-[20rem]">
    </DataGraph>
    <DataTable :data="dataFlow" class="my-2 break-inside-avoid-page" @highlighted="(n) => (highlightedSerie = n)" :th95="true" />

  </div>
</template>

<script lang="ts" setup>
import { ref, watch } from "vue";
import {
  default as OptionsPanel,
  type ModelType,
} from "./OptionsPanel.vue";
import { flowStore } from "@/stores/flows";
import DataGraph from "@/components/widgets/VisualizePage/DataGraph.vue";
import DataTable from "@/components/widgets/VisualizePage/DataTable.vue";
import { useInterval, useWebSocket } from "@vueuse/core";
import type { GraphLineHandlerResult } from "@/utils";
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('ddos', language.value);

const optionsTime = ref<any>([
  { title: "1 " + translations['hour'], value:1000*60*60 },
  { title: "3 " + translations['hours'], value:3000*60*60 },
  { title: "6 " + translations['hours'], value:6000*60*60 },
  { title: "12 " + translations['hours'], value:12000*60*60 },
  { title: "1 " + translations['day'], value:1000*60*60*24 },
  { title: "3 " + translations['days'], value:3000*60*60*24 }
]);

const useFlow = await flowStore();
const highlightedSerie = ref<number | null>(null);
const selectedTime = ref<any>({ title: "1 " + translations['hour'], value:1000*60*60 });
const visible = ref<boolean>(false);
const updateTimeRange = ([start, end]: [Date, Date]) => {
  if (state.value === null) return;
  state.value = {
    ...state.value,
    start: start.toISOString(),
    end: end.toISOString(),
    humanStart: start.toISOString(),
    humanEnd: end.toISOString(),
  };
};
const now = new Date();
const oneHourBefore = new Date(now);
oneHourBefore.setHours(now.getHours() - 1);
const dataFlow = ref<GraphLineHandlerResult | null>(null)
const refreshOften = useInterval(1_000);
watch([useFlow], async () => {
  await useFlow.store.data
  const now = new Date();
  const interval = Number(now.getTime())-selectedTime.value.value
  const before = new Date(interval)
  dataFlow.value = await {
    ...useFlow.store.data,
    "graphType": "stacked",
    "start": before.toISOString(),
    "end": now.toISOString(),
    "dimensions": useFlow.state.value.dimensions,
    "units": "l3bps",
    "bidirectional": false
  }
})
watch([refreshOften], async () => {
  await useFlow.store.update(await selectedTime.value.value)
  const now = new Date();
  const interval = Number(now.getTime())-(await selectedTime.value.value)
  const before = new Date(interval)
  dataFlow.value = await {
    ...useFlow.store.data,
    "graphType": "stacked",
    "start": before.toISOString(),
    "end": now.toISOString(),
    "dimensions": useFlow.state.value.dimensions,
    "units": "l3bps",
    "bidirectional": false
  }
})

// Main state
const state = ref<ModelType>(null);
const flows = ref<NetworkFlow[]>([])
const table = ref({
  columns: [
    { name: translations['protocol'], classNames: "text-right" },
    { name: translations['avarage'], classNames: "text-right" },
    { name: "Min", classNames: "text-right" },
    { name: "Max", classNames: "text-right" },
    { name: "~95th", classNames: "text-right" },
  ],
  rows: []
})
const protocolStats = ref<Map<number, { count: number, total: number, min: number, max: number }>>(new Map());


// useWebSocket('ws://localhost:5000', {
//   onMessage(ws, event) {
//     try {
//       const flowData: NetworkFlow = JSON.parse(event.data);
//       flows.value.push(flowData)
//       const protocol = flowData.protocol;

//       if (!protocolStats.value.has(protocol)) {
//         protocolStats.value.set(protocol, {
//           count: 0,
//           total: 0,
//           min: Number.MAX_VALUE,
//           max: Number.MIN_VALUE
//         });
//       }

//       const stats = protocolStats.value.get(protocol)!;
//       const meanPs = flowData.bidirectional_mean_ps;

//       stats.count++;
//       stats.total += meanPs;
//       stats.min = Math.min(stats.min, meanPs);
//       stats.max = Math.max(stats.max, meanPs);

//       // Update table rows
//       table.value.rows = Array.from(protocolStats.value).map(([protocol, stats]) => ({
//         values: [
//           { value: `${protocolsNumber[protocol]}(${protocol.toString()})`, classNames: "text-right" },
//           { value: (stats.total / stats.count).toFixed(2), classNames: "text-right" },
//           { value: stats.min.toString(), classNames: "text-right" },
//           { value: stats.max.toString(), classNames: "text-right" },
//           { value: (stats.max * 0.95).toFixed(2), classNames: "text-right" },
//         ],
//         color: "white"
//       }));
//     } catch (error) {
//       console.error("Error parsing WebSocket message:", error);
//     }
//   },
// })

const protocolsNumber = {
  1: "HOPOPT",
  2: "IGMP",
  6: "TCP",
  17: "UDP",
}
</script>
<script lang="ts">
export interface NetworkFlow {
  id: number;
  expiration_id: number;
  src_ip: string;
  src_mac: string;
  src_oui: string;
  src_port: number;
  dst_ip: string;
  dst_mac: string;
  dst_oui: string;
  dst_port: number;
  protocol: number;
  ip_version: number;
  vlan_id: number;
  tunnel_id: number;
  bidirectional_first_seen_ms: number;
  bidirectional_last_seen_ms: number;
  bidirectional_duration_ms: number;
  bidirectional_packets: number;
  bidirectional_bytes: number;
  src2dst_first_seen_ms: number;
  src2dst_last_seen_ms: number;
  src2dst_duration_ms: number;
  src2dst_packets: number;
  src2dst_bytes: number;
  dst2src_first_seen_ms: number;
  dst2src_last_seen_ms: number;
  dst2src_duration_ms: number;
  dst2src_packets: number;
  dst2src_bytes: number;
  bidirectional_min_ps: number;
  bidirectional_mean_ps: number;
  bidirectional_stddev_ps: number;
  bidirectional_max_ps: number;
  src2dst_min_ps: number;
  src2dst_mean_ps: number;
  src2dst_stddev_ps: number;
  src2dst_max_ps: number;
  dst2src_min_ps: number;
  dst2src_mean_ps: number;
  dst2src_stddev_ps: number;
  dst2src_max_ps: number;
  bidirectional_min_piat_ms: number;
  bidirectional_mean_piat_ms: number;
  bidirectional_stddev_piat_ms: number;
  bidirectional_max_piat_ms: number;
  src2dst_min_piat_ms: number;
  src2dst_mean_piat_ms: number;
  src2dst_stddev_piat_ms: number;
  src2dst_max_piat_ms: number;
  dst2src_min_piat_ms: number;
  dst2src_mean_piat_ms: number;
  dst2src_stddev_piat_ms: number;
  dst2src_max_piat_ms: number;
  bidirectional_syn_packets: number;
  bidirectional_cwr_packets: number;
  bidirectional_ece_packets: number;
  bidirectional_urg_packets: number;
  bidirectional_ack_packets: number;
  bidirectional_psh_packets: number;
  bidirectional_rst_packets: number;
  bidirectional_fin_packets: number;
  src2dst_syn_packets: number;
  src2dst_cwr_packets: number;
  src2dst_ece_packets: number;
  src2dst_urg_packets: number;
  src2dst_ack_packets: number;
  src2dst_psh_packets: number;
  src2dst_rst_packets: number;
  src2dst_fin_packets: number;
  dst2src_syn_packets: number;
  dst2src_cwr_packets: number;
  dst2src_ece_packets: number;
  dst2src_urg_packets: number;
  dst2src_ack_packets: number;
  dst2src_psh_packets: number;
  dst2src_rst_packets: number;
  dst2src_fin_packets: number;
  application_name: string;
  application_category_name: string;
  application_is_guessed: number;
  application_confidence: number;
  requested_server_name: string;
  client_fingerprint: string;
  server_fingerprint: string;
  user_agent: string;
  content_type: string;
}
type Units = string;
</script>