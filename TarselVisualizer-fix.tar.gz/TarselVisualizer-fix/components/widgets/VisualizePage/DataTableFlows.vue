<template>
  <div class="flex-1">
    <div class="card flex justify-end">
      <PrimeDrawer v-model:visible="visible" :header="translations['custom_time']" position="right">
        <PrimeListbox v-model="selectedTime" :options="optionsTime" optionLabel="title" class="w-full md:w-56" />
      </PrimeDrawer>
      <PrimeButton class="bg-gray-800 border-[1px] border-gray-50 text-gray-50 hover:bg-gray-50 w-[2rem] h-[2rem]"
        icon="pi pi-hourglass" @click="visible = true"></PrimeButton>
    </div>
    <Suspense>
        <DataGraph autoresize :data="dataFlow" :highlight="highlightedSerie" @update:time-range="updateTimeRange"
          class="h-[20rem]">
        </DataGraph>
      <template #fallback>
        Loading...
      </template>
    </Suspense>
    <div v-if="dimensions.length && $props.rede.length == 1">
      <PrimeMultiSelect v-model="selectedDimensions" :options="listDimensions" optionLabel="name"
        placeholder="Select Dimensions" :maxSelectedLabels="5" class="w-full md:w-80" />
    </div>
    <Suspense>
      <DataTable :th95="false" :data="dataFlow" class="my-2 break-inside-avoid-page"
        @highlighted="(n) => (highlightedSerie = n)" />
      <template #fallback>
        Loading...
      </template>
    </Suspense>

  </div>
</template>

<script lang="ts" setup>
import {
  default as OptionsPanel,
  type ModelType,
} from "./OptionsPanel.vue";
import DataGraph from "@/components/widgets/VisualizePage/DataGraph.vue";
import DataTable from "@/components/widgets/VisualizePage/DataTable.vue";
import { useInterval, useWebSocket } from "@vueuse/core";
import type { GraphLineHandlerResult } from "@/utils";
import { formatIPAddress } from "@/utils/ips";
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('ddos', language.value);

const props = defineProps<{ time: string, rede: string[] }>()
const config = useRuntimeConfig()
const token = useCookie('token')
const id_client = useCookie('id_client')
let fetchController: AbortController | null = null;

const updateTimeRange = ([start, end]: [Date, Date]) => {
  if (state.value === null) return;
  state.value = {
    ...state.value,
    start: start.toISOString(),
    end: end.toISOString(),
    humanStart: start.toISOString(),
    humanEnd: end.toISOString(),
  };
};
const optionsTime = ref<any>([
  { title: translations['custom_time'], value: 1000 * 60 * 60, code: "1h" },
  { title: "3 " + translations['hours'], value: 3000 * 60 * 60, code: "3h" },
  { title: "6 " + translations['hours'], value: 6000 * 60 * 60, code: "6h" },
  { title: "12 " + translations['hours'], value: 12000 * 60 * 60, code: "12h" },
  { title: "1 " + translations['day'], value: 1000 * 60 * 60 * 24, code: "24h" },
  { title: "3 " + translations['days'], value: 3000 * 60 * 60 * 24, code: "72h" }
]);
const selectedTime = ref<any>({ title: "1 hour", value: 1000 * 60 * 60, code: "1h" });
const selectedDimensions = ref<any>([{ name: 'Destination IP', code: 'DstAddr' },
{ name: 'Protocol', code: 'Proto' }])
const listDimensions = ref([
  { name: 'Destination IP', code: 'DstAddr' },
  { name: 'Protocol', code: 'Proto' },
  { name: 'Destination Port', code: 'DstPort' },
  { name: 'Source Port', code: 'SrcPort' },
]);
const dimensions = computed(() => selectedDimensions.value.map(item => item.code))
const getFlows = ref<any>()

const highlightedSerie = ref<number | null>(null);
const visible = ref<boolean>(false);
const dataFlow = ref<GraphLineHandlerResult | null>(null)
const refreshOften = useInterval(5_000);
watch([refreshOften, () => props.rede, selectedDimensions], async () => {
  if (fetchController) {
    fetchController.abort();
  }
  fetchController = new AbortController();

  if (selectedDimensions.value.length == 0) {
    selectedDimensions.value = [{ name: 'Destination IP', code: 'DstAddr' }, { name: 'Protocol', code: 'Proto' }];
  }

  if (props.rede) {
    const end = new Date();
    const start = new Date(end.getTime() - selectedTime.value.value);
    
    const { data } = await useFetch<any>(`${config.public.goServer}/consult/graph`, {
      method: "POST",
      query: {
        "token": `${token.value}`,
        "id_client": id_client.value
      },
      body: {
        "rede": props.rede,
        "end": end.toISOString(),
        "limit": 10,
        "dimensions": selectedDimensions.value ? [...dimensions.value] : ["DstAddr", "Proto"],
        "points": 200,
        "start": start.toISOString()
      },
      signal: fetchController.signal
    });

    // Ensure data.value is not null or undefined
    if (data.value && data.value.rows) {
      const now = new Date();
      const interval = Number(now.getTime()) - selectedTime.value.value;
      const before = new Date(interval);

      if (props.rede.length != 1) {
        data.value.rows = data.value.rows.map((item: string[], i: number) => {
          if (!item.includes('Other')) {
            return [convertIPv6ToIPv4WithCIDR(item[0])];
          }
          return item;
        });
      }

      dataFlow.value = {
        ...data.value,
        "graphType": "lines",
        "start": before.toISOString(),
        "end": now.toISOString(),
        "dimensions": props.rede.length != 1 ? ["DstNetPrefix"] : [...dimensions.value],
        "units": "l3bps",
        "bidirectional": false
      };
    } else {
      console.error("Data fetching returned null or incomplete data.");
    }
  }
}, { immediate: true });

onUnmounted(() => {
  if (fetchController) {
    fetchController.abort();
  }
})
// Main state
const state = ref<ModelType>(null);
const flows = ref<NetworkFlow[]>([])
const table = ref({
  columns: [
    { name: "Protocol", classNames: "text-right" },
    { name: "Average", classNames: "text-right" },
    { name: "Min", classNames: "text-right" },
    { name: "Max", classNames: "text-right" },
    // { name: "~95th", classNames: "text-right" },
  ],
  rows: []
})

function convertIPv6ToIPv4WithCIDR(ipv6WithCIDR: string): string | null {
  // Divide o endereço IPv6 e o prefixo
  const [ipv6, prefix] = ipv6WithCIDR.split('/');
  if (!ipv6 || !prefix) return null;

  // Verifica se o endereço está no formato IPv6 com IPv4 embutido (::ffff:XXXX:XXXX)
  const ipv4Match = ipv6.match(/^::ffff:(\w{4}):(\w{4})$/);
  if (!ipv4Match) {
    return null; // Retorna nulo se o formato não for válido
  }

  // Converte os grupos hexadecimais em decimal
  const hexPart1 = parseInt(ipv4Match[1], 16);
  const hexPart2 = parseInt(ipv4Match[2], 16);

  // Monta o endereço IPv4
  const ipv4Address = `${(hexPart1 >> 8) & 0xff}.${hexPart1 & 0xff}.${(hexPart2 >> 8) & 0xff}.${hexPart2 & 0xff}`;

  // Converte o prefixo para um valor equivalente em IPv4
  const ipv4Prefix = parseInt(prefix) - 96;

  return `${ipv4Address}/${ipv4Prefix}`;
}
</script>