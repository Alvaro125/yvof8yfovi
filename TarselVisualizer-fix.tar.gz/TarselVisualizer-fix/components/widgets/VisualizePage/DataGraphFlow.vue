<template>
  <div class="h-[20rem]">
      <VChart class="chart" :option="chartConfig" />
  </div>
</template>

<script lang="ts" setup>
import { LineChart } from 'echarts/charts'
import {
  GridComponent,
  LegendComponent,
  TitleComponent,
  TooltipComponent,
  MarkLineComponent
} from 'echarts/components'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { computed, ref } from 'vue'
import VChart from 'vue-echarts'
import { NetworkFlow } from '@/components/widgets/VisualizePage/DataTableFlow.vue';
const props = defineProps<{
  data: NetworkFlow[];
}>();
use([
  CanvasRenderer,
  LineChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
    GridComponent,
    MarkLineComponent
])

function convertToChartConfig(flows: NetworkFlow[]) {
  // Ordenar os fluxos por tempo
  flows.sort((a, b) => a.bidirectional_first_seen_ms - b.bidirectional_first_seen_ms);

  // Extrair e formatar dados do eixo x (tempo em HH:mm:ss)
  const formatTime = (ms: number) => {
    const date = new Date(ms);
    const hours = date.getUTCHours().toString().padStart(2, '0');
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    const seconds = date.getUTCSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  };
  
  const xAxisData = Array.from(new Set(flows.map(flow => formatTime(flow.bidirectional_first_seen_ms)))).sort();

  // Agrupar os fluxos por protocolo
  const groupedByProtocol: Record<number, NetworkFlow[]> = flows.reduce((acc, flow) => {
    if (!acc[flow.protocol]) {
      acc[flow.protocol] = [];
    }
    acc[flow.protocol].push(flow);
    return acc;
  }, {} as Record<number, NetworkFlow[]>);

  // Criar séries para cada protocolo, garantindo que cada tempo tenha um valor
  const series = Object.keys(groupedByProtocol).map(protocol => {
    const protocolFlows = groupedByProtocol[Number(protocol)];
    const dataMap = new Map(protocolFlows.map(flow => [formatTime(flow.bidirectional_first_seen_ms), flow.bidirectional_bytes]));
    const bidirectionalBytes = xAxisData.map(time => dataMap.get(time) ?? 0);

    return {
      name: `Protocol ${protocol}`,
      type: 'line',
      stack: 'Total',
      areaStyle: {},
      emphasis: {
        focus: 'series'
      },
      data: bidirectionalBytes
    };
  });

  return {
    title: {
      text: 'Stacked Area Chart'
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      }
    },
    legend: {
      data: series.map(s => s.name)
    },
    toolbox: {
      feature: {
        saveAsImage: {}
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: xAxisData
      }
    ],
    yAxis: [
      {
        type: 'value'
      }
    ],
    series: series
  };
}

const chartConfig = computed(()=>convertToChartConfig(props.data));

</script>