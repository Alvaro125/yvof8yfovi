<template>
  <div>
    <!-- Axis selection -->
    <div v-if="axes && axes.length > 1"
      class="border-b border-gray-200 text-center text-sm font-medium text-gray-500 dark:border-gray-700 dark:text-gray-400">
      <ul class="flex flex-wrap">
        <li v-for="{ id: axis, name } in axes" :key="axis" class="mr-2">
          <button
            class="pointer-cursor inline-block rounded-t-lg border-b-2 border-transparent p-4 hover:border-gray-300 hover:text-gray-600 dark:hover:text-gray-300"
            :class="{
              'active border-blue-600 text-blue-600 dark:border-blue-500 dark:text-blue-500':
                displayedAxis === axis,
            }" :aria-current="displayedAxis === axis ? 'page' : undefined" @click="selectedAxis = axis">
            {{ name }}
          </button>
        </li>
      </ul>
    </div>
    <!-- Table -->
    <div class="relative overflow-x-auto shadow-md dark:shadow-white/10 sm:rounded-lg">
      <table v-if="table" id="my-table" class="w-full max-w-full text-left text-sm text-gray-700 dark:text-gray-200">
        <thead class="bg-gray-50 text-xs uppercase dark:bg-zinc-500">
          <div v-if="!props.open" class="absolute h-8 flex items-center w-12 justify-center">
            <button :class="open ? 'pi pi-angle-down' : 'pi pi-angle-up'" @click="open = !open"></button>
          </div>
          <tr>
            <th scope="col" :class="{ 'px-6 py-2': table.rows.some((r) => r.color) }"
              v-if="props.data.graphType != 'sankey'"></th>
            <th v-for="(column, index) in table.columns" :key="column.name" scope="col" class="px-6 py-2"
              :class="column.classNames">
              <button class="flex justify-center space-x-1 text-center w-full" @click="sortTable(index)">
                <span>{{ column.name }}</span>
                <span v-if="sortConfig.key === index">
                  <span v-if="sortConfig.direction === 'asc'" class="pi pi-sort-amount-down-alt">
                  </span>
                  <span v-else class="pi pi-sort-amount-up">
                  </span>
                </span>
                <span v-else class="pi pi-sort-alt"></span>
              </button>
            </th>
          </tr>
        </thead>
        <tbody v-if="open">
          <tr v-for="(row, index) in sortedRows" :key="index"
            class="border-b odd:bg-white even:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 odd:dark:bg-zinc-800 even:dark:bg-zinc-700"
            @pointerenter="highlight(index)" @pointerleave="highlight(null)">
            <th scope="row" class="text-center" v-if="props.data.graphType != 'sankey'">
              <div v-if="row.color" class="px-6 py-2 text-center font-medium">
                <div class="relative flex items-center justify-center">
                  <div class="z-10 w-3 h-3 cursor-pointer rounded-full absolute" :style="{
                    backgroundColor: row.color,
                    printColorAdjust: 'exact',
                  }"></div>
                  <div class="w-8 h-1 absolute" :style="{
                    backgroundColor: row.color,
                    printColorAdjust: 'exact',
                  }"></div>
                </div>
              </div>
            </th>
            <td v-for="(value, idx) in row.values" :key="idx" class="px-6 py-2 text-center" :class="value.classNames">
              {{ value.value }}
            </td>
          </tr>
          <tr
            class="border-b odd:bg-white even:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 odd:dark:bg-zinc-800 even:dark:bg-zinc-700"
            v-if="props.data.graphType != 'sankey'">
            <th scope="row" class="text-center">
              <div class="px-6 py-2 text-center font-medium">
                <div class="relative flex items-center justify-center">
                  <div class="z-10 w-3 h-3 cursor-pointer rounded-full absolute" :style="{
                    printColorAdjust: 'exact',
                  }">Total</div>
                </div>
              </div>
            </th>
            <td v-for="(value, idx) in total" :key="idx" class="px-6 py-2 text-center" :class="value.classNames">
              {{ value }}
            </td>
          </tr>
          <tr
            class="border-b odd:bg-white even:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 odd:dark:bg-zinc-800 even:dark:bg-zinc-700"
            v-else>
            <td v-for="(value, idx) in total" :key="idx" class="px-6 py-2 text-center" :class="value.classNames">
              {{ value }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, inject, ref } from "vue";
import { uniqWith, isEqual, findIndex, takeWhile, toPairs } from "lodash-es";
import { dataColor, dataColorGrey } from "@/utils/palette";
import { formatXps } from "@/utils/index";
import { ThemeKey } from "@/components/ThemeProvider.vue";
import type { GraphLineHandlerResult, GraphSankeyHandlerResult } from ".";
const { isDark } = inject(await ThemeKey)!;

const props = withDefaults(
  defineProps<{
    data: GraphLineHandlerResult | GraphSankeyHandlerResult | null;
    th95: boolean;
    open?: boolean;
    limit?: number;
  }>(),
  {
    open: true,
    limit: 10,
  },
);
const emit = defineEmits<{
  highlighted: [index: number | null];
}>();
const open = ref<boolean>(props.open)
const highlight = (index: number | null) => {
  if (
    index === null ||
    props.data == null ||
    props.data.graphType == "sankey"
  ) {
    emit("highlighted", null);
    return;
  }
  // The index provided is the one in the filtered data. We want the original index.
  const axis = props.data.axis;
  const originalIndex = takeWhile(
    props.data.rows,
    (() => {
      let count = 0;
      return (_, idx) => axis[idx] != displayedAxis.value || count++ < index;
    })(),
  ).length;
  emit("highlighted", table.value?.rows.indexOf(sortedRows.value[originalIndex]) as number);
};
const axes = computed(() => {
  if (!props.data || props.data.graphType === "sankey") return null;
  return toPairs(props.data["axis-names"])
    .map(([k, v]) => ({ id: Number(k), name: v }))
    .filter(({ id }) => [1, 2].includes(id))
    .sort(({ id: id1 }, { id: id2 }) => id1 - id2);
});
const selectedAxis = ref(1);
const displayedAxis = computed(() => {
  if (!axes.value) return null;
  return axes.value.some((axis) => axis.id === selectedAxis.value)
    ? selectedAxis.value
    : 1;
});
const sortConfig = ref<{ key: number; direction: string }>({
  key: -1,
  direction: 'asc'
});
const parseFormattedValue = (value: string): number => {
  const suffixes = ["", "K", "M", "G", "T", "P", "Ex", "Z"];
  const regex = /^([\d.]+)([a-zA-Z]*)$/;
  const match = value.match(regex);

  if (!match) return parseFloat(value); // Retorna o valor numérico puro, se não houver sufixo

  const [, num, suffix] = match;
  const factor = Math.pow(1000, suffixes.indexOf(suffix[0]));
  return parseFloat(num) * factor;
};

const sortedRows = computed(() => {
  if (!table.value) return [];
  if (!props.data || props.data.graphType === "sankey") {
    const { key, direction } = sortConfig.value;
    const rowsToSort = table.value.rows.slice(0,props.limit);

    if (key === -1) return rowsToSort;

    return [...rowsToSort].sort((a, b) => {
      const aValue = a.values[key]?.value || "";
      const bValue = b.values[key]?.value || "";

      const aNum = parseFormattedValue(aValue);
      const bNum = parseFormattedValue(bValue);

      if (aNum < bNum) return direction === "asc" ? -1 : 1;
      if (aNum > bNum) return direction === "asc" ? 1 : -1;
      return 0;
    });
  } else {
    const { key, direction } = sortConfig.value;
    const rowsToSort = table.value.rows.filter(
      (_, idx) => props.data.axis[idx] == displayedAxis.value
    );

    if (key === -1) return rowsToSort;

    return [...rowsToSort].sort((a, b) => {
      const aValue = a.values[key]?.value || "";
      const bValue = b.values[key]?.value || "";

      const aNum = parseFormattedValue(aValue);
      const bNum = parseFormattedValue(bValue);

      if (aNum < bNum) return direction === "asc" ? -1 : 1;
      if (aNum > bNum) return direction === "asc" ? 1 : -1;
      return 0;
    });
  }
});

const sortTable = (key: number) => {
  if (sortConfig.value.key === key) {
    sortConfig.value.direction = sortConfig.value.direction === "asc" ? "desc" : "asc";
  } else {
    sortConfig.value.key = key;
    sortConfig.value.direction = "asc";
  }
};
const total = computed(() => {
  if (props.data && props.data.dimensions) {
    if (props.data.graphType != 'sankey') {
      const unit = ["inl2%", "outl2%"].includes(props.data.units)
        ? "%"
        : props.data.units.slice(-3);
      const totalLine = props.data.points[props.data.points.length - 1]
      return [...Array(props.data.dimensions.length).fill("..."),
      `${formatXps(Math.min(...totalLine.slice(0, -1)))}${unit}`,
      `${formatXps(Math.max(...totalLine))}${unit}`,
      `${formatXps(props.data.average[props.data.average.length - 1])}${unit}`,
      `${formatXps(props.data['95th'][props.data['95th'].length - 1])}${unit}`
      ]
    } else {
      const unit = ["inl2%", "outl2%"].includes(props.data.units)
        ? "%"
        : props.data.units.slice(-3);
      return [...Array(props.data.dimensions.length).fill("Total"),
      `${formatXps(props.data.xps.reduce((ac, v) => ac + v, 0))}${unit}`,
      ]
    }
  }
  return []
})
const table = computed(
  (): {
    columns: { name: string; classNames?: string }[];
    rows: {
      values: { value: string; classNames?: string }[];
      color?: string;
    }[];
  } | null => {
    const theme = isDark.value ? "dark" : "light";
    const data = props.data;
    if (data === null) return null;
    data.units = undefined ? "bps" : data.units;
    const unit = ["inl2%", "outl2%"].includes(data.units)
      ? "%"
      : data.units.slice(-3);
    const formatValue = (v: number): string =>
      unit === "%" ? `${v.toFixed(0)}%` : `${formatXps(v)}${unit}`;
    if (
      data.graphType === "stacked" ||
      data.graphType === "stacked100" ||
      data.graphType === "lines" ||
      data.graphType === "grid"
    ) {
      const uniqRows = uniqWith(data.rows, isEqual),
        uniqRowIndex = (row: string[]) =>
          findIndex(uniqRows, (orow) => isEqual(row, orow));
      return {
        columns: props.th95 ? [
          // Dimensions
          ...(data.dimensions.map((col) => ({
            name: col.replace(/([a-z])([A-Z])/g, "$1 $2"),
          })) || []),
          // Stats
          { name: "Min", classNames: "text-center" },
          { name: "Max", classNames: "text-center" },
          { name: "Average", classNames: "text-center" },
          { name: "~95th", classNames: "text-center" },
        ] : [
          // Dimensions
          ...(data.dimensions.map((col) => ({
            name: col.replace(/([a-z])([A-Z])/g, "$1 $2"),
          })) || []),
          // Stats
          { name: "Min", classNames: "text-center" },
          { name: "Max", classNames: "text-center" },
          { name: "Average", classNames: "text-center" },
          // { name: "~95th", classNames: "text-center" },
        ],
        rows:
          data.rows
            .map((row, idx) => {
              const color =
                data.graphType === "grid"
                  ? dataColorGrey
                  : dataColor;
              return {
                values: props.th95 ? [
                  // Dimensions
                  ...row.map((r) => ({ value: r })),
                  // Stats
                  ...[
                    data.min[idx],
                    data.max[idx],
                    data.average[idx],
                    data["95th"][idx],
                  ].map((d) => ({
                    value: formatValue(d),
                    classNames: "text-center tabular-nums",
                  })),
                ] : [
                  // Dimensions
                  ...row.map((r) => ({ value: r })),
                  // Stats
                  ...[
                    data.min[idx],
                    data.max[idx],
                    data.average[idx],
                    // data["95th"][idx],
                  ].map((d) => ({
                    value: formatValue(d),
                    classNames: "text-center tabular-nums",
                  })),
                ],
                color: color(uniqRowIndex(row), false, theme),
              };
            })
            .filter((_, idx) => data.axis[idx] == displayedAxis.value) || [],
      };
    } else if (data.graphType === "sankey") {
      return {
        columns: [
          // Dimensions
          ...(data.dimensions?.map((col) => ({
            name: col.replace(/([a-z])([A-Z])/g, "$1 $2"),
          })) || []),
          // Average
          { name: "Average", classNames: "text-center" },
        ],
        rows: data.rows?.map((row, idx) => ({
          values: [
            // Dimensions
            ...row.map((r) => ({ value: r })),
            // Average
            {
              value: formatValue(data.xps[idx]),
              classNames: "text-center tabular-nums",
            },
          ],
        })),
      };
    }
    return null;
  },
);
</script>
