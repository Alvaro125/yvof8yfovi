<template>
  <div>
    <h1 class="font-semibold leading-relaxed">Last flow</h1>
    <div class="h-[300px]">
      <v-chart :option="option"/>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { inject, computed, ref, watch } from "vue";
import { filterStore } from "../../../stores/filters";
import { useFetch } from "@vueuse/core";
import { formatXps } from "@/utils";
import { dataColor, dataColorGrey } from "@/utils/palette";
import { ThemeKey } from "../../ThemeProvider.vue";
import { use, type ComposeOption } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { SankeyChart, type SankeySeriesOption } from "echarts/charts";
import {
  TooltipComponent,
  type TooltipComponentOption,
  type GridComponentOption,
} from "echarts/components";
import type { TooltipCallbackDataParams } from "echarts/types/src/component/tooltip/TooltipView";
import VChart from "vue-echarts";
use([CanvasRenderer, SankeyChart, TooltipComponent]);
const useFilter = await filterStore();
type ECOption = ComposeOption<
  SankeySeriesOption | TooltipComponentOption | GridComponentOption
>;
const { isDark } = inject(await ThemeKey)!;

const props = withDefaults(
  defineProps<{
    refresh?: number;
  }>(),
  {
    refresh: 0,
  },
);

interface NetworkFlow {
  TimeReceived: number;
  SamplingRate: number;
  ExporterAddress: string;
  InIf: number;
  OutIf: number;
  SrcVlan: number;
  DstVlan: number;
  SrcAddr: string;
  DstAddr: string;
  NextHop: string;
  SrcAS: number;
  DstAS: number;
  GotASPath: boolean;
  SrcNetMask: number;
  DstNetMask: number;
}
use([CanvasRenderer, SankeyChart, TooltipComponent]);

const flows = ref<any>([])

const url = computed(() => `/api/v0/inlet/flows?limit=${25}`);
useFetch(url,{immediate:true})
  .get().text()
  .then(async (dt) => {
    flows.value = await convertNetworkFlows(
      (dt.data.value as string)
        ?.trim().split('\n').map(line => JSON.parse(line))
    )
  })
function convertNetworkFlows(networkFlows: NetworkFlow[]) {
  const rows: string[][] = [];
  const xps: number[] = [];
  const nodesSet = new Set<string>();
  const links: { source: string; target: string; xps: number }[] = [];

  networkFlows?.forEach(flow => {
    const srcNode = findAs(`${flow.SrcAS}`)
    const findDstNode = findAs(`${flow.DstAS}`)
    const dstNode = findDstNode == "Other" ? flow.DstAddr : findDstNode;

    // Add nodes to the set
    nodesSet.add(`SrcAS: ${srcNode}`);
    nodesSet.add(`DstAddr: ${dstNode}`);

    // Add rows and xps
    rows.push([srcNode, dstNode]);
    xps.push(flow.SamplingRate);

    // Add links
    links.push({
      source: `SrcAS: ${srcNode}`,
      target: `DstAddr: ${dstNode}`,
      xps: flow.SamplingRate,
    });
  });

  const nodes = Array.from(nodesSet);

  return { rows, xps, nodes, links };
}
function findAs(subtext: string) {
  if (useFilter.srcAs) {
    const asSrc = [...(useFilter.srcAs)].filter(text => text[0].includes(subtext));
    return asSrc.length ? asSrc[0] : "Other"
  }
  return null;
}
watch(()=>props.refresh, async () => {
  const { data, execute } = useFetch(url, { immediate: true }).get().text();
  await execute();
  if (await data.value) {
    console.log(await data)
    flows.value = convertNetworkFlows(
      (await data.value as string).trim().split('\n').map(line => JSON.parse(line))
    )
  }
}, {immediate: true})
let option = computed((): ECOption => {
  const theme = isDark.value ? "dark" : "light";
  const _data = flows.value || {};
  if (!_data.xps) return {};
  let greyNodes = 0;
  let colorNodes = 0;
  return {
    backgroundColor: "transparent",
    tooltip: {
      confine: true,
      trigger: "item",
      triggerOn: "mousemove",
      formatter(params) {
        if (Array.isArray(params)) return "";
        const { dataType, marker, data, value } =
          params as TooltipCallbackDataParams;
        if (dataType === "node") {
          const nodeData = data as NonNullable<SankeySeriesOption["nodes"]>[0];
          return [
            marker,
            `<span style="display:inline-block;margin-left:1em;">${nodeData.name}</span>`,
            `<span style="display:inline-block;margin-left:2em;font-weight:bold;">${formatXps(
              value.valueOf() as number,
            )}`,
          ].join("");
        } else if (dataType === "edge") {
          const edgeData = data as NonNullable<SankeySeriesOption["edges"]>[0];
          const source =
            edgeData.source?.toString().split(": ").slice(1).join(": ") ??
            "???";
          const target =
            edgeData.target?.toString().split(": ").slice(1).join(": ") ??
            "???";
          return value
            ? [
              `${source} → ${target}`,
              `<span style="display:inline-block;margin-left:2em;font-weight:bold;">${formatXps(
                value.valueOf() as number,
              )}`,
            ].join("")
            : "";
        }
        return "";
      },
      valueFormatter: (value) => formatXps(value.valueOf() as number),
    },
    series: [
      {
        type: "sankey",
        animationDuration: 500,
        emphasis: {
          focus: "trajectory",
        },
        data: _data.nodes.map((v) => ({
          id: v,
          name: v.split(": ").slice(1).join(": "),
          itemStyle: {
            color: v.endsWith(" Other")
              ? dataColorGrey(greyNodes++, false, theme)
              : dataColor(colorNodes++, false, theme),
          },
        })),
        links: _data.links.map(({ source, target, xps }) => ({
          source,
          target,
          value: xps,
        })),
        label: {
          formatter: "{b}",
        },
        lineStyle: {
          color: "gradient",
          curveness: 0.5,
        },
      },
    ],
  };
});
</script>
