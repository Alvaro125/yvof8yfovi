<template>
  <div v-if="isModalVisible" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50" @click.self="closeModal">
    <div class="w-4/5 h-[575px] bg-white p-6 rounded shadow-lg  dark:bg-slate-800">
      <form @submit.prevent="request()">
        <div class="flex flex-row justify-between">
          <h1 class="text-xl">{{ planName }}</h1>
          <div class="flex flex-row space-x-4">
            <PrimeButton size="small" class="h-7 w-20 opacity-80" type="button" :label="translations['cancel']" severity="danger" @click="closeModal"></PrimeButton>
            <PrimeButton size="small" class="h-7 w-20 opacity-80" type="submit" :label="translations['save']" severity="success"></PrimeButton>
          </div>
        </div>
        <div class="my-2">
          <button :class="['mr-2', activeTab === 'Capacity Computation' ? 'border-b-4 border-blue-700 text-blue-700' : 'border-hidden']"
          @click.prevent="changeTab('Capacity Computation')"
          >{{ translations['capacity_computation'] }}</button>
          <button :class="['mx-2', activeTab === 'Interfaces' ? 'border-b-4 border-blue-700 text-blue-700' : 'border-hidden']"
          @click.prevent="changeTab('Interfaces')"
          >{{ translations['interfaces'] }}</button>
        </div>
        <div v-if="activeTab === 'Capacity Computation'">
          <div class="flex flex-col mb-4">
            <label for="planName" class="text-sm">{{ translations['name'] }}:</label>
            <PrimeInputText id="planName" v-model="planNameInput" class="h-8 border-gray-300 bg-white dark:bg-slate-800" required></PrimeInputText>
          </div>
          <div class="flex flex-col mb-4">
            <label for="description" class="text-sm">{{ translations['description'] }}:</label>
            <Textarea id="description" v-model="planDescription" rows="4" cols="30" class="border-gray-300 bg-white dark:bg-slate-800" />
          </div>
          <div class="border border-gray-300 rounded-lg p-5 relative">
            <span class="absolute -top-3 left-3 text-sm px-2 bg-white dark:bg-slate-800">{{ translations['thresholds'] }}</span>
            <div class="flex flex-col mb-5">
              <label for="runout" class="text-sm">Runout:</label>
              <div class="flex flex-row w-full mt-2">
                <InputListBox v-model="selectedInterval" :items="selectedIntervalList" :label="translations['select_interval']" class="grow basis-full mr-10">
                  <template #selected>{{ selectedInterval.name }}</template>
                  <template #item="{ name }">
                    <span>{{ name }}</span>
                  </template>
                </InputListBox>
                <div>
                  <div class="relative w-[800px]">
                    <div class="absolute" :style="{ left: `${(runout[0]-1)*0.9*10+0.3}%` }">
                      <span class="w-[29px] bg-blue-500 text-white text-xs text-center px-2 py-1 rounded absolute -top-10 left-1/2 transform -translate-x-1/2">
                        {{ runout[0] }}
                      </span>
                    </div>
                    <div class="absolute" :style="{ left: `${(runout[1]-1)*0.9*10+0.3}%` }">
                      <span class="w-[29px] bg-blue-500 text-white text-xs text-center px-2 py-1 rounded absolute -top-10 left-1/2 transform -translate-x-1/2">
                        {{ runout[1] }}
                      </span>
                    </div>
                    <Slider id="runout" v-model="runout" :min="1" :max="12" :step="1" :range="true" class="mt-4 w-[800px]" />
                  </div>
                  <div class="relative w-[805px] mt-2">
                    <div class="flex justify-between absolute inset-x-0 -left-1.5">
                      <span v-for="n in 12" :key="n" class="text-[10px] w-3 text-center">{{ n }}</span>
                    </div>
                  </div>
                </div>    
              </div>
            </div>
            <div class="flex flex-col mb-5">
              <label for="utilization" class="text-sm">{{ translations['utilization'] }}:</label>
              <div class="flex flex-row w-full mt-2 justify-end">
                <div class="relative left-2.5">
                  <div class="relative w-[800px]">
                    <div class="absolute" :style="{ left: `${utilization[0]}%` }">
                      <span class="bg-blue-500 text-white text-xs px-2 py-1 rounded absolute -top-10 left-1/2 transform -translate-x-1/2">
                        {{ utilization[0] }}%
                      </span>
                    </div>
                    <div class="absolute" :style="{ left: `${utilization[1]}%` }">
                      <span class="bg-blue-500 text-white text-xs px-2 py-1 rounded absolute -top-10 left-1/2 transform -translate-x-1/2">
                        {{ utilization[1] }}%
                      </span>
                    </div>
                    <Slider id="utilization" v-model="utilization" :min="0" :max="100" :step="1" :range="true" class="mt-4 w-[800px]" />
                  </div>
                  <div class="relative w-[815px] mt-2">
                    <div class="flex justify-between absolute inset-x-0">
                      <span v-for="n in 11" :key="n" class="text-[10px]">{{ (n - 1) * 10 }}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script lang="ts" setup>
import Textarea from 'primevue/textarea';
import Slider from 'primevue/slider';
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('capacity_planning_page', language.value);
const config = useRuntimeConfig();
const token = useCookie<string>("token");
const toast = useToast();
const emit = defineEmits(["refresh", "update:openModalNewPlan", "update:openModalEditPlan"]);
const props = defineProps<{
  newPlan?: boolean;
  editPlan?: boolean;
  planID?: any;
}>()

const isModalVisible = ref<boolean>(false);
const isNewPlan = ref<boolean>(true);

const planNameInput = ref('');
const planName = ref(translations['new_plan']);
const planDescription = ref('');
const selectedIntervalList = [{id: 1, value: 'Days', name: translations['days']}, {id: 2, value: 'Weeks', name: translations['weeks']}, {id: 3, value: 'Months', name: translations['months']}]
const selectedInterval = ref(selectedIntervalList[0]);
const runout = ref<{ 0: number; 1: number }>({ 0: 1, 1: 12 });
const utilization = ref<{ 0: number; 1: number }>({ 0: 0, 1: 100 });

watch(() => props.editPlan, async () => {
  if(props.editPlan) {
    isNewPlan.value = false;
    openModal();
    await loadPlanInfo(props.planID);
  } else {
    isNewPlan.value = true;
  }
});
watch([() => props.newPlan], async () => {
  if (props.newPlan) {
    openModal();
  }
});

watch(runout, (newValue: { 0: number; 1: number }, oldValue: { 0: number; 1: number }) => {
  if (newValue[0] >= newValue[1]) {
    runout.value[0] = oldValue[0];
  } 
  if (newValue[1] <= newValue[0]) {
    runout.value[1] = oldValue[1];
  }
});
watch(utilization, (newValue: { 0: number; 1: number }, oldValue: { 0: number; 1: number }) => {
  if (newValue[0] >= newValue[1] - 9) {
    utilization.value[0] = oldValue[0];
  } 
  if (newValue[1] <= newValue[0] + 9) {
    utilization.value[1] = oldValue[1];
  }
});

const resetForm = () => {
  planName.value = translations['new_plan'];
  planNameInput.value = '';
  planDescription.value = '';
  selectedInterval.value = selectedIntervalList[0];
  runout.value = { 0: 1, 1: 12 };
  utilization.value = { 0: 0, 1: 100 };
};

const request = async () => {
  if(isNewPlan.value) {
    await newPlan();
  } else {
    await updatePlan(props.planID);
  }
}

const convertTime = (selectedInterval: string) => {
  let selectedIntervalMedium;
  let selectedIntervalHigh;
  
  if (selectedInterval === 'Days') {
    selectedIntervalMedium = runout.value[0];
    selectedIntervalHigh = runout.value[1];
  } else if (selectedInterval === 'Weeks') {
    selectedIntervalMedium = runout.value[0] * 7;
    selectedIntervalHigh = runout.value[1] * 7;
  } else if (selectedInterval === 'Months') {
    selectedIntervalMedium = runout.value[0] * 30;
    selectedIntervalHigh = runout.value[1] * 30;
  }

  return [selectedIntervalMedium, selectedIntervalHigh] 
}

const calculateTimeInterval = (mediumRunout: number, highRunout: number) => {
  let timeNumber: Array<number>;
  const Days = [1,2,3,4,5,6,7,8,9,10,11,12];
  const Weeks = [7,14,21,28,35,42,49,56,63,70,77,84];
  const Months = [30,60,90,120,150,180,210,240,270,300,330,360];

  if(Days.includes(mediumRunout) && Days.includes(highRunout)) {
    selectedInterval.value = selectedIntervalList[0];
    timeNumber = [mediumRunout, highRunout];
  } else if(Weeks.includes(mediumRunout) && Weeks.includes(highRunout)) {
    selectedInterval.value = selectedIntervalList[1];
    timeNumber = [mediumRunout/7, highRunout/7];
  } else if(Months.includes(mediumRunout) && Months.includes(highRunout)) {
    selectedInterval.value = selectedIntervalList[2];
    timeNumber = [mediumRunout/30, highRunout/30];
  } else {
    timeNumber = [1, 12];
  }
  return timeNumber;
}

const newPlan = async () => {
  const time = convertTime(selectedInterval.value.value)

  if(planNameInput.value === '') return

  try {
    const data = await $fetch(`${config.public.apiFastApi}/capacity_planning/new_plan`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token.value}`
      },
      body: {
        "plan_name": planNameInput.value,
        "description": planDescription.value,
        "interface_ids": [2, 4],
        "medium_threshold_runout": time[0],
        "high_threshold_runout": time[1],
        "medium_threshold_utilization": utilization.value[0],
        "high_threshold_utilization": utilization.value[1]
      }
    });
    
    toast.add({ severity: 'success', summary: translations['confirmed'], detail: translations['plan_created'], life: 3000 });
    emit('refresh', true);
    resetForm();
    closeModal();
    
  } catch (error) {
    console.error("Erro ao criar o plano:", error);
    resetForm();
    toast.add({ severity: 'error', summary: translations['rejected'], detail: translations['plan_create_error'], life: 3000 });
  }
};

const loadPlanInfo = async (planID: number) => {
  try {
    const data = await $fetch(`${config.public.apiFastApi}/capacity_planning/get_plan/${planID}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token.value}`
      },
    })

    const timeNumber = calculateTimeInterval(parseInt(data[0].medium_threshold_runout), parseInt(data[0].high_threshold_runout));

    planNameInput.value = data[0].plan_name;
    planName.value = data[0].plan_name;
    planDescription.value = data[0].description;
    runout.value = { 0: timeNumber[0], 1: timeNumber[1] };
    utilization.value = { 0: parseInt(data[0].medium_threshold_utilization), 1: parseInt(data[0].high_threshold_utilization) };

  } catch (error) {
    console.error("Erro ao carregar os dados do plano:", error);
  }
}

const updatePlan = async (planID: number | undefined) => {
  const time = convertTime(selectedInterval.value.value)

  if(planNameInput.value === '') return

  try {
    const data = await $fetch(`${config.public.apiFastApi}/capacity_planning/update_plan/${planID}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token.value}`
      },
      body: {
        "plan_name": planNameInput.value,
        "description": planDescription.value,
        "interface_ids": [2, 4],
        "medium_threshold_runout": time[0],
        "high_threshold_runout": time[1],
        "medium_threshold_utilization": utilization.value[0],
        "high_threshold_utilization": utilization.value[1]
      }
    });

    toast.add({ severity: 'success', summary: translations['confirmed'], detail: translations['plan_saved'], life: 3000 });
    emit('refresh', true);
    resetForm();
    closeModal();

  } catch (error) {
    console.error("Erro ao editar plano:", error);
    resetForm();
    toast.add({ severity: 'error', summary: translations['rejected'], detail: translations['plan_save_error'], life: 3000 });
  }
};

const openModal = () => {
  isModalVisible.value = true;
  resetForm();
}

const closeModal = () => {
  isModalVisible.value = false;
  resetForm();
  if (props.newPlan) {
    emit('update:openModalNewPlan');
  }
  if (props.editPlan) {
    emit('update:openModalEditPlan');
  }
}

const activeTab = ref('Capacity Computation');
const changeTab = (tabName: string) => {
  activeTab.value = tabName;
}

</script>
