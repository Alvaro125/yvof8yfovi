<template>
  <div class="w-full px-5 pb-5 pt-1 grid grid-cols-3">
    <div v-for="([deviceName, deviceInfo], index) in Object.entries(devices)" :key="index">
      <div class="w-96 m-5 p-3 border border-solid rounded border-gray-400 dark:border-slate-600 overflow-hidden">
        <span class="font-bold text-xl mb-2 hover:cursor-pointer" @click="PopTable(deviceInfo.planning_id, deviceName);dialogVisible = true" >{{ deviceName }}</span>
        <div class="flex justify-between mt-3">
          <div class="flex justify-between w-44">
            <p class="text-sm">{{ translations['interfaces'] }}:</p>
            <p class="text-sm text-right">{{ deviceInfo.interface_count }} |</p>
          </div>
          <div class="flex justify-between w-44">
            <p class="text-sm">Runout:</p>
            <p class="text-sm text-right">{{ formatRunout(deviceInfo.runout) }}</p>
          </div>
        </div>
        <div class="flex justify-between">
          <div class="flex justify-between w-44">
            <p class="text-sm">{{ translations['total_capacity'] }}:</p>
            <p class="text-sm text-right">{{ deviceInfo.total_capacity }} |</p>
          </div>
          <div class="flex justify-between w-44">
            <p class="text-sm">{{ translations['utilization'] }}:</p>
            <p class="text-sm text-right">{{ deviceInfo.max_use }}%</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <PrimeDialog v-model:visible="dialogVisible" :header="planName" :style="{ width: '75vw' }" maximizable modal
    :contentStyle="{ height: '300px' }">
    <PrimeConfirmDialog></PrimeConfirmDialog>
    <PrimeDataTable :value="infoTable" scrollable scrollHeight="flex" tableStyle="min-width: 50rem">
      <div class="flex flex-row justify-end">
        <PrimeButton size="small" class="h-6 opacity-80 mr-3" type="submit" :label="translations['edit_capacity_plan']" severity="success" @click="editPlan(planID)"></PrimeButton>
        <PrimeButton size="small" class="h-6 opacity-80" type="button" :label="translations['delete_capacity_plan']" severity="danger" @click="confirmDelete(planID)"></PrimeButton>
      </div>
      <PrimeColumn field="interface_name" :header="translations['interface']"></PrimeColumn>
      <PrimeColumn field="bandwith_capacity" :header="translations['capacity']"></PrimeColumn>
      <PrimeColumn field="interface_id" :header="translations['site']"></PrimeColumn>
      <PrimeColumn field="interface_id" :header="translations['device']"></PrimeColumn>
      <PrimeColumn field="interface_type" :header="translations['network_boundary']"></PrimeColumn>
      <PrimeColumn field="interface_id" :header="translations['connecivity_type']"></PrimeColumn>
      <PrimeColumn field="interface_id" :header="translations['provider']"></PrimeColumn>
      <PrimeColumn field="interface_id" :header="translations['traffic']"></PrimeColumn>
      <PrimeColumn field="current_use" :header="translations['utilization']"></PrimeColumn>
      <PrimeColumn field="interface_id" header="Runout"></PrimeColumn>
      <PrimeColumn :header="translations['trend']" style="min-width: 200px">
        <template #body="{ data }">
            <p>{{data.interface_name}}</p>
        </template>
    </PrimeColumn>
    </PrimeDataTable>
    <template #footer>
      <PrimeButton label="Ok" icon="pi pi-check" @click="dialogVisible = false" />
    </template>
  </PrimeDialog>
</template>

<script lang="ts" setup>
import { useConfirm } from "primevue/useconfirm";
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('capacity_planning_page', language.value);
const config = useRuntimeConfig();
const token = useCookie<string>("token");
const toast = useToast();
const confirm = useConfirm();
const emit = defineEmits(['update:refresh', 'editModal']);

const props = defineProps<{ refresh: boolean }>()
const dialogVisible = ref<boolean>(false)
watch([() => props.refresh], async () => {
  if (props.refresh) {
    refresh();
  }
})

const devices = ref({});
const infoTable = ref([]);
const planID = ref<number>(0);
const planName = ref<string>('');

// pt: Função para formatar a forma como o runout é exibido
// es: Función para formatear la forma en que se muestra el runout
function formatRunout(runout: string): string {
  return runout.split('.')[0];
}

// pt: Função para mesclar os dados da requisição para criar o card
// es: Función para fusionar datos de solicitud para crear la tarjeta
function mergeRouterData(dataArray: any[], key: string) {
  dataArray.forEach((item) => {
    const routerName = item.plan_name;
    if (!devices.value[routerName]) {
      devices.value[routerName] = {};
    }
    devices.value[routerName][key] = item[key];
  });
}


const refresh = async () => {
  devices.value = {};
  await fetchData();
  emit('update:refresh', false)
}

// pt: Função para popular a tabela
// Función para llenar la tabla
const PopTable = async (id: number, name: string) => {
  const dt:any[] = await $fetch(`${config.public.apiFastApi}/capacity_planning/get_interface/${id}`,{
    method: 'GET', 
   })
   infoTable.value=dt
   planID.value = id;
   planName.value = name;
}

// pt: Função para fazer as requisições para pegar as informações necessárias para o card
// es: Función para realizar solicitudes para obtener la información necesaria para la tarjeta
const fetchData = async () => {
  try {
    const { data: idData, error: idError } = await useFetch(`${config.public.apiFastApi}/capacity_planning/get_ids`, { method: "GET" });
    const { data: interfacesData, error: interfacesError } = await useFetch(`${config.public.apiFastApi}/capacity_planning/get_interfaces`, { method: "GET" });
    const { data: runoutData, error: runoutError } = await useFetch(`${config.public.apiFastApi}/capacity_planning/get_runout`, { method: "GET" });
    const { data: totalCapacityData, error: totalCapacityError } = await useFetch(`${config.public.apiFastApi}/capacity_planning/get_total_capacity`, { method: "GET" });
    const { data: utilizationData, error: utilizationError } = await useFetch(`${config.public.apiFastApi}/capacity_planning/get_utilization`, { method: "GET" });

    if (idError.value) {
      throw new Error(`Error fetching data: ${idError.value}`);
    }
    if (interfacesError.value) {
      throw new Error(`Error fetching data: ${interfacesError.value}`);
    }
    if (runoutError.value) {
      throw new Error(`Error fetching data: ${runoutError.value}`);
    }
    if (totalCapacityError.value) {
      throw new Error(`Error fetching data: ${totalCapacityError.value}`);
    }
    if (utilizationError.value) {
      throw new Error(`Error fetching data: ${utilizationError.value}`);
    }

    const parsedIdData = parseData(idData.value);
    const parsedInterfacesData = parseData(interfacesData.value);
    const parsedRunoutData = parseData(runoutData.value);
    const parsedTotalCapacityData = parseData(totalCapacityData.value);
    const parsedUtilizationData = parseData(utilizationData.value);

    mergeRouterData(parsedIdData, 'planning_id');
    mergeRouterData(parsedInterfacesData, 'interface_count');
    mergeRouterData(parsedRunoutData, 'runout');
    mergeRouterData(parsedTotalCapacityData, 'total_capacity');
    mergeRouterData(parsedUtilizationData, 'max_use');

  } catch (err: any) {
    console.error(err.message);
  }
}

const editPlan = (planID: number) => {
  dialogVisible.value = false
  emit('editModal', {control: true, planId: planID})
}

const deletePlan = async (planID: number) => {
  try {
    const data = await $fetch(`${config.public.apiFastApi}/capacity_planning/delete_plan/${planID}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token.value}`
      },
    });
    
    toast.add({ severity: 'success', summary: translations['confirmed'], detail: translations['plan_deleted'], life: 3000 });
    refresh();
    dialogVisible.value = false;
    
  } catch (error) {
    console.error("Erro ao deletar o plano:", error);
    toast.add({ severity: 'error', summary: translations['rejected'], detail: translations['plan_delete_error'], life: 3000 });
  }
}

const confirmDelete = (id: number) => {
  confirm.require({
    message: `${translations['modal_delete_plan']} "${planName.value}"?`,
    header: translations['delete_plan'],
    icon: 'pi pi-info-circle',
    rejectLabel: translations['cancel'],
    rejectProps: {
      label: translations['cancel'],
      severity: 'secondary',
      outlined: true
    },
    acceptProps: {
      label: translations['delete'],
      severity: 'danger'
    },
    accept: () => {
      deletePlan(id)
    },
  });
};

await fetchData()
</script>
