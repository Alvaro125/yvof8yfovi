<template>
  <slot></slot>
</template>

<script lang="ts" setup>
import { provide, shallowReadonly } from "vue";
import { useFetch } from "@vueuse/core";
import type { graphTypes } from "@/utils/graphtypes";

const { data } = useFetch("/api/v0/console/configuration")
  .get()
  .json<ServerConfig>();
provide(ServerConfigKey, shallowReadonly(data));
</script>

<script lang="ts">
import type { InjectionKey, Ref } from "vue";

type ServerConfig = {
  version: string;
  defaultVisualizeOptions: {
    graphType: keyof typeof graphTypes;
    start: string;
    end: string;
    filter: string;
    dimensions: string[];
    limit: number;
  };
  dimensions: string[];
  dimensionsLimit: number;
  truncatable: string[];
  homepageTopWidgets: string[];
};

export const ServerConfigKey: InjectionKey<Readonly<Ref<ServerConfig | null>>> =
  Symbol();
</script>
