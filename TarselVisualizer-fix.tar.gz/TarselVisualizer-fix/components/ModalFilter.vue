<!-- SPDX-FileCopyrightText: 2022 Free Mobile -->
<!-- SPDX-License-Identifier: AGPL-3.0-only -->

<!-- pt: Modal de filtros que permite criar grupos de expresões logicas usando linhas de dimensões -->
<!-- es: Modal de filtros que permite crear grupos de expresiones lógicas usando líneas de dimensiones -->
<template>
  <InputBase v-slot="{ childClass }" :error="error" v-bind="$attrs">
    <div ref="elEditor" :class="childClass"></div>
  </InputBase>
  <InputButton @click="status = true" class="justify-center sm:max-lg:order-4 mt-1">{{ translations['select'] }}
  </InputButton>
  <PrimeDialog v-model:visible="status" modal :header="translations['filters']" :style="{ width: '90vw' }"
    class="text-black bg-gray-100 dark:text-white dark:bg-zinc-900 min-h-min">
    <div>
      <div class="flex justify-between mb-4 pl-4">
        <span class="text-surface-500 dark:text-surface-40 mb-8">
          {{ translations['filter_groups'] }}
        </span>
        <!-- Lista de Matchs -->
        <InputListBox v-model="seletedMatch" :items="matchsOperators" :label="translations['group_matchs']"
          class="w-1/4">
          <template #selected>
            {{ seletedMatch.description }}
          </template>
          <template #item="{ description }">
            <span>{{ description }}</span>
          </template>
        </InputListBox>
      </div>

      <div class="overflow-auto p-4 h-96">
        <!-- pt: Opções do grupo -->
        <!-- es: Opciones del grupo -->
        <div v-for="(group, gIndex) in expressionsGroups" :key="gIndex" class="flex flex-col gap-4 mb-10 mt-2">
          <div class="flex justify-between items-center">
            <div class="flex gap-5 items-center">
              <!-- pt: Lista de inclusões -->
              <!-- es: Lista de inclusiones -->
              <span>{{ translations['include'] }}</span>
              <!-- pt: Lista de operações logicas do group -->
              <!-- es: Lista de operaciones lógicas del grupo -->
              <InputBase class="w-24">
                <InputListBox v-model="logicalOperator[gIndex]" :items="logicalOperatorList" class="justify-center">
                  <template #selected>
                    {{ logicalOperator[gIndex].description ?? '' }}
                  </template>
                  <template #item="{ description }">
                    <span>{{ description }}</span>
                  </template>
                </InputListBox>
              </InputBase>
              <span>{{ translations['filter_conditions'] }}</span>
            </div>
            <!-- pt: Butão para remover grupo -->
            <!-- es: Botón para eliminar grupo -->
            <PrimeButton :label="translations['remove_group']" severity="danger" @click="removeGroup(gIndex);"
              class="h-8">
            </PrimeButton>
          </div>
          <!-- pt: condições do filtro -->
          <!-- es: condiciones del filtro -->
          <div class="w-full p-4 flex-r space-y-2 bg-gray-300 dark:bg-gray-600 rounded">
            <div v-for="(expresion, eIndex) in expressionsList[gIndex]" :key="eIndex" class="flex space-x-4">
              <!-- pt: Lista de dimensões -->
              <!-- es: Lista de dimensiones -->
              <InputBase class="w-1/4"
                :class="errorDimension[0] == gIndex && errorDimension[1] == eIndex ? 'border-red-600 border-2 rounded-sm' : ''">
                <InputListBoxSearch v-model="expressionsList[gIndex][eIndex].dimension" :items="dimensionsLists"
                  :multiple="false" :search-fields="['maskedName']">
                  <template #item="{ maskedName }">
                    <span>{{ maskedName }}</span>
                  </template>
                </InputListBoxSearch>
              </InputBase>
              <!-- pt: Lista de operadores da linha de expressão -->
              <!-- es: Lista de operadores de la línea de expresión -->
              <InputBase class="w-1/6">
                <InputListBox v-model="expressionsList[gIndex][eIndex].op" :items="localFilterOperators">
                  <template #selected>
                    {{ expressionsList[gIndex][eIndex].op.description ?? '' }}
                  </template>
                  <template #item="{ description }">
                    <span>{{ description }}</span>
                  </template>
                </InputListBox>
              </InputBase>
              <!-- Filtro AutoComplete -->
              <!-- <AutoComplete
                dropdown
                v-model="expressionsList[gIndex][eIndex].selected"
                :suggestions="possibleFilters[gIndex][eIndex]"
                @complete="searchFilter($event,gIndex,eIndex)"
                class="w-1/2 h-8 "
                :class="{
                  'light-p-autocomplete-input': !isDark,
                  'light-p-autocomplete-dropdown': !isDark,
                  'dark-p-autocomplete-input': isDark,
                  'dark-p-autocomplete-dropdown': isDark
                }"
                :inputStyle="{ border: 'none', borderTopLeftRadius: '0.5rem', borderBottomLeftRadius: '0' }"
              /> -->
              <AutoCompleteFilterOptions v-model="expressionsList[gIndex][eIndex].selected"
                :dimension="expressionsList[gIndex][eIndex].dimension.dimension" />
              <!-- pt: Botão para remover linhas de expressão -->
              <!-- es: Botón para eliminar líneas de expresión -->
              <PrimeButton label="X" severity="danger" @click="removeExpression(eIndex, gIndex);" class="h-8">
              </PrimeButton>
            </div>
            <!-- pt: Botão para adicionar linha de expressão -->
            <!-- es: Botón para agregar línea de expresión -->
            <PrimeButton :label="translations['add_condition']" @click="addExpression(gIndex)" class="h-7">
            </PrimeButton>
          </div>
        </div>
      </div>

      <div class="flex justify-between items-center">
        <!-- pt: Botão para adicionar -->
        <!-- es: Botón para agregar -->
        <PrimeButton type="button" :label="translations['add_group']" class="h-10" @click="addGroup()"></PrimeButton>
        <!-- pt: Botões para limpar grupos e salvar filtros -->
        <!-- es: Botones para limpiar grupos y guardar filtros -->
        <div class="flex gap-2 mt-4">
          <PrimeButton type="button" :label="translations['clear']" severity="danger" @click="clear"></PrimeButton>
          <PrimeButton type="button" :label="translations['save']" @click="Save"></PrimeButton>
        </div>
      </div>
    </div>
  </PrimeDialog>
</template>

<script lang="ts" setup>
import { ref, inject, watch, computed, onMounted, onBeforeUnmount } from "vue";
import InputBase from "@/components/InputBase.vue";
import InputButton from "@/components/InputButton.vue";
import { ThemeKey } from "@/components/ThemeProvider.vue";
import {
  EditorState,
  StateEffect,
  Compartment,
  type Extension,
} from "@codemirror/state";
import { EditorView, keymap, placeholder } from "@codemirror/view";
import { syntaxHighlighting, HighlightStyle } from "@codemirror/language";
import { standardKeymap, history } from "@codemirror/commands";
import { linter } from "@codemirror/lint";
import { autocompletion, acceptCompletion } from "@codemirror/autocomplete";
import { tags as t } from "@lezer/highlight";
import {
  filterLanguage,
  filterCompletion,
  filterLinterSource,
} from "@/codemirror/lang-filter";
import type { InputListBox } from "#build/components";
import { ServerConfigKey } from "@/components/ServerConfigProvider.vue";
import AutoComplete from 'primevue/autocomplete';
import { changeDimensionsNames } from "@/utils/dimensions";
import getTranslations from '@/utils/translations';
import { isEqual } from "lodash-es";

const language = useCookie('language');
const translations: any = await getTranslations('visualize', language.value);
// pt: Interfaces para representar os dados
// es: Interfaces para representar los datos
interface SelectedIncludeModel {
  id: number;
  description: string;
  value: boolean;
};
interface SelectedDimensionModel {
  id: number;
  dimension: string;
};
interface LogicalOperatorModel {
  id: number;
  description: string;
  operator: string;
};
interface SelectedOperatorModel {
  id: number;
  description: string;
  operator: string;
};
interface FilterObject {
  selected: string;
  dimension: SelectedDimensionModel;
  op: LogicalOperatorModel;
};
const cookieToken = useCookie('token')
const cookieIdClient = useCookie('id_client')
const props = defineProps<{
  modelValue: ModelType;
}>();
const emit = defineEmits<{
  "update:modelValue": [value: typeof props.modelValue];
  submit: [];
}>();
const vModel = defineModel<ModelType>();

const { isDark } = inject(await ThemeKey)!;
const toast = useToast();

// # Editor
const status = ref<boolean>(false);
const elEditor = ref<HTMLDivElement | null>(null);
const expression = ref(""); // Keep in sync with modelValue.expression
const error = ref(""); // Keep in sync with modelValue.errors
const text = ref(""); // Keep in sync with modelValue.errors

// pt: Lista de operadores logicos entre os grupo
// es: Lista de operadores lógicos entre los grupos
const matchsOperators = [
  {
    id: 0,
    description: translations['match_all'],
    operator: 'AND'
  },
  {
    id: 1,
    description: translations['match_any'],
    operator: 'OR'
  }
]
const seletedMatch = ref(matchsOperators[0]);
// pt: Lista de inclusão de grupos
// es: Lista de inclusión de grupos
const includeOptions = [
  {
    id: 0,
    description: translations['include'],
    value: true
  },
  {
    id: 1,
    description: translations['exclude'],
    value: false
  }
];
const selectedInclude = ref<SelectedIncludeModel[]>([]);
// pt: Lista de operadores logicos do grupo
// es: Lista de operadores lógicos del grupo
const logicalOperatorList = [
  {
    id: 0,
    description: translations['all'],
    operator: 'AND'
  },
  {
    id: 1,
    description: translations['any'],
    operator: 'OR'
  }
];
const logicalOperator = ref<LogicalOperatorModel[]>([]);
// pt: Lista de operadores comparativos do filtro
// es: Lista de operadores comparativos del filtro
const localFilterOperators = [
  {
    id: 0,
    description: translations['equal'],
    operator: "="
  }, {
    id: 1,
    description: translations['not_equal'],
    operator: "!="
  }, {
    id: 2,
    description: translations['contain'],
    operator: "LIKE"
  }, {
    id: 3,
    description: translations['dont_contain'],
    operator: "UNLIKE"
  }, {
    id: 4,
    description: translations['greater_than'],
    operator: ">"
  }, {
    id: 5,
    description: translations['less_than'],
    operator: "<"
  }, {
    id: 6,
    description: translations['greater_equal'],
    operator: ">="
  }, {
    id: 7,
    description: translations['less_equal'],
    operator: "<="
  }
];
const selectedOperator = ref<SelectedOperatorModel[]>([]);
const requestFilters = ref<Promise<[]>[][]>([[]]); // pt: Lista de dimensões para pesquisa de filtros - es: Lista de dimensiones para búsqueda de filtros
const possibleFilters = ref<FilterObject[][]>([[]]); // pt: Lista de filtros possiveis com base na dimensão escolhida - es: Lista de filtros posibles basados en la dimensión elegida
const selectedFilter = ref<string[]>([]); // pt: Lista de filtros selecionados - es: Lista de filtros seleccionados
const serverConfiguration = inject(await ServerConfigKey)!;
const dimensionsLists = Object.entries(serverConfiguration.value?.dimensions).map(([k, v], idx) => ({
  id: idx + 1,
  dimension: v,
  maskedName: changeDimensionsNames(v)
})); // pt: Lista de dimensões - es: Lista de dimensiones
const selectedDimension = ref<SelectedDimensionModel[]>([]); // pt: Lista de dimensões selecionadas - es: Lista de dimensiones seleccionadas
const expressionsGroups = reactive(['']); // pt: Lista de grupos de expressões - es: Lista de grupos de expresiones
const expressionsList = reactive<FilterObject[][]>([[]]); // pt: Lista de expressões do grupo - es: Lista de expresiones del grupo
const errorDimension = ref<Array<number>>([-1, -1]);

let component:
  | { view: EditorView; state: EditorState }
  | { view: null; state: null } = {
  view: null,
  state: null,
};
watch(
  () => props.modelValue,
  (model) => {
    if (model) {
      if (model.expression.trim().length) {
        parseComplexFilters(model.expression)
      }
      expression.value = model.expression;
    }

  },
  { immediate: true },
);
watch(
  () => ({ expression: expression.value, errors: !!error.value }),
  (value) => {
    if (!isEqual(props.modelValue, value)) {
      emit("update:modelValue", value);
    }
  },
  { immediate: true },
);

type Filter = {
  attr: string;
  op: string;
  value: string;
};

function parseFilter(filter: string): Filter[] {
  const operators = [">=", "<=", "<>", "!=", "UNLIKE", "LIKE", "=", ">", "<"];
  const result: Filter[] = [];

  // Divide o filtro em partes com base no "AND"
  const conditions = filter.split(/\s+(AND|OR)\s+/);

  conditions.forEach((condition) => {
    // Encontra o operador dentro da condição
    const operator = operators.find((op) => condition.includes(op));
    if (operator) {
      const [attr, value] = condition.split(operator).map((part) => part.trim());
      const valueFormat = value.replace(/[\"|\'|\%']/g, '')
      result.push({ attr, op: operator, value: valueFormat });
    }
  });
  return result;
}

function parseComplexFilters(filterString: string) {
  const groupPattern = /\(([^()]+)\)/g;
  const allParttern = /(AND)/g;
  const anyParttern = /(OR)/g;
  const nestedMatch: string[] | null = filterString.match(groupPattern);
  expressionsList.splice(0, expressionsList.length)
  expressionsGroups.splice(0, expressionsGroups.length)
  selectedInclude.value.splice(0, selectedInclude.value.length)
  if (nestedMatch == null) {
    expressionsGroups.push("")
    selectedInclude.value.push({
      id: 0,
      description: "Include",
      value: true
    })
    const rule = filterString.replace(/(\(|\))/g, "")
    const expr = parseFilter(rule)
    expressionsList.push([])
    expr.map((l, i) => {
      const dimension = dimensionsLists.find((d) => d.dimension == l.attr) as any
      expressionsList[0].push({
        dimension: dimension,
        op: localFilterOperators.find(o => o.operator == l.op) as any,
        selected: l.value
      })
    })
  } else {
    nestedMatch.map((value, index) => {
      expressionsGroups.push("")
      selectedInclude.value.push({
        id: 0,
        description: "Include",
        value: true
      })
      const rule = value.replace(/(\(|\))/g, "")
      const expr = parseFilter(rule)
      expressionsList.push([])
      expr.map((l, i) => {
        const dimension = dimensionsLists.find((d) => d.dimension == l.attr) as any
        expressionsList[index].push({
          dimension: dimension,
          op: localFilterOperators.find(o => o.operator == l.op) as any,
          selected: l.value
        })
      })
    });
  }
}


// pt: Atualiza as listas se houver mudança ou seleciona o primeiro item da lista
// es: Actualiza las listas si hay cambios o selecciona el primer elemento de la lista
watchEffect(
  async () => {
    selectedDimension.value = dimensionsLists.map((element, index) => { return selectedDimension.value[index] ?? dimensionsLists[0] });
    selectedInclude.value = expressionsGroups.map((element, index) => { return selectedInclude.value[index] ?? includeOptions[0] });
    logicalOperator.value = expressionsGroups.map((element, index) => { return logicalOperator.value[index] ?? logicalOperatorList[0] });
    selectedOperator.value = expressionsList.map((element, index) => { return selectedOperator.value[index] ?? localFilterOperators[0] });
    selectedFilter.value = expressionsList.map((element, index) => { return selectedFilter.value[index] ?? '' });
  }
);

// pt: Função que busca filtros possiveis com base na dimensão escolhida e no texto digitado, e adiciona a lista de filtros possiveis
// es: Función que busca filtros posibles basados en la dimensión elegida y el texto escrito, y añade a la lista de filtros posibles

// pt: Função que junta as expressão e campos dos grupos e gera o filtro
// es: Función que junta las expresiones y campos de los grupos y genera el filtro
function generateFilter() {
  let filterResult = '';

  expressionsList.forEach((group, gIndex) => {
    let filter:Array<string> = [];
    let includeValue = [...selectedInclude.value][gIndex].value;

    if (group.length != 0 && includeValue) {
      group.forEach((line: FilterObject, index) => {
        switch (line.op.operator) {
          case "LIKE":
            filter.push(likeCase(line, index));
            break;
          case "UNLIKE":
            filter.push(likeCase(line, index));
            break;
          default:
            filter.push(defaultCase(line, index));
            break;
        };
      });
      console.log(filter)
      filterResult == '' ? filterResult += `(${filter.join(` ${logicalOperator.value[gIndex].operator} `)})` : filterResult += ` ${seletedMatch.value.operator} (${filter.join(` ${logicalOperator.value[gIndex].operator} `)})`;
    };
  });
  return filterResult != '' ? filterResult : ' ';
};

// pt: Função que gera a expressão do filtro com base na dimensão escolhida
// es: Función que genera la expresión del filtro basada en la dimensión elegida
function defaultCase(obj: FilterObject, index: number) {
  const codeSplitRegex = /\d+:\s[\w\s\.\(\)À-ÿ/-]+/;
  const ipRegex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;

  const dimensions_exception = ["DstAS", "SrcAS", 'InIfSpeed', 'InIfBoundary', 'OutIfSpeed', 'ForwardingStatus', 'DstNetPrefix', 'SrcNetPrefix', 'SrcPort', 'DstPort', "EType"]
  const getFilterValue = () => {
    if (ipRegex.test(obj.selected)) {
      return obj.selected;
    } else if (codeSplitRegex.test(obj.selected)) {
      return obj.selected.split(":")[0];
    } else {
      if (dimensions_exception.includes(obj.dimension.dimension)) {
        return `${obj.selected}`;
      } else {
        return `'${obj.selected}'`;
      };
    };
  };

  const dimensionString = `${obj.dimension.dimension} ${obj.op.operator} ${getFilterValue()}`;
  return dimensionString;
}

// pt: Função que gera a expressão do filtro com base na dimensão escolhida para o operator LIKE
// es: Función que genera la expresión del filtro basada en la dimensión elegida para el operador LIKE
function likeCase(obj: FilterObject, index: number) {
  const codeSplitRegex = /\d+:\s[\w\s\.\(\)À-ÿ/-]+/;
  const ipRegex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;

  const getFilterValue = () => {
    if (ipRegex.test(obj.selected)) {
      return obj.selected;
    } else if (codeSplitRegex.test(obj.selected)) {
      return obj.selected.split(":")[0];
    } else {
      return `${obj.selected}`;
    };
  };

  const dimensionString = `${obj.dimension.dimension} ${obj.op.operator} '%${getFilterValue()}%'`;
  return dimensionString;
};

// pt: Função que busca os filtros possiveis com base na dimensão escolhida
// es: Función que busca los filtros posibles basados en la dimensión elegida
async function getFilters(dimension: string) {
  const route = `/api/v0/console/graph/line?token=${cookieToken.value}&id_client=${cookieIdClient.value}`;

  const request = {
    "bidirectional": false,
    "dimensions": [`${dimension}`],
    "end": (new Date()).toISOString(),
    "filter": "",
    "limit": 50,
    "points": 10,
    "previous-period": false,
    "start": new Date(new Date().setDate(new Date().getDate() - 1)).toISOString(),
    "truncate-v4": 1,
    "truncate-v6": 1,
    "units": "pps"
  };

  const result = fetch(route, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(request)
  })
    .then(response => response.json())
    .then(data => { return data.rows; })
    .catch(error => { console.error('Error:', error); });

  return result;
};

// pt: Funções para adicionar e remover expressões e grupos
// es: Funciones para agregar y eliminar expresiones y grupos
function removeExpression(eIndex: number, gIndex: number) {
  expressionsList[gIndex].splice(eIndex, 1);
  selectedOperator.value.splice(eIndex, 1);
  selectedFilter.value.splice(eIndex, 1);
};
function removeGroup(gIndex: number) {
  expressionsGroups.splice(gIndex, 1);
  expressionsList.splice(gIndex, 1);
  selectedInclude.value.splice(gIndex, 1);
  logicalOperator.value.splice(gIndex, 1);
};
function addGroup() {
  expressionsGroups.push('');
  expressionsList.push([]);
  possibleFilters.value.push([]);
};
function addExpression(gIndex: number) {
  expressionsList[gIndex].push({
    dimension: {
      id: 0,
      dimension: "",
      maskedName: ""
    },
    op: {
      id: 0,
      description: translations['equal'],
      operator: "="
    },
    selected: ''
  });
  possibleFilters.value[gIndex].push([]);
};

function clear() {
  expressionsGroups.splice(0, expressionsGroups.length);
  expressionsList.splice(0, expressionsList.length);
}

function hasEmptyDimension(filters): boolean {
  if (filters.length) {
    let il = -1;
    const ig = filters.findIndex(
      filter => {
        let fi = filter.findIndex(f => f.dimension === undefined || f.dimension.dimension === '')
        if (fi != -1) {
          il = fi;
        }
        return fi != -1;
      })
    errorDimension.value = [ig, il]
    return ig != -1;
  } else {
    return false;
  }
}

function Save() {
  if (!hasEmptyDimension(expressionsList)) {
    status.value = false;
    vModel.value = { expression: generateFilter() };
    emit('submit');
  } else {
    toast.add({ severity: 'error', summary: translations['invalid'], detail: translations['select_a_filter'], life: 3000 });
    return;
  }
};

// https://github.com/surmon-china/vue-codemirror/blob/59598ff72327ab6c5ee70a640edc9e2eb2518775/src/codemirror.ts#L52
const rerunExtension = () => {
  const compartment = new Compartment();
  const run = (view: EditorView, extension: Extension) => {
    if (compartment.get(view.state)) {
      // reconfigure
      view.dispatch({ effects: compartment.reconfigure(extension) });
    } else {
      // inject
      view.dispatch({
        effects: StateEffect.appendConfig.of(compartment.of(extension)),
      });
    }
  };
  return run;
};

// Theme for the filtering language
const filterTheme = computed(() => [
  syntaxHighlighting(
    HighlightStyle.define([
      { tag: t.propertyName, color: isDark.value ? "#fb660a" : "#008800" },
      { tag: t.string, color: isDark.value ? "#ff0086" : "#880000" },
      { tag: t.comment, color: isDark.value ? "#7d8799" : "#4f4f4f" },
      { tag: t.operator, color: isDark.value ? "#00a3ff" : "#333399" },
    ]),
  ),
  /* Theme is in tailwind.css */
  EditorView.theme({}, { dark: isDark.value }),
]);

const submitFilter = (_: EditorView): boolean => {
  emit("submit");
  return true;
};

onMounted(() => {
  // Create Code mirror instance
  const state = EditorState.create({
    doc: vModel.value?.expression,
    extensions: [
      filterLanguage(),
      filterCompletion(),
      autocompletion({ icons: false }),
      linter(async (v) => {
        const diags = await filterLinterSource(v);
        error.value = diags.length > 0 ? "Invalid filter expression" : "";
        return diags;
      }),
      keymap.of([
        ...standardKeymap.filter((b) => b.key !== "Mod-a"),
        { key: "Tab", run: acceptCompletion },
        { key: "Ctrl-Enter", run: submitFilter },
        { key: "Cmd-Enter", run: submitFilter },
      ]),
      history(),
      placeholder("Filter expression"),
      EditorView.lineWrapping,
      EditorView.updateListener.of((viewUpdate) => {
        if (viewUpdate.docChanged) {
          expression.value = viewUpdate.state.doc.toString();
        }
        if (viewUpdate.focusChanged) {
          if (!viewUpdate.view.hasFocus) {
            // Trim spaces
            const index = viewUpdate.state.doc.toString().search(/\s+$/);
            if (index !== -1) {
              viewUpdate.view.dispatch({
                changes: {
                  from: index,
                  to: viewUpdate.state.doc.length,
                },
              });
            }
          }
        }
      }),
    ],
  });
  const view = new EditorView({
    state: state,
    parent: elEditor.value!,
  });
  const run = rerunExtension();
  run(view, filterTheme.value);
  component = { view, state };

  watch(
    expression,
    (expression) => {
      if (expression !== component.view?.state.doc.toString()) {
        component.view?.dispatch({
          changes: {
            from: 0,
            to: component.view.state.doc.length,
            insert: expression,
          },
        });
      }
    },
    { immediate: true },
  );

  // Reactivity
  watch(filterTheme, (theme) => run(view, theme));
});

onBeforeUnmount(() => {
  if (component.view) component.view.destroy();
});
</script>
<script lang="ts">
export default {
  inheritAttrs: false,
};
export type ModelType = {
  expression: string;
  errors?: boolean;
} | null;
</script>

<!-- pt: Estilização do AutoComplete -->
<!-- es: Estilización del AutoComplete -->
<style scoped>
.light-p-autocomplete-input {
  --p-inputtext-background: white;
  --p-inputtext-color: black;
}

.light-p-autocomplete-dropdown {
  --p-autocomplete-dropdown-background: white;
  --p-autocomplete-dropdown-color: #9ca3af;
  --p-autocomplete-dropdown-hover-background: white;
  --p-autocomplete-dropdown-hover-border-color: white;
  --p-autocomplete-dropdown-border-color: white;
  --p-autocomplete-dropdown-active-background: #2563eb;
}

.dark-p-autocomplete-input {
  --p-inputtext-background: #111827;
}

.dark-p-autocomplete-dropdown {
  --p-autocomplete-dropdown-background: #111827;
  --p-autocomplete-dropdown-color: #9ca3af;
  --p-autocomplete-dropdown-hover-background: #111827;
  --p-autocomplete-dropdown-hover-border-color: #111827;
  --p-autocomplete-dropdown-border-color: #111827;
  --p-autocomplete-dropdown-active-background: none;
}
</style>