<!-- SPDX-FileCopyrightText: 2022 Free Mobile -->
<!-- SPDX-License-Identifier: AGPL-3.0-only -->

<template>
  <div class="mr-10">
    <i class="pi pi-spin pi-spinner" style="font-size: 1rem"></i>
  </div>
</template>