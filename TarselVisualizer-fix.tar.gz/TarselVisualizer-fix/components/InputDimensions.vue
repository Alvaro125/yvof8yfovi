<template>
  <div class="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-1">
    <InputButton @click="toggleModalVisibility" class="justify-center sm:max-lg:order-4 mt-1"
      :class="dimensionsError.length && 'border-red-600 border-2'">{{ translations['select'] }}</InputButton>
    <div v-if="isModalVisible" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
      @click.self="toggleModalVisibility">
      <div class="w-5/6 h-5/6 bg-white p-6 rounded shadow-lg  dark:bg-slate-800">
        <h2 class="text-xl mb-4 text-center dark:text-white">{{ translations['dimensions'] }}</h2>
        <InputListBox v-model="selectedDimensions" :items="dimensions" :error="dimensionsError" multiple
          :label="translations['dimensions']" filter="maskedName" class="col-span-2 lg:col-span-1 w-1/2">
          <template #item="{ maskedName, color }">
            <span :style="{ backgroundColor: color }" class="inline w-1 rounded">&nbsp;</span>
            {{ maskedName }}
          </template>
        </InputListBox>
        <div class="flex flex-row">
          <div class="h-80 w-96 mt-4 p-2 overflow-y-auto scrollbar-thin border border-solid rounded border-stone-200">
            <div class="w-full h-5">
              <p class="text-sm text-center dark:text-white">{{ translations['selected_dimensions'] }}</p>
            </div>
            <div class="flex justify-start mt-2">
              <span v-if="selectedDimensions.length === 0" class="dark:text-white">{{ translations['no_dimensions']
                }}</span>
              <draggable v-model="selectedDimensions" class="flex flex-wrap gap-1 h-5" tag="span" item-key="id">
                <template #item="{ element: dimension }">
                  <span
                    class="flex cursor-grab items-center gap-1 rounded border-2 bg-violet-100 px-1.5 dark:bg-slate-800 dark:text-gray-200"
                    :style="{ borderColor: dimension.color }">
                    <span class="leading-4">{{ dimension.maskedName }}</span>
                    <XIcon class="h-4 w-4 cursor-pointer hover:text-blue-700 dark:hover:text-white"
                      @click.stop.prevent="removeDimension(dimension)" />
                  </span>
                </template>
              </draggable>
              <span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                <SelectorIcon class="h-5 w-5 text-gray-400" aria-hidden="true" />
              </span>
            </div>
          </div>
          <div class="h-80 mt-2 overflow-y-auto scrollbar-thin flex flex-wrap justify-center">
            <div v-for="(dimensions, color) in groupedDimensions" :key="color" :style="{ backgroundColor: color }"
              class="p-3 m-2 w-48 rounded">
              <label v-for="dimension in dimensions" :key='dimension.id' :value="dimension"
                class="relative inline-flex w-full cursor-default select-none py-2 pl-1.5 text-sm ui-active:bg-gray-100 text-white hover:bg-gray-600 hover:text-white ui-active:dark:bg-gray-600 ui-active:dark:text-white">
                <input type="checkbox" :value="dimension" v-model="selectedDimensions" />
                <span class="pl-1">{{ dimension.maskedName }}</span>
              </label>
            </div>
          </div>
        </div>

        <div class="flex justify-center mt-5">
          <InputButton @click="toggleModalVisibility" class="order-2 w-28 justify-center sm:max-lg:order-4 mt-3">{{
            translations['close'] }}</InputButton>
        </div>
      </div>

    </div>

    <div class="flex flex-row flex-nowrap gap-2">
      <InputString v-if="canAggregate" v-model="truncate4" class="grow" label="IPv4 /x" :error="truncate4Error" />
      <InputString v-if="canAggregate" v-model="truncate6" class="grow" label="IPv6 /x" :error="truncate6Error" />
      <InputString v-model="limit" class="grow" :label="translations['limit']" :error="limitError" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import draggable from "vuedraggable";
import { XIcon, SelectorIcon } from "@heroicons/vue/solid";
import { dataColor } from "@/utils/palette";
import InputString from "@/components/InputString.vue";
import InputListBox from "@/components/InputListBox.vue";
import { ServerConfigKey } from "@/components/ServerConfigProvider.vue";
import { isEqual, intersection } from "lodash-es";
import InputButton from "@/components/InputButton.vue";
import { changeDimensionsNames, selectedDimensions } from "~/utils/dimensions";
import getTranslations from '@/utils/translations';
import { errorMessages } from "vue/compiler-sfc";

const language = useCookie('language');
const translations: any = await getTranslations('visualize', language.value);

const props = withDefaults(
  defineProps<{
    modelValue: ModelType;
    minDimensions?: number;
    maxDimensions?: number;
  }>(),
  {
    minDimensions: 0,
    maxDimensions: 6,
  },
);
const emit = defineEmits<{
  "update:modelValue": [value: typeof props.modelValue];
}>();

const isModalVisible = ref(false);
const toggleModalVisibility = () => isModalVisible.value = !isModalVisible.value;

// pt: Essa função pega o objeto Dimensions e o divide em 3 chaves de acordo com a cor de cada dimension
// es: Esta función toma el objeto Dimensions y lo divide en 3 claves según el color de cada dimension
const groupedDimensions = computed(() => {
  return dimensions.value.reduce((groups, dimension) => {
    if (!groups[dimension.color]) {
      groups[dimension.color] = [];
    }
    groups[dimension.color].push(dimension);
    return groups;
  }, {} as Record<string, typeof dimensions.value>);
});

const serverConfiguration = inject(await ServerConfigKey)!;

const dimensionsError = computed(() => {
  if (selectedDimensions.value.length < props.minDimensions) {
    return "At least two dimensions are required";
  }
  if (selectedDimensions.value.length > props.maxDimensions) {
    return "It is not possible to select more than 6 dimensions";
  }
  return "";
});
const limit = ref("10");
const limitError = computed(() => {
  const val = parseInt(limit.value);
  if (isNaN(val)) {
    return "Not a number";
  }
  if (val < 1) {
    return "Should be ≥ 1";
  }
  const upperLimit = 200;
  // const upperLimit = serverConfiguration.value?.dimensionsLimit ?? 50;
  if (val > upperLimit) {
    return `Should be ≤ ${upperLimit}`;
  }
  return "";
});
const canAggregate = computed(
  () =>
    intersection(
      selectedDimensions.value.map((dim) => dim.name),
      serverConfiguration.value?.truncatable || [],
    ).length > 0,
);
const truncate4 = ref("32");
const truncate4Error = computed(() => {
  const val = parseInt(truncate4.value);
  if (isNaN(val) || val <= 0 || val > 32) {
    return "0 < x ≤ 32";
  }
  return "";
});
const truncate6 = ref("128");
const truncate6Error = computed(() => {
  const val = parseInt(truncate6.value);
  if (isNaN(val) || val <= 0 || val > 128) {
    return "0 < x ≤ 128";
  }
  return "";
});
const hasErrors = computed(
  () =>
    !!limitError.value ||
    !!dimensionsError.value ||
    !!truncate4Error.value ||
    !!truncate6Error.value,
);

// pt: Esta variável cria o objeto Dimensions. Ele cria uma id, recebe o nome do backend, cria um nome para ser usado no frontend e define uma cor para cada dimension
// es: Esta variable crea el objeto Dimension. Crea una identificación, recibe el nombre del backend, crea un nombre para usar en el frontend y define un color para cada dimension.
const dimensions = computed(
  () =>
  Object.keys(nameDimensions).map((v: string, idx: number) => {
      return {
        id: idx + 1,
        name: v,
        maskedName: changeDimensionsNames(v),
        color: dataColor(
          ["Exporter", "Src", "Dst", "In", "Out", ""]
            .map((p) => v.startsWith(p))
            .indexOf(true),
        ),
      }
    }) || [],
);

// pt: Remove a dimension selecionada do Array usado para fazer o gráfico
// es: Elimina la dimension seleccionada del Array utilizado para hacer el gráfico.
const removeDimension = (dimension: (typeof dimensions.value)[0]) => {
  selectedDimensions.value = selectedDimensions.value.filter(
    (d) => d !== dimension,
  );
};

watch(
  () => [props.modelValue, dimensions.value] as const,
  async ([value, dimensions]) => {
    if (value) {
      limit.value = value.limit.toString();
      truncate4.value = value.truncate4.toString();
      truncate6.value = value.truncate6.toString();
    }
    if (value)
      selectedDimensions.value = value.selected
        .map((name) => dimensions.find((d) => d.name === name))
        .filter((d): d is (typeof dimensions)[0] => !!d);
  },
  { immediate: true, deep: true },
);
watch(
  [selectedDimensions, limit, truncate4, truncate6, hasErrors] as const,
  ([selected, limit, truncate4, truncate6, hasErrors]) => {
    const updated = {
      selected: selected.map((d) => d.name),
      limit: parseInt(limit),
      truncate4: parseInt(truncate4),
      truncate6: parseInt(truncate6),
      errors: hasErrors,
    };
    if (
      !isEqual(updated, props.modelValue) &&
      !isNaN(updated.limit) &&
      !isNaN(updated.truncate4) &&
      !isNaN(updated.truncate6)
    ) {
      emit("update:modelValue", updated);
    }
  },
);
</script>

<script lang="ts">
export type ModelType = {
  selected: string[];
  limit: number;
  truncate4: number;
  truncate6: number;
  errors?: boolean;
} | null;
</script>
