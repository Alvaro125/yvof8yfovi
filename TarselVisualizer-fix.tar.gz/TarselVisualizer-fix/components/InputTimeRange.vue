<!-- SPDX-FileCopyrightText: 2022 Free Mobile -->
<!-- SPDX-License-Identifier: AGPL-3.0-only -->

<template>
  <div class="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-1">
    <InputListBox
      v-model="selectedPreset"
      :items="presets"
      filter="name"
      :label="translations['presets']"
      class="col-span-2 sm:col-span-1"
    >
      <template #selected>{{ selectedPreset.name }}</template>
      <template #item="{ name }">{{ name }}</template>
    </InputListBox>
    <InputString v-model="startTime" :label="translations['start']" :error="startTimeError" />
    <InputString v-model="endTime" :label="translations['end']" :error="endTimeError" />
  </div>
</template>

<script lang="ts" setup>
import { ref, computed, watch } from "vue";
import { Date as SugarDate } from "sugar-date";
import InputString from "@/components/InputString.vue";
import InputListBox from "@/components/InputListBox.vue";
import { isEqual } from "lodash-es";
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('visualize', language.value);

const props = defineProps<{
  modelValue: ModelType;
}>();
const emit = defineEmits<{
  "update:modelValue": [value: typeof props.modelValue];
}>();

const startTime = ref("");
const endTime = ref("");
const parsedTimes = computed(() => ({
  start: SugarDate.create(startTime.value),
  end: SugarDate.create(endTime.value),
}));
const startTimeError = computed(() =>
  isNaN(parsedTimes.value.start.valueOf()) ? translations['invalid_date'] : "",
);
const endTimeError = computed(
  () =>
    (isNaN(parsedTimes.value.end.valueOf()) ? translations['invalid_date'] : "") ||
    (!isNaN(parsedTimes.value.start.valueOf()) &&
      parsedTimes.value.start > parsedTimes.value.end &&
      translations['invalid_range']) ||
    "",
);
const hasErrors = computed(
  () => !!(startTimeError.value || endTimeError.value),
);

const presets = [
  { name: translations['custom'] },
  { name: translations['last_hour'], start: "1 hour ago", end: "now" },
  { name: "6 " + translations['hours'] + " " + translations['ago'] , start: "6 hours ago", end: "now" },
  { name: "12 " + translations['hours'] + " " + translations['ago'] , start: "12 hours ago", end: "now" },
  { name: "24 " + translations['hours'] + " " + translations['ago'] , start: "24 hours ago", end: "now" },
  { name: translations['last_evening'], start: "yesterday at 7pm", end: "today at 1am" },
  { name: "2 " + translations['days'] + " " + translations['ago'] , start: "2 days ago", end: "now" },
  { name: "7 " + translations['days'] + " " + translations['ago'] , start: "7 days ago", end: "now" },
  { name: "30 " + translations['days'] + " " + translations['ago'] , start: "30 days ago", end: "now" },
  { name: "3 " + translations['months'] + " " + translations['ago'] , start: "3 months ago", end: "now" },
  { name: "6 " + translations['months'] + " " + translations['ago'] , start: "6 months ago", end: "now" },
  { name: translations['last_year'], start: "1 year ago", end: "now" },
  { name: "2 " + translations['years'] + " " + translations['ago'] , start: "2 years ago", end: "now" },
  { name: "5 " + translations['years'] + " " + translations['ago'] , start: "5 years ago", end: "now" },
  { name: translations['today'], start: "today", end: "end of today" },
  { name: translations['yesterday'], start: "yesterday", end: "end of yesterday" },
  {
    name: translations['before_yesterday'],
    start: "day before yesterday",
    end: "yesterday",
  },
  {
    name: translations['this_week'],
    start: "the beginning of this week",
    end: "the end of this week",
  },
  {
    name: translations['this_month'],
    start: "the beginning of this month",
    end: "the end of this month",
  },
  {
    name: translations['this_year'],
    start: "the beginning of this year",
    end: "the end of this year",
  },
  {
    name: translations['today_last_week'],
    start: "0am 1 week ago",
    end: "0am 6 days ago",
  },
  {
    name: translations['last_week'],
    start: "the beginning of last week",
    end: "the end of last week",
  },
  {
    name: translations['last_month'],
    start: "the beginning of last month",
    end: "the end of last month",
  },
  {
    name: translations['last_year'],
    start: "the beginning of last year",
    end: "the end of last year",
  },
].map((v, idx) => ({ id: idx + 1, ...v }));
const selectedPreset = ref(presets[0]);
watch(selectedPreset, (preset) => {
  if (preset.start) {
    startTime.value = preset.start;
    endTime.value = preset.end;
  }
});

watch(
  () => props.modelValue,
  (m) => {
    if (m) {
      startTime.value = m.start;
      endTime.value = m.end;
    }
  },
  { immediate: true, deep: true },
);
watch(
  [startTime, endTime, hasErrors] as const,
  ([start, end, errors]) => {
    // Find the right preset
    const newPreset =
      presets.find((p) => p.start === start && p.end === end) || presets[0];
    if (newPreset.id !== selectedPreset.value.id) {
      selectedPreset.value = newPreset;
    }

    // Update the model
    const newModel = {
      start,
      end,
      errors,
    };
    if (!isEqual(newModel, props.modelValue)) {
      emit("update:modelValue", newModel);
    }
  },
  { immediate: true },
);
</script>

<script lang="ts">
export type ModelType = {
  start: string;
  end: string;
  errors?: boolean;
} | null;
</script>
