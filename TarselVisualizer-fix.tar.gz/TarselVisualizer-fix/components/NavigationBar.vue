<template>
  <div>
    <button @click="drawerVisible = true">
      <MenuIcon class="h-7 w-7" />
    </button>
    <Drawer v-model:visible="drawerVisible" :style="{backgroundColor: isDark ? '#4B5563' : '#90CDF4'}">
      <template #header>
        <a :href="config.public.apiHome" class="flex items-center justify-center">
          <img
            :src="imgSrc"
            :key="imgSrc"
            class="ui-open:mr-3 h-9"
            alt="Tarsel Logo"
          />
          <span class="ml-3 self-center w-fit dark:text-white ui-not-open:hidden">
            <span class="block text-xl font-semibold">Tarsel</span>
            <!-- <span
              class="block max-w-[8em] overflow-hidden text-ellipsis whitespace-nowrap text-xs leading-4 text-gray-600 dark:text-gray-400"
            >
              {{ serverConfiguration?.version }}
            </span> -->
          </span>
        </a>
      </template>
      <div class="container flex flex-wrap sm:ui-open:items-start sm:ui-not-open:items-center flex-col sm:justify-start sm:w-fit">
        <div class="flex sm:order-2 order-1 sm:flex-col-reverse flex-row">
          <DarkModeSwitcher class="ml-1 mt-2 "/>
        </div>
        <div
          class="justify-between ui-open:block ui-not-open:hidden md:order-1 md:block md:w-auto ui-not-open:md:block sm:order-1 order-2"
        >
          <ul
            class="mt-4 flex flex-col ui-not-open:items-center ui-open:items-start md:mt-0 md:text-sm md:font-medium list-none"
          >
            <li v-for="(item, index) in navigation" :key="index" class="ui-not-open:w-fit ui-open:flex-1">
              <a
                :class="[ 
                  'block w-full mt-2 rounded py-2 pl-3 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-800',
                  item.current ? 'bg-blue-700 text-white dark:text-white md:bg-transparent md:text-blue-700' : 'text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white md:hover:text-blue-700 md:dark:hover:text-white'
                ]"
                :href="item.link"
                :aria-current="item.current ? 'page' : null"
              >
                <component :is="item.icon" class="inline h-6 w-6"></component>
                <span class="ml-2 ui-not-open:hidden">{{ item.name }}</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <template #footer>
        <div class="mt-4 flex flex-col ui-not-open:items-center ui-open:items-start md:mt-0 md:text-sm md:font-medium list-none">
          <a 
            @click="logout"
            :class="[ 
              'w-fit mt-2 rounded py-2 pl-3 pr-4 cursor-pointer flex items-center',
              'text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white md:hover:text-blue-700 md:dark:hover:text-white'
            ]"
          >
            <component :is="LogoutIcon" class="h-6 w-6"></component>
            <span class="ml-2">{{ translations['logout'] }}</span>
          </a>
        </div>  
      </template>
    </Drawer>
  </div>
</template>

<script setup lang="ts">
import { computed, inject } from 'vue';
import Drawer from 'primevue/drawer';
import { HomeIcon, ChartBarIcon, AdjustmentsIcon, MenuIcon, LogoutIcon } from '@heroicons/vue/solid';
import DarkModeSwitcher from '@/components/DarkModeSwitcher.vue';
import UserMenu from '@/components/UserMenu.vue';
import { ServerConfigKey } from '@/components/ServerConfigProvider.vue';
import getTranslations from '@/utils/translations';
import lightLogo from "@/assets/images/logo.png";
import darkLogo from "@/assets/images/logo-dark.png";
import { ThemeKey } from "@/components/ThemeProvider.vue";
const { isDark, imgSrc } = inject(await ThemeKey)!;
const language = useCookie('language');
const serverConfiguration = inject(await ServerConfigKey);
const route = useRoute();
const config = useRuntimeConfig()
const token = useCookie('token')
const id_client = useCookie('id_client')
const translations: any = await getTranslations('navbar', language.value);
const drawerVisible = ref<boolean>(false);

const logout = () => {
  const currentUrl = new URL(config.public.apiHome);
  currentUrl.port = "8000";
  window.location.href = `${currentUrl.origin}/logout`;
};

const navigation = computed(() => [
  { name: translations['home'], icon: HomeIcon, link: `${config.public.apiHome}`, current: route.path === `${config.public.apiHome}` },
  { name: translations['visualize'], icon: ChartBarIcon, link: '/visualize', current: route.path.startsWith('/visualize') },
  { name: translations['filters'], icon: AdjustmentsIcon, link: '/filters', current: route.path.startsWith('/filters') },
  // { name: translations['library'], icon: BookOpenIcon, link: '/library', current: route.path.startsWith('/library') },
  // { name: translations['network_explorer'], icon: GlobeIcon, link: '/network_explorer', current: route.path.startsWith('/network_explorer') },
  // { name: translations['capacity_planning'], icon: CheckCircleIcon, link: '/capacity_planning', current: route.path.startsWith('/capacity_planning') },
  // { name: translations['connectivity'], icon: CogIcon, link: '/connectivity', current: route.path.startsWith('/connectivity') },
]);
</script>
