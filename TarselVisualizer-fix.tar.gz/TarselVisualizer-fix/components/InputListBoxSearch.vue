<template>
  <div class="relative w-full" ref="elNets">
    <InputBase v-slot="{ id, childClass }" v-bind="otherAttrs" :error="error">
      <div :id="id" :class="[childClass, 'relative']">
        <input
          type="text"
          class="w-full rounded-md border h-6 border-gray-300 bg-white py-2 pl-3 pr-10 text-sm focus:border-blue-500 focus:outline-none dark:border-gray-600 dark:bg-neutral-800 dark:text-white"
          :placeholder="translations['search']"
          v-model="searchQuery"
          @focus="showOptions = true"
          @blur="handleBlur"
        />
        <button
          class="absolute inset-y-0 right-0 flex items-center pr-2"
          @click="toggleOptions"
        >
          <SelectorIcon 
            class="h-5 w-5 text-gray-400 transition-transform"
            :class="{ 'rotate-180': showOptions }"
            aria-hidden="true" 
          />
        </button>
      </div>
    </InputBase>

    <transition
      enter-active-class="transition duration-100 ease-out"
      enter-from-class="transform scale-95 opacity-0"
      enter-to-class="transform scale-100 opacity-100"
      leave-active-class="transition duration-75 ease-out"
      leave-from-class="transform scale-100 opacity-100"
      leave-to-class="transform scale-95 opacity-0"
    >
      <div
        v-if="showOptions"
        class="absolute z-50 mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-sm shadow-lg dark:bg-neutral-900 dark:shadow-white/10"
      >
        <div v-if="filteredItems.length === 0" class="px-4 py-2 text-gray-500 dark:text-gray-400">
          {{ translations['no_results'] }}
        </div>
        <ul v-else>
          <li
            v-for="item in filteredItems"
            :key="item.id"
            class="flex cursor-pointer items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800"
            @click="selectItem(item)"
          >
            <div class="flex-grow">
              <slot name="item" v-bind="item">
                {{ item.name || item.id }}
              </slot>
            </div>
            <CheckIcon
              v-if="isSelected(item)"
              class="h-5 w-5 text-blue-600 dark:text-blue-500"
            />
          </li>
        </ul>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { CheckIcon, SelectorIcon } from "@heroicons/vue/solid";
import InputBase from "@/components/InputBase.vue";
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('visualize', language.value);

const props = withDefaults(
  defineProps<{
    modelValue: any;
    multiple?: boolean;
    items: Array<{ id: number; [n: string]: any }>;
    error?: string;
    searchFields?: string[];
  }>(),
  {
    error: "",
    multiple: false,
    searchFields: () => ['name', 'id']
  },
);

const emit = defineEmits<{
  'update:modelValue': [value: typeof props.modelValue];
}>();

const attrs = useAttrs();
const searchQuery = ref('');
const elNets = ref();
const showOptions = ref(false);

watch(() => props.modelValue, (newValue) => {
  if (!newValue) {
    searchQuery.value = '';
  } else if (Array.isArray(newValue)) {
    searchQuery.value = '';
  } else {
    searchQuery.value = newValue.maskedName || newValue.id || '';
  }
}, { immediate: true });

const otherAttrs = computed(() => {
  const { class: _, ...others } = attrs;
  return others;
});

const filteredItems = computed(() => {
  if (!searchQuery.value) return props.items;
  
  const query = searchQuery.value.toLowerCase();
  return props.items.filter(item => {
    return props.searchFields.some(field => {
      const value = item[field];
      return value && String(value).toLowerCase().includes(query);
    });
  });
});

const isSelected = (item: any) => {
  if (props.multiple) {
    return Array.isArray(props.modelValue) && props.modelValue.some((selected: any) => selected.id === item.id);
  }
  return props.modelValue && props.modelValue.id === item.id;
};

const selectItem = (item: any) => {
  if (props.multiple) {
    const currentValue = Array.isArray(props.modelValue) ? props.modelValue : [];
    const itemIndex = currentValue.findIndex((selected: any) => selected.id === item.id);
    
    if (itemIndex === -1) {
      emit('update:modelValue', [...currentValue, item]);
    } else {
      const newValue = [...currentValue];
      newValue.splice(itemIndex, 1);
      emit('update:modelValue', newValue);
    }
  } else {
    emit('update:modelValue', item);
    searchQuery.value = item.maskedName
    showOptions.value = false;
  }
};

const toggleOptions = () => {
  showOptions.value = !showOptions.value;
};

const handleBlur = () => {
  // Small delay to allow click events to fire on options
  setTimeout(() => {
    showOptions.value = false;
  }, 150);
};

const handleClickOutside = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    if (elNets.value && !elNets.value.contains(target) && 
        !target.closest('.relative.flex.flex-col')) {
          showOptions.value = false;
    }
}

// Adiciona e remove o event listener
onMounted(() => {
    document.addEventListener('click', handleClickOutside);
});

onUnmounted(() => {
    document.removeEventListener('click', handleClickOutside);
});
</script>

<script lang="ts">
export default {
  inheritAttrs: false,
};
</script>