<!-- SPDX-FileCopyrightText: 2022 Free Mobile -->
<!-- SPDX-License-Identifier: AGPL-3.0-only -->

<template>
  <slot></slot>
</template>

<script lang="ts" setup>
import { useDark, useToggle } from "@vueuse/core";
import lightLogo from "@/assets/images/logo.png";
import darkLogo from "@/assets/images/logo-dark.png";

const isDark = useDark();
const toggleDark = useToggle(isDark);
const imgSrc = computed(() => {
  return isDark.value ? darkLogo : lightLogo;
});

provide(ThemeKey, {
  isDark: readonly(isDark),
  toggleDark,
  imgSrc,
});
</script>

<script lang="ts">
import type { InjectionKey, Ref } from "vue";
export const ThemeKey: InjectionKey<{
  isDark: Readonly<Ref<boolean>>;
  toggleDark: () => void;
  imgSrc: globalThis.ComputedRef<string>
}> = Symbol();
</script>
