import type { GraphType } from "./graphtypes";

export function formatXps(value: number) {
  value = Math.abs(value);
  const suffixes = ["", "K", "M", "G", "T", "P", "Ex", "Z"];
  let idx = 0;
  while (value >= 1000 && idx < suffixes.length) {
    value /= 1000;
    idx++;
  }
  return `${value.toFixed(2)}${suffixes[idx]}`;
}

// Order function for field names
export function compareFields(f1: string, f2: string) {
  const metric: { [prefix: string]: number } = {
    Dat: 1,
    Tim: 2,
    Byt: 3,
    Pac: 4,
    Exp: 7,
    Sam: 8,
    Seq: 9,
    Src: 10,
    Dst: 12,
    InI: 11,
    Out: 13,
  };
  const m1 = metric[f1.substring(0, 3)] || 100;
  const m2 = metric[f2.substring(0, 3)] || 100;
  const cmp = m1 - m2;
  if (cmp) {
    return cmp;
  }
  if (m1 === 10) {
    f1 = f1.substring(3);
    f2 = f2.substring(3);
  } else if (m1 === 11) {
    if (f1.startsWith("InIf")) {
      f1 = f1.substring(4);
    } else {
      f1 = f1.substring(5);
    }
    if (f2.startsWith("InIf")) {
      f2 = f2.substring(4);
    } else {
      f2 = f2.substring(5);
    }
  }
  return f1.localeCompare(f2);
}

export type Units = "l3bps" | "l2bps" | "pps" | "inl2%" | "outl2%";
export type GraphSankeyHandlerInput = {
  start: string;
  end: string;
  dimensions: string[];
  limit: number;
  filter: string;
  units: Units;
};
export type GraphLineHandlerInput = GraphSankeyHandlerInput & {
  points: number;
  bidirectional: boolean;
  "previous-period": boolean;
  total: boolean;
};
export type GraphSankeyHandlerOutput = {
  rows: string[][];
  xps: number[];
  nodes: string[];
  links: {
    source: string;
    target: string;
    xps: number;
  }[];
};
export type GraphLineHandlerOutput = {
  t: string[];
  rows: string[][];
  points: number[][];
  axis: number[];
  "axis-names": Record<number, string>;
  average: number[];
  min: number[];
  max: number[];
  "95th": number[];
};
export type GraphSankeyHandlerResult = GraphSankeyHandlerOutput & {
  graphType: Extract<GraphType, "sankey">;
} & Pick<GraphSankeyHandlerInput, "start" | "end" | "dimensions" | "units">;
export type GraphLineHandlerResult = GraphLineHandlerOutput & {
  graphType: Exclude<GraphType, "sankey">;
} & Pick<
    GraphLineHandlerInput,
    "start" | "end" | "dimensions" | "units" | "bidirectional"
  >;