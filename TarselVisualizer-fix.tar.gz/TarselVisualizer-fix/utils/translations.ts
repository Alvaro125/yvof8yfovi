import type { language } from "@codemirror/language";

/**
 * @function getTranslations
 * @description - pt: Busca e analisa as traduções JSON para uma determinada página da API.
 *                es: Obtiene y analiza las traducciones JSON de una página determinada desde la API.
 * @param {string} page - pt: O nome da página para a qual as traduções serão buscadas.
 *                        es: El nombre de la página para la que se obtendrán las traducciones.
 * @returns {Promise<{[key: string]: JSON}>} - pt: Uma promessa que é resolvida com um mapeamento de objeto
 * chaves de tradução para seus valores JSON correspondentes, ou um objeto vazio se houver um erro.
 *                                             es: Una promesa que se resuelve con un mapeo de objeto de claves de traducción
 * para sus valores JSON correspondientes o un objeto vacío si hay un error.
 */
const getTranslations = async (
  page: string,
  language: string
): Promise<{ [key: string]: JSON }> => {
  const config = useRuntimeConfig();
  try {
    const response = await fetch(
      `${config.public.apiHome}/export_translations`,
      {
        method: "POST",
        mode: "cors",
        headers: {
          "page": page,
        },
        body: JSON.stringify({ language }),
      }
    );
    try {
      const keys = await response.text();
      return JSON.parse(keys);
    } catch (error) {
      console.error("Error parsing JSON:", error);
      return {};
    }
  } catch (error) {
    console.error(error);
    return {};
  }
};

export default getTranslations;
