// SPDX-FileCopyrightText: 2022 Free Mobile
// SPDX-License-Identifier: AGPL-3.0-only

// See https://design.gitlab.com/data-visualization/color
const colors = {
  blue: [
    "#caf0f8", // 50
    "#ade8f4", // 100
    "#90e0ef", // 200
    "#48cae4", // 300
    "#00b4d8", // 400
    "#0096c7", // 500
    "#0077b6", // 600
    "#023e8a", // 700
    "#232fcf", // 800
    "#1e23a8", // 900
    "#03045e", // 950
  ],
  orange: [
    "#fff200",
    "#ffe600",
    "#ffd900",
    "#ffcc00",
    "#ffbf00",
    "#ffb300",
    "#ffa600",
    "#ff9900",
    "#ff8c00",
    "#ff8000",
    "#fc2f00",
  ],
  aqua: [
    "#f6cacc",
    "#f1a7a9",
    "#ec8385",
    "#e66063",
    "#e35053",
    "#dd2c2f",
    "#d02224",
    "#bd1f21",
    "#ac1c1e",
    "#9c191b",
    "#5a0002",
  ],
  green: [
    "#b7efc5",
    "#92e6a7",
    "#6ede8a",
    "#4ad66d",
    "#2dc653",
    "#25a244",
    "#208b3a",
    "#1a7431",
    "#155d27",
    "#10451d",
    "#0f3300",
  ],
  magenta: [
    "#ea698b",
    "#d55d92",
    "#c05299",
    "#ac46a1",
    "#973aa8",
    "#822faf",
    "#6d23b6",
    "#6411ad",
    "#571089",
    "#47126b",
    "#820263",
  ],
};

const orderedColors = ["blue", "orange", "aqua", "green", "magenta"] as const;

const darkPalette = [5, 6, 7, 8, 9, 10]
  .map((idx) =>
    orderedColors.map(
      (colorName: keyof typeof colors) => colors[colorName][idx],
    ),
  )
  .flat();
const lightPalette = [5, 4, 3, 2, 1, 0]
  .map((idx) => orderedColors.map((colorName) => colors[colorName][idx]))
  .flat();
const lightenColor = (color: string, amount: number) =>
  "#" +
  color
    .replace(/^#/, "")
    .replace(/../g, (color) =>
      (
        "0" +
        Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)
      ).slice(-2),
    );

export function dataColor(
  index: number,
  alternate = false,
  theme: "light" | "dark" = "light",
) {
  const palette = theme === "light" ? lightPalette : darkPalette;
  const correctedIndex = index % 2 === 0 ? index : index + orderedColors.length;
  const computed = palette[correctedIndex % palette.length];
  if (!alternate) {
    return computed;
  }
  return lightenColor(computed, 20);
}

export function dataColorGrey(
  index: number,
  alternate = false,
  theme: "light" | "dark" = "light",
) {
  const palette =
    theme === "light"
      ? ["#212529", "#343a40", "#495057", "#6c757d", "#adb5bd"].reverse()
      : ["#d0b8ac", "#f3d8c7", "#efe5dc", "#fbfefb", "#ffffff"];
  const computed = palette[index % palette.length];
  if (!alternate) {
    return computed;
  }
  return lightenColor(computed, 10);
}
