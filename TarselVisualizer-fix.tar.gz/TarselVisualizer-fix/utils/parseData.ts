export default function parseData(data: any) {
    return JSON.parse(JSON.stringify(data));
}