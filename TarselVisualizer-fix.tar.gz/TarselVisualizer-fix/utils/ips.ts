export function ipToBinary(ip: string): string {
  // Convert an IP address to its binary representation
  return ip.split('.')
      .map(octet => parseInt(octet).toString(2).padStart(8, '0'))
      .join('');
}

export function isIpInSubnet(ip: string, subnet: string, maskLength: number): boolean {
  const ipBinary = ipToBinary(ip);
  const subnetBinary = ipToBinary(subnet);

  return ipBinary.substring(0, maskLength) === subnetBinary.substring(0, maskLength);
}

export function ipv6ToIpv4(ipv6Address: string): string {
  // Verifica se o endereço é um IPv4-mapped IPv6 (contém '::ffff:')
  if (!ipv6Address.toLowerCase().includes("::ffff:")) {
    throw new Error("O endereço IPv6 fornecido não é um endereço IPv4-mapped IPv6.");
  }

  // Extrai a parte IPv4 do endereço
  const ipv4Part = ipv6Address.split("::ffff:").pop();

  if (!ipv4Part) {
    throw new Error("Parte IPv4 inválida.");
  }

  // Divide a parte IPv4 em duas partes hexadecimais
  const hexParts = ipv4Part.split(":");

  if (hexParts.length !== 2) {
    throw new Error("Formato inválido para endereço IPv4-mapped IPv6.");
  }

  // Converte cada parte de hexadecimal para decimal
  const octets = hexParts.map(part => parseInt(part, 16).toString());

  // Une os octetos para formar o endereço IPv4
  const ipv4Address = octets.join(".");
  return ipv4Address;
}

function ipv4ToIpv6(ipv4Address: string): string {
  // Verifica se o endereço é um IPv4 válido
  const ipv4Regex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (!ipv4Regex.test(ipv4Address)) {
    throw new Error("O endereço IPv4 fornecido não é válido.");
  }

  // Divide o endereço IPv4 em octetos
  const octets = ipv4Address.split('.').map(Number);

  // Combina dois octetos em cada segmento hexadecimal
  const part1 = ((octets[0] << 8) + octets[1]).toString(16).padStart(4, '0');
  const part2 = ((octets[2] << 8) + octets[3]).toString(16).padStart(4, '0');

  // Forma o endereço IPv6 mapeado
  const ipv6Address = `::ffff:${part1}:${part2}`;

  return ipv6Address;
}

export function formatIPAddress(ip:string) {
  // Verifica se é um IPv6 válido (com ou sem máscara)
  const ipv6Regex = /^([a-fA-F0-9:]+)(\/\d{1,3})?$/;
  // Verifica se é um IPv4 válido (com ou sem máscara)
  const ipv4Regex = /^((\d{1,3}\.){3}\d{1,3})(\/\d{1,3})?$/;
  // Verifica se é um IPv4 mapeado em IPv6 válido (com ou sem máscara)
  const ipv4MappedIPv6Regex = /^::ffff:(\d{1,3}\.){3}\d{1,3}(\/\d{1,3})?$/;

  const ipv4MappedIPv6Match = ip.match(ipv4MappedIPv6Regex);
  const ipv4Match = ip.match(ipv4Regex);
  const ipv6Match = ip.match(ipv6Regex);

  if (ipv4MappedIPv6Match) {
      const hasMask = ipv4MappedIPv6Match[ipv4MappedIPv6Match.length-1];
    return hasMask ? ip : `${ip}/128`; // Retorna o IP com máscara, ou adiciona /128 se não tiver máscara
  } else if (ipv4Match) {
    // É um IPv4
    const ipv4Address = ipv4Match[1];
    const mask = ipv4Match[3] || "/128";
    const numberMask = Number(mask.split('/')[1])
    let formatMask = `/${numberMask<33?numberMask+96:numberMask}`
    return `${ipv4ToIpv6(ipv4Address)}${formatMask}`;
  } else if (ipv6Match) {
    // É um IPv6
    const hasMask = ipv6Match[2];
    // Adiciona /128 se não houver máscara
    return hasMask ? ip : `${ip}/128`;
  } else {
    // Não é um IP válido
    throw new Error('Endereço IP inválido');
  }
}
export function binaryToIp(binary: string): string {
  // Convert a binary string back to an IP address
  return binary.match(/.{1,8}/g)!.map(byte => parseInt(byte, 2).toString()).join('.');
}

export function calculateSubnets(network: string, currentMask: number, newMask: number): string[] {
  // Calculate subnets from a network address with given current and new masks
  const [networkAddress, prefixLength] = network.split('/');
  const mask = parseInt(prefixLength, 10);

  if (newMask <= mask) {
      throw new Error('New mask should be greater than the current mask');
  }

  const binaryNetwork = ipToBinary(networkAddress).slice(0, mask);
  const subnetCount = Math.pow(2, newMask - mask);
  const subnets: string[] = [];

  for (let i = 0; i < subnetCount; i++) {
      const subnetBinary = (binaryNetwork + i.toString(2).padStart(newMask - mask, '0')).padEnd(32, '0');
      const subnetIp = binaryToIp(subnetBinary);
      subnets.push(`${subnetIp}/${newMask}`);
  }

  return subnets;
}