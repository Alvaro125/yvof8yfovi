const nameDimensions: Record<string, string> = {
  'ExporterName': 'Device',
  'ExporterAddress': 'Device IP',
  'ExporterGroup': 'Device Group',
  'ExporterRole': 'Device Role',
  'ExporterSite': 'Device Site',
  'ExporterRegion': 'Device Region',
  'ExporterTenant': 'Device Tenant',
  'SrcAddr': 'Source IP',
  'DstAddr': 'Destination IP',
  'SrcNetPrefix': 'Source Net Prefix',
  'DstNetPrefix': 'Destination Net Prefix',
  'SrcAS': 'Source ASN',
  'DstAS': 'Destination ASN',
  'SrcNetName': 'Source Net Name',
  'DstNetName': 'Destination Net Name',
  'SrcNetRole': 'Source Net Role',
  'DstNetRole': 'Destination Net Role',
  'SrcNetSite': 'Source Net Site',
  'DstNetSite': 'Destination Net Site',
  'SrcNetRegion': 'Source Net Region',
  'DstNetRegion': 'Destination Net Region',
  'SrcNetTenant': 'Source Net Tenant',
  'DstNetTenant': 'Destination Net Tenant',
  'SrcCountry': 'Source Country',
  'DstCountry': 'Destination Country',
  'SrcGeoCity': 'Source City',
  'DstGeoCity': 'Destination City',
  'SrcGeoState': 'Source State',
  'DstGeoState': 'Destination State',
  'DstASPath': 'Destination ASPath',
  'Dst1stAS': 'First Destination AS',
  'Dst2ndAS': 'Second Destination AS',
  'Dst3rdAS': 'Third Destination AS',
  'DstCommunities': 'Destination Community',
  'InIfName': 'Source Interface Name',
  'OutIfName': 'Destination Interface Name',
  'InIfDescription': 'Source Interface Description',
  'OutIfDescription': 'Destination Interface Description',
  'InIfSpeed': 'Source Interface Speed',
  'OutIfSpeed': 'Destination Interface Speed',
  'InIfConnectivity': 'Source Connectivity',
  'OutIfConnectivity': 'Destination Connectivity',
  'InIfProvider': 'Source Provider',
  'OutIfProvider': 'Destination Provider',
  'InIfBoundary': 'Source Interface Boundary',
  'OutIfBoundary': 'Destination Interface Boundary',
  'EType': 'Ethernet Type',
  'Proto': 'Protocol',
  'SrcPort': 'Source Port',
  'DstPort': 'Destination Port',
  'PacketSizeBucket': 'Packet Size',
  'ForwardingStatus': 'Forwarding Status'
};

const changeDimensionsNames = (name: string) => {
    for (const [key, value] of Object.entries(nameDimensions)) {
        const regex = new RegExp(`\\b${key}\\b`, 'g');
        name = name.replace(regex, value);
    }

    return name;
}

interface Dimension {
  id: number,
  name: string;
  maskedName: string;
  color: string;
}

const selectedDimensions = ref<Dimension[]>([]);

export {nameDimensions, changeDimensionsNames, selectedDimensions}

export const typeDimensions: Record<string, string> = {
  'ExporterName': 'string',
  'ExporterAddress': 'string',
  'ExporterGroup': 'string',
  'ExporterRole': 'string',
  'ExporterSite': 'string',
  'ExporterRegion': 'string',
  'ExporterTenant': 'string',
  'SrcAddr': 'string',
  'DstAddr': 'string',
  'SrcNetPrefix': 'string',
  'DstNetPrefix': 'string',
  'SrcAS': 'string',
  'DstAS': 'string',
  'SrcNetName': 'string',
  'DstNetName': 'string',
  'SrcNetRole': 'string',
  'DstNetRole': 'string',
  'SrcNetSite': 'string',
  'DstNetSite': 'string',
  'SrcNetRegion': 'string',
  'DstNetRegion': 'string',
  'SrcNetTenant': 'string',
  'DstNetTenant': 'string',
  'SrcCountry': 'string',
  'DstCountry': 'string',
  'SrcGeoCity': 'string',
  'DstGeoCity': 'string',
  'SrcGeoState': 'string',
  'DstGeoState': 'string',
  'DstASPath': 'string',
  'Dst1stAS': 'string',
  'Dst2ndAS': 'string',
  'Dst3rdAS': 'string',
  'DstCommunities': 'string',
  'InIfName': 'string',
  'OutIfName': 'string',
  'InIfDescription': 'string',
  'OutIfDescription': 'string',
  'InIfSpeed': 'string',
  'OutIfSpeed': 'string',
  'InIfConnectivity': 'string',
  'OutIfConnectivity': 'string',
  'InIfProvider': 'string',
  'OutIfProvider': 'string',
  'InIfBoundary': 'string',
  'OutIfBoundary': 'string',
  'EType': 'string',
  'Proto': 'string',
  'SrcPort': 'number',
  'DstPort': 'number',
  'PacketSizeBucket': 'string',
  'ForwardingStatus': 'string'
};