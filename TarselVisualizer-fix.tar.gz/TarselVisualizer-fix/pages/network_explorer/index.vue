<template>
  <div class="grow overflow-y-auto bg-white dark:bg-slate-800">
    <NetworkGraph></NetworkGraph>
    <div class="ml-5">
      <button :class="['mx-2', activeTable === 'applications' ? 'border-b-4 border-blue-700 text-blue-700' : 'border-hidden']"
      @click="changeTable('applications')"
      >{{ translations['applications'] }}</button>
      <button :class="['mx-2', activeTable === 'country' ? 'border-b-4 border-blue-700 text-blue-700' : 'border-hidden']"
      @click="changeTable('country')"
      >{{ translations['countries'] }}</button>
      <button :class="['mx-2', activeTable === 'asn' ? 'border-b-4 border-blue-700 text-blue-700' : 'border-hidden']"
      @click="changeTable('asn')"
      >{{ translations['asn'] }}</button>
    </div>  
    <div class="m-4">
      <table class="min-w-full border-collapse overflow-hidden">
        <thead>
          <tr>
            <th class="w-3/5 text-left border-l-0 border-t-0 border-b border-gray-400 dark:border-slate-700 px-2 py-1">{{ nameTable }}</th>
            <th class="border-l border-t-0 border-b border-gray-400 dark:border-slate-700 px-2 py-1">{{ translations['internal'] }}</th>
            <th class="border-l border-t-0 border-b border-gray-400 dark:border-slate-700 px-2 py-1">{{ translations['inbound'] }}</th>
            <th class="border-l border-t-0 border-b border-gray-400 dark:border-slate-700 px-2 py-1">{{ translations['outbound'] }}</th>
            <th class="border-l border-t-0 border-b border-gray-400 dark:border-slate-700 px-2 py-1">{{ translations['through'] }}</th>
            <th class="border-l border-t-0 border-b border-gray-400 dark:border-slate-700 px-2 py-1">{{ translations['other'] }}</th>
            <th class="border-l border-t-0 border-b border-r-0 border-gray-400 dark:border-slate-700 px-2 py-1">{{ translations['total'] }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(info, index) in paginatedData" :key="index" class="hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors">
            <td class="w-1/2 text-left text-sm border-l-0 border-t border-b-0 border-r border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.name }}</td>
            <td class="text-right text-sm border-l border-t border-b-0 border-r border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.internalBytes }}</td>
            <td class="text-right text-sm border-l border-t border-b-0 border-r border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.inboundBytes }}</td>
            <td class="text-right text-sm border-l border-t border-b-0 border-r border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.outboundBytes }}</td>
            <td class="text-right text-sm border-l border-t border-b-0 border-r border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.throughBytes }}</td>
            <td class="text-right text-sm border-l border-t border-b-0 border-r border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.otherBytes }}</td>
            <td class="text-right text-sm border-l border-t border-b-0 border-r-0 border-gray-400 dark:border-slate-700 px-2 py-1">{{ info.totalBytes }}</td>
          </tr>
        </tbody>
      </table>
      <PrimePaginator :rows="rowsPerPage" :totalRecords="tableInfo.length" @page="page = $event.page + 1"></PrimePaginator>
    </div>
  </div>
</template>

<script lang="ts" setup>
import getTranslations from '@/utils/translations';

const config = useRuntimeConfig();

const language = useCookie('language');
const translations: any = await getTranslations('network_explorer_page', language.value);

const activeTable = ref('country')
const nameTable = computed(() => {
  if (activeTable.value === 'country') {
    return translations['country']
  } else if (activeTable.value === 'applications') {
    return translations['application']
  } else {
    return translations['asn']
  }
})
const tableInfo = ref([])
const page = ref(1)
const rowsPerPage = 20

// pt: Função para o conteúdo da tabela de acordo com a paginação
// es: Función para contenido de tabla según paginación
const paginatedData = computed(() => {
  const start = (page.value - 1) * rowsPerPage
  const end = start + rowsPerPage
  return tableInfo.value.slice(start, end)
})

// pt: Função para fazer a requisição para receber os dados da tabela
// es: Función para realizar la solicitud de recibir datos de la tabla
const fetchTableData = async () => {
  try {
    const token = useCookie("token");
    const id_client = useCookie("id_client");
    const data = await $fetch(`${config.public.goServer}/consult/network_explorer/${activeTable.value}?token=${token.value}&id_client=${id_client.value}`, {
      method: "GET",
    })

    const parsedData = parseData(data);

    if (!parsedData) {
      throw new Error("Data is null");
    }
    
    tableInfo.value = parsedData
    page.value = 1
  } catch(err: any) {
    console.error(err.message);
  }
}

// pt: Função para alternar entre tabelas e fazer a chamada de requisição novamente
// es: Función para cambiar entre tablas y volver a realizar la llamada de solicitud
const changeTable = (tableName: string) => {
  activeTable.value = tableName;
  fetchTableData()
}
fetchTableData()
</script>