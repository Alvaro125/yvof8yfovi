<template>
  <div class="flex h-full w-full flex-col">
    <div class="flex justify-end gap-2 mt-5">
      <button @click="openExportModal('csv')"
        class="bg-slate-400 hover:bg-slate-200 transition-all text-gray-950 py-1 px-2 rounded-md border-slate-800 border-[1px] dark:bg-neutral-800 dark:text-neutral-50 dark:border-neutral-50">
        {{ 'Export CSV' }}<span class="pi pi-table pl-2"></span>
      </button>
      <button @click="openExportModal('pdf')"
        class="bg-slate-400 hover:bg-slate-200 transition-all text-gray-950 py-1 px-2 rounded-md border-slate-800 border-[1px] dark:bg-neutral-800 dark:text-neutral-50 dark:border-neutral-50">
        {{ translations_visualize['export_pdf'] }}<span class="pi pi-upload pl-2"></span>
      </button>
      <button @click="op = true"
        class="bg-slate-400 hover:bg-slate-200 transition-all text-gray-950 dark:bg-neutral-800 dark:text-neutral-50 py-1 px-2 rounded-md border-slate-800 dark:border-neutral-50 border-[1px]">
        {{ translations_visualize['save_filter'] }}<span class="pi pi-save pl-2"></span>
      </button>
      <button @click="openOptions" class="py-1 px-2 rounded-md"
        :class="!viewOption ? 'bg-slate-400 text-gray-950 dark:text-neutral-800 dark:bg-neutral-100 dark:border-neutral-50 border-[1px]' : 'bg-slate-900 text-gray-200 dark:text-neutral-900 dark:bg-neutral-400'">
        {{ translations_visualize['query'] }}<span class="pi pi-search pl-2"></span>
      </button>
    </div>
    <PrimeDialog v-model:visible="op" modal :header="translations_visualize['create_filter']"
      :style="{ width: '25rem' }">
      <span class="text-surface-500 dark:text-surface-400 block mb-8">{{ translations_visualize['update_info'] }}</span>
      <div class="flex items-center gap-4 mb-4">
        <label for="username" class="font-semibold w-22">{{ translations_visualize['filter_name'] }}</label>
        <PrimeInputText id="username" class="flex-auto" autocomplete="off" v-model="nameFilter" />
      </div>
      <div class="flex justify-end gap-2">
        <PrimeButton type="button" :label="translations_visualize['cancel']" severity="secondary" @click="op = false">
        </PrimeButton>
        <PrimeButton type="button" :label="translations_visualize['save']" @click="() => {
          op = false;
          SaveFilter()
        }"></PrimeButton>
      </div>
    </PrimeDialog>
    
    <!-- Modal para nomear arquivos de exportação -->
    <PrimeDialog v-model:visible="exportModal" modal :header="exportType === 'csv' ? 'Export CSV' : 'Export PDF'" :style="{ width: '25rem' }">
      <span class="text-surface-500 dark:text-surface-400 block mb-8">{{ translations_visualize['enter_filename'] || 'Enter filename for export' }}</span>
      <div class="flex items-center gap-4 mb-4">
        <label for="filename" class="font-semibold w-22">{{ translations_visualize['filename'] || 'Filename' }}</label>
        <PrimeInputText id="filename" class="flex-auto" autocomplete="off" v-model="exportFilename" />
      </div>
      <div class="flex justify-end gap-2">
        <PrimeButton type="button" :label="translations_visualize['cancel']" severity="secondary" @click="exportModal = false">
        </PrimeButton>
        <PrimeButton type="button" :label="translations_visualize['export'] || 'Export'" @click="confirmExport">
        </PrimeButton>
      </div>
    </PrimeDialog>
    
    <div class="flex h-full w-full flex-col lg:flex-row-reverse">
      <OptionsPanel v-model="state" :loading="isFetching" class="print:hidden" @cancel="canAbort && cancel()"
        :view="(state) => viewFlow = state" :open="viewOption" />
      <div ref="pdfContent" class="grow overflow-y-auto bg-white dark:bg-zinc-800">
        <DataTableFlow v-if="viewFlow" />
        <LoadingOverlay v-if="!viewFlow" :loading="isFetching">
          <RequestSummaryInfo :request="request" class="absolute ml-2" />
          <div class="mx-4 my-2">
            <InfoBox v-if="errorMessage" kind="error">
              <strong>{{ translations_visualize['fetch_data_error'] }}&nbsp;</strong>{{ errorMessage }}
            </InfoBox>
            <ResizeRow :slider-width="10" :height="graphHeight" width="auto" slider-bg-color="#eee1"
              slider-bg-hover-color="#ccc3" class="break-inside-avoid-page">
              <DataGraph ref="pdfChart" :data="fetchedData" :highlight="highlightedSerie"
                @update:time-range="updateTimeRange" />
            </ResizeRow>
            <DataTable :data="fetchedData" class="my-2 break-inside-avoid-page"
              @highlighted="(n) => (highlightedSerie = n)" :th95="true" :limit="state?.limit" />
          </div>
        </LoadingOverlay>
      </div>
    </div>
    <PrimeToast />
    <router-view />
  </div>
</template>

<script setup lang="ts">
import { ref, watch, computed } from "vue";
import { useFetch, type AfterFetchContext } from "@vueuse/core";
import { ResizeRow } from "vue-resizer";
import LZString from "lz-string";
import InfoBox from '@/components/InfoBox.vue';
import LoadingOverlay from '@/components/LoadingOverlay.vue';
import RequestSummary from '@/components/widgets/VisualizePage/RequestSummary.vue';
import DataTable from '@/components/widgets/VisualizePage/DataTable.vue';
import DataGraph from '@/components/widgets/VisualizePage/DataGraph.vue';
import DataTableFlow from "@/components/widgets/VisualizePage/DataTableFlow.vue";
import OptionsPanel, { type ModelType } from '@/components/widgets/VisualizePage/OptionsPanel.vue';
import type { GraphType } from '@/utils/graphtypes';
import type {
  GraphSankeyHandlerInput,
  GraphLineHandlerInput,
  GraphSankeyHandlerOutput,
  GraphLineHandlerOutput,
  GraphSankeyHandlerResult,
  GraphLineHandlerResult
} from "@/utils";
import { forEach, forIn, isEqual, omit, pick } from 'lodash-es';
import { useToast } from 'primevue/usetoast';
import { selectedDimensions } from '~/utils/dimensions';
import { ServerConfigKey } from "@/components/ServerConfigProvider.vue";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import getTranslations from '@/utils/translations';
import { ThemeKey } from "~/components/ThemeProvider.vue";

const language = useCookie('language');
const translations_visualize: any = await getTranslations('visualize', language.value);

const serverConfiguration = inject(await ServerConfigKey)!;
const { isDark, toggleDark } = inject(await ThemeKey)!;
const toast = useToast();
const cookieToken = useCookie('token')
const cookieIdClient = useCookie('id_client')

const pdfContent = ref(null);
const pdfChart = ref(null);

// pt: Função para gerar os detalhes do gráfico do pdf
// es: Función para generar detalles de gráficos en formato PDF
const addAttrPDF = (_pdf: jsPDF, name: string, content: string | string[], linePosition: { value: number }) => {
  const negate = ['truncate-v4', 'truncate-v6', 'units', 'bidirectional', 'previousPeriod'];
  if (negate.includes(name)) { return };

  const lineHeight = 10; // Altura de cada linha
  const pageHeight = _pdf.internal.pageSize.getHeight(); // Altura total da página
  const marginBottom = 10; // Margem inferior para evitar corte
  const pageWidth = _pdf.internal.pageSize.getWidth(); // Largura da página
  const marginLeft = 21; // Margem esquerda

  // Verifica se há espaço suficiente na página para o título
  if (linePosition.value + lineHeight > pageHeight - marginBottom) {
    _pdf.addPage();
    linePosition.value = 20; // Reinicia a posição na nova página
  }

  // Adiciona o título (campo `name`) em negrito
  _pdf.setFont("Helvetica", "bold");
  _pdf.setFontSize(13);
  _pdf.text(21, linePosition.value, `${translations_visualize[name]}:`);
  linePosition.value += lineHeight; // Move para a próxima linha

  // Ajusta o conteúdo (valores do campo)
  _pdf.setFont("Helvetica", "normal");

  if (Array.isArray(content)) {
    content.forEach((item) => {
      if (linePosition.value + lineHeight > pageHeight - marginBottom) {
        _pdf.addPage();
        linePosition.value = 20; // Reinicia a posição na nova página
      }

      // Adiciona cada valor com indentação
      if (name === 'dimensions') {
        _pdf.text(marginLeft + 4, linePosition.value, `- ${changeDimensionsNames(item)}`);
      } else {
        _pdf.text(marginLeft + 4, linePosition.value, `- ${item}`);
      }
      linePosition.value += lineHeight; // Move para a próxima linha
    });
  } else {
    // Quebra o texto longo em várias linhas
    const textLines = _pdf.splitTextToSize(content as string, pageWidth - 2 * marginLeft);

    textLines.forEach((line) => {
      if (linePosition.value + lineHeight > pageHeight - marginBottom) {
        _pdf.addPage();
        linePosition.value = 20; // Reinicia a posição na nova página
      }

      // Adiciona cada linha do texto quebrado
      _pdf.text(marginLeft + 4, linePosition.value, line);
      linePosition.value += lineHeight; // Move para a próxima linha
    });
  }
};


const generateCSV = () => {
  if (!fetchedData.value) return;

  const data = fetchedData.value;
  const unit = ["inl2%", "outl2%"].includes(data.units || "bps")
    ? "%"
    : (data.units || "bps").slice(-3);
  
  const formatValue = (v: number): string =>
    unit === "%" ? `${v.toFixed(0)}%` : `${formatXps(v)}${unit}`;
  
  let csvContent = '';
  
  if (data.graphType === 'sankey') {
    // Para gráfico Sankey
    const headers = [...data.dimensions, 'Average'];
    csvContent = headers.join(',') + '\n';
    
    // Adiciona as linhas de dados
    data.rows.forEach((row, idx) => {
      const line = [...row, formatValue(data.xps[idx])];
      csvContent += line.map(v => `"${v}"`).join(',') + '\n';
    });
    
    // Adiciona linha de Total
    const totalValues = [
      ...Array(data.dimensions.length).fill('Total'),
      formatValue(data.xps.reduce((ac, v) => ac + v, 0))
    ];
    csvContent += totalValues.map(v => `"${v}"`).join(',') + '\n';
    
  } else {
    // Para outros tipos de gráfico (line, stacked, etc)
    const headers = [...data.dimensions, 'Min', 'Max', 'Average', '~95th'];
    csvContent = headers.join(',') + '\n';
    
    // Adiciona as linhas de dados
    data.rows.forEach((row, idx) => {
      const stats = [
        formatValue(data.min[idx]),
        formatValue(data.max[idx]),
        formatValue(data.average[idx]),
        formatValue(data['95th'][idx])
      ];
      
      const line = [...row, ...stats];
      csvContent += line.map(v => `"${v}"`).join(',') + '\n';
    });
    
    // Adiciona linha de Total
    const totalLine = data.points[data.points.length - 1];
    const totalValues = [
      ...Array(data.dimensions.length).fill('...'),
      formatValue(Math.min(...totalLine.slice(0, -1))),
      formatValue(Math.max(...totalLine)),
      formatValue(data.average[data.average.length - 1]),
      formatValue(data['95th'][data['95th'].length - 1])
    ];
    csvContent += totalValues.map(v => `"${v}"`).join(',') + '\n';
  }
  
  // Criar e baixar o arquivo
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `${exportFilename.value}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  toast.add({ 
    severity: 'success', 
    summary: translations_visualize['success_message'], 
    detail: 'CSV exported successfully', 
    life: 3000 
  });
};
// pt: Função para gerar pdf do gráfico da página visualize
// es: Función para generar PDF a partir del gráfico de página visualize
const generatePDF = async () => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const linePosition = { value: 35 }; // Controla a posição vertical

  pdf.setFontSize(16);
  pdf.text("Details:", 85, 20);

  pdf.setFontSize(13);

  // Itera sobre os campos do objeto `state.value` e adiciona ao PDF
  for (const key in state.value) {
    // Verifica se a propriedade é uma lista ou um valor único
    if (Array.isArray(state.value[key])) {
      addAttrPDF(pdf, key, state.value[key] as string[], linePosition);
    } else {
      addAttrPDF(pdf, key, state.value[key] as string, linePosition);
    }
  }

  // Adiciona uma nova página em orientação horizontal
  pdf.addPage('a4', 'landscape');

  // Define a margem superior para o conteúdo HTML
  const topMargin = 15;

  // Captura o conteúdo HTML como uma imagem
  let dk = true;
  if (isDark.value) {
    dk = false;
    toggleDark();
  }
  const chartElement = pdfContent.value.querySelector('.echarts');
  const canvas = await html2canvas(chartElement);
  const imgData = canvas.toDataURL('image/png');

  // Calcula as dimensões da imagem
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

  // Verifica se a imagem cabe na página; ajusta se necessário
  const pageHeightLandscape = pdf.internal.pageSize.getHeight();
  const finalImageHeight = pdfHeight > pageHeightLandscape - topMargin ? pageHeightLandscape - topMargin : pdfHeight;

  // Adiciona a imagem na última página
  pdf.addImage(imgData, 'PNG', 0, topMargin, pdfWidth, finalImageHeight);

  // Captura a tabela HTML e a renderiza como imagem
  const tableElement = pdfContent.value.querySelector('table');
  if (tableElement) {
    const tableCanvas = await html2canvas(tableElement);
    const tableImgData = tableCanvas.toDataURL('image/png');

    const tableImgWidth = pdfWidth - 20; // Largura da imagem ajustada à página (com margens)
    const tableImgHeight = (tableCanvas.height * tableImgWidth) / tableCanvas.width;

    let remainingHeight = tableCanvas.height; // Altura restante da tabela em pixels
    let currentY = 10; // Posição inicial para adicionar a tabela no PDF

    // Adiciona a tabela dividida em várias páginas, se necessário
    while (remainingHeight > 0) {
      // Adiciona uma nova página caso não seja a primeira fatia

      pdf.addPage('a4', 'landscape');

      // Define o canvas temporário para a fatia atual
      const canvasSlice = document.createElement('canvas');
      const context = canvasSlice.getContext('2d');

      // Altura do pedaço atual em pixels
      const sliceHeight = Math.min(
        remainingHeight,
        (pageHeightLandscape - topMargin) * (tableCanvas.width / tableImgWidth)
      );

      canvasSlice.width = tableCanvas.width;
      canvasSlice.height = sliceHeight;

      // Copia o pedaço correspondente da tabela para o canvas temporário
      context.drawImage(
        tableCanvas,
        0,
        tableCanvas.height - remainingHeight, // Ponto inicial do corte na tabela original
        tableCanvas.width,
        sliceHeight,
        0,
        0,
        canvasSlice.width,
        canvasSlice.height
      );

      // Converte o pedaço em imagem e adiciona ao PDF
      const sliceImgData = canvasSlice.toDataURL('image/png');
      const sliceHeightInPDF = (sliceHeight * tableImgWidth) / tableCanvas.width;

      pdf.addImage(sliceImgData, 'PNG', 10, currentY, tableImgWidth, sliceHeightInPDF);

      // Atualiza as variáveis para o próximo pedaço
      remainingHeight -= sliceHeight;
    }
  } else {
    pdf.text("Table not found.", 10, 20); // Mensagem de fallback se a tabela não for encontrada
  }

  // Salva o PDF
  pdf.save(`${exportFilename.value}.pdf`);
  if (!dk) {
    toggleDark();
  }
};

const config = useRuntimeConfig()

const op = ref<boolean>(false);
const nameFilter = ref<string>('');
const code = ref<string>(generateUUID());
const viewFlow = ref(false);
const viewOption = ref(false);
const graphHeight = ref(500);
const highlightedSerie = ref<number | null>(null);
const exportModal = ref(false);
const exportType = ref('');
const exportFilename = ref('');

// Main state
const state = ref<ModelType>();

function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        const r = (Math.random() * 16) | 0,
              v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}
const updateTimeRange = ([start, end]: [Date, Date]) => {
  if (state.value === null) return;
  state.value = {
    ...state.value,
    start: start.toISOString(),
    end: end.toISOString(),
    humanStart: start.toISOString(),
    humanEnd: end.toISOString(),
  };
};

function openOptions() {
  if (viewOption.value) {
    viewOption.value = false
  } else {
    viewOption.value = true
  }
}

function openExportModal(type: 'csv' | 'pdf') {
  exportType.value = type;
  exportFilename.value = `data_${new Date().toISOString().slice(0, 10)}`;
  exportModal.value = true;
}

function confirmExport() {
  exportModal.value = false;
  if (exportType.value === 'csv') {
    generateCSV();
  } else if (exportType.value === 'pdf') {
    generatePDF();
  }
}
watch(viewFlow, () => {
  viewOption.value = viewFlow.value
}, { immediate: true })
// Load data from URL
const route = await useRoute();
const router = useRouter();
const decodeState = (serialized: string | undefined): ModelType => {
  try {
    if (!serialized) {
      console.debug("no state");
      return null;
    }
    const unserialized = LZString.decompressFromBase64(serialized);
    if (!unserialized) {
      console.debug("empty state");
      return null;
    }
    return JSON.parse(unserialized);
  } catch (error) {
    console.error("cannot decode state:", error);
    return null;
  }
};

const encodeState = (state: ModelType) => {
  if (state === null) return "";
  return LZString.compressToBase64(
    JSON.stringify(state, Object.keys(state).sort()),
  );
};

watch(
  () => route.query.state,
  () => {
    const newState = decodeState(route.query.state);
    if (!isEqual(newState, state.value)) {
      state.value = newState;
    }
  },
  { immediate: true },
);

const encodedState = computed(() => encodeState(state.value));

// Fetch data
const fetchedData = ref<
  GraphLineHandlerResult | GraphSankeyHandlerResult | null
>(null);

const orderedJSONPayload = <T extends Record<string, any>>(input: T): T => {
  return Object.keys(input)
    .sort()
    .reduce(
      (o, k) => ((o[k] = input[k]), o),
      {} as { [key: string]: any },
    ) as T;
};

const jsonPayload = computed(
  (): GraphSankeyHandlerInput | GraphLineHandlerInput | null => {
    if (state.value === null) return null;
    if (state.value.graphType === "sankey") {
      const input: GraphSankeyHandlerInput = {
        ...omit(state.value, [
          "graphType",
          "bidirectional",
          "previousPeriod",
          "humanStart",
          "humanEnd",
        ]),
        code: code.value,
      };
      return orderedJSONPayload(input);
    } else {
      const input: GraphLineHandlerInput = {
        ...omit(state.value, [
          "graphType",
          "previousPeriod",
          "humanStart",
          "humanEnd",
        ]),
        points: state.value.graphType === "grid" ? 50 : 200,
        "previous-period": state.value.previousPeriod,
        total: true,
        code: code.value,

      };
      return orderedJSONPayload(input);
    }
  },
);

const dimensions = computed(
  () =>
    serverConfiguration.value?.dimensions.map((v, idx) => {
      return {
        id: idx + 1,
        name: v,
        maskedName: changeDimensionsNames(v),
        color: dataColor(
          ["Exporter", "Src", "Dst", "In", "Out", ""]
            .map((p) => v.startsWith(p))
            .indexOf(true),
        ),
      }
    }) || [],
);
const request = ref<ModelType>(null); // Same as state, but once request is successful
const { data, execute, isFetching, aborted, abort, canAbort, error } = useFetch(
  "",
  {
    beforeFetch(ctx) {
      // Add the URL. Not a computed value as if we change both payload
      // and URL, the query will be triggered twice.
      const { cancel } = ctx;
      if (state.value === null) {
        cancel();
        return ctx;
      }
      const endpoint: Record<GraphType, string> = {
        stacked: "line",
        stacked100: "line",
        lines: "line",
        grid: "line",
        sankey: "sankey",
      };
      const url = endpoint[state.value.graphType];
      return {
        ...ctx,
        url: `/api/v0/console/graph/${url}?token=${cookieToken.value}&id_client=${cookieIdClient.value}`,
      };
    },
    async afterFetch(
      ctx: AfterFetchContext<GraphLineHandlerOutput | GraphSankeyHandlerOutput>,
    ) {
      // Update data. Not done in a computed value as we want to keep the
      // previous data in case of errors.
      const { data, response } = ctx;
      if (data === null || !state.value) return ctx;
      if (state.value.graphType === "sankey") {
        fetchedData.value = {
          graphType: "sankey",
          ...(data as GraphSankeyHandlerOutput),
          ...pick(state.value, ["start", "end", "dimensions", "units"]),
        };
      } else {
        fetchedData.value = {
          graphType: state.value.graphType,
          ...(data as GraphLineHandlerOutput),
          ...pick(state.value, [
            "start",
            "end",
            "dimensions",
            "units",
            "bidirectional",
          ]),
        };
      }
      // Also update URL.
      const routeTarget = {
        name: "visualize",
        query: { state: encodedState.value },
      };
      if (route.query.state !== routeTarget.query.state) {
        await router.replace(routeTarget);
      } else {
        selectedDimensions.value = dimensions.value.filter(dm => state.value.dimensions.includes(dm.name))
        await router.push(routeTarget);
      }

      request.value = state.value;

      return ctx;
    },
    immediate: false,
  },
)
  .post(jsonPayload, "json")
  .json<
    GraphLineHandlerOutput | GraphSankeyHandlerOutput | { message: string }
  >();
async function cancel(){
  await abort()
  await $fetch(`${config.public.goServer}/query/cancel`,{
    method: "DELETE",
    mode: 'cors',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${cookieToken.value}`
    },
    query:{
      id: code.value,
      token: `${cookieToken.value}`,
      id_client: cookieIdClient.value,
    }
  })
}
watch(
  [jsonPayload],
  async () => {
    await execute();
  },
  { immediate: true },
);
const errorMessage = computed(() => {
  if (!error.value || aborted.value) return "";
  if (data.value && "message" in data.value) return data.value.message;
  return `Server returned an error: ${error.value}`;
});

function formatJSON(obj: any, from: string, to: string) {
  let object: any = {};

  Object.keys(obj).forEach((key: any) => {
    object[key.toString().replace(from, to)] = parseValue(obj[key]);
  });
  return object;
}

function parseValue(value: string | any) {
  if (value === 'true') return true;
  if (value === 'false') return false;
  return value;
}

async function SaveFilter() {
  try {
    let filter = await formatJSON(state.value, "-", "_")
    filter['filterName'] = await nameFilter.value
    filter['code'] = await encodedState.value
    const data = await $fetch(`${config.public.apiFastApi}/save_filter`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cookieToken.value}`
      },
      body: filter
    })
    if (data.error) {
      throw data;
    }
    toast.add({ severity: 'success', summary: translations_visualize['success_message'], detail: data.message, life: 3000 });
  } catch (error) {
    if (error.error) {
      toast.add({ severity: 'error', summary: translations_visualize['error_message'], detail: error.error, life: 3000 });
    } else {
      toast.add({ severity: 'error', summary: translations_visualize['error_message'], detail: error.data.detail, life: 3000 });
    }
    console.dir(error);
  }
}
</script>
