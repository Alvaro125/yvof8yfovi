<template>
    <div>
        <h1>Template</h1>
        <ul>
            <li><a href="/library/dispositivo">{{ translations['devices'] }}</a></li>
        </ul>
    </div>
</template>

<script lang="ts" setup>
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('library', language.value);
</script>