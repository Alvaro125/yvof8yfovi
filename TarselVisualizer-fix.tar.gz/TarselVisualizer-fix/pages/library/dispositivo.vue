<template>
    <div class="w-full h-min-screen">
        <PrimeButton @click="Create">+</PrimeButton>
        <div class="flex h-full w-full flex-col-reverse lg:flex-row">
            <div class="flex h-full w-full flex-col">
                <div v-for="(item, index) in structs" :key="index" class="flex flex-col">
                    <div class="flex justify-end">
                        <button class="pi pi-file-edit" @click="Edit(item,index)"></button>
                        <button class="pi pi-trash" @click="Delete(index)"></button>
                    </div>
                    <GraphPieLibrary v-if="item.graphType=='pie'" :state="item" :title="nameDimensions[item.dimensions[0]]"/>
                    <GraphBarLibrary v-else-if="item.graphType=='bar'" :state="item" :title="nameDimensions[item.dimensions[0]]"/>
                    <GraphLineLibrary v-else="item.graphType=='stacked'" :state="item"/>
                </div>
            </div>
            <OptionsGraphs :open="viewOption" @update:open="viewOption = $event" v-model="state" @update:submit="toogle=$event"  />
        </div>
    </div>
</template>
<script setup lang="ts">
import GraphPieLibrary from '@/components/widgets/LibraryPage/GraphPieLibrary.vue'
import GraphBarLibrary from '@/components/widgets/LibraryPage/GraphBarLibrary.vue'
import GraphLineLibrary from '@/components/widgets/LibraryPage/GraphLineLibrary.vue'
import OptionsGraphs from '@/components/widgets/LibraryPage/OptionsGraphs.vue'
import {nameDimensions} from '@/utils/dimensions'

const toogle = ref<boolean>(false)
const viewOption = ref<boolean>(false)
const state = ref<any>()
const status = ref<string>('create')
const idEdit = ref<number>(-1) 
const structs = ref([{
    "bidirectional": false,
    "dimensions": [
        "SrcAS",
    ],
    "end": "2025-01-17T19:38:46.137Z",
    "filter": "InIfBoundary = external AND SrcAS IN (15169,263703,262589,32934)",
    "graphType": "bar",
    "humanEnd": "now",
    "humanStart": "24 hours ago",
    "limit": 50,
    "previousPeriod": false,
    "start": "2025-01-16T19:38:46.135Z",
    "truncate-v4": 32,
    "truncate-v6": 128,
    "units": "pps"
},
{
    "bidirectional": false,
    "dimensions": [
        "SrcAS",
    ],
    "end": "2025-01-17T19:38:46.137Z",
    "filter": "InIfBoundary = external AND SrcAS IN (15169,263703,262589,32934)",
    "graphType": "pie",
    "humanEnd": "now",
    "humanStart": "24 hours ago",
    "limit": 50,
    "previousPeriod": false,
    "start": "2025-01-16T19:38:46.135Z",
    "truncate-v4": 32,
    "truncate-v6": 128,
    "units": "pps"
}
])

function Edit(_data: any, key: number) {
    status.value = 'edit'
    state.value = _data;
    viewOption.value = true;
    idEdit.value = key;
}
function Delete(key: number) {
    structs.value.splice(key, 1);
}
function Create() {
    status.value = 'create'
    state.value = null
    viewOption.value = true
}
watch([state], (value) => {
    if (toogle.value) {
        if (status.value == 'create') {
            structs.value.push(state.value);
        } else if (status.value == 'edit' && idEdit.value >= 0) {
            structs.value[idEdit.value] = state.value
        }
        toogle.value=false
    }
})
</script>