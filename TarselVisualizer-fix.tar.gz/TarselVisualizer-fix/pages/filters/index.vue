<template>
  <div class="w-full">
    <div v-if="error">{{ translations['error'] }}</div>
    <div v-else-if="loading">{{ translations['wait_loading'] }}</div>
    <div v-else>
      <PrimeConfirmDialog></PrimeConfirmDialog>

      <PrimeDataTable :value="filters" paginator :rows="5" :rowsPerPageOptions="[5, 10, 20, 50]"
        tableStyle="min-width: 50rem"
        paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
        :currentPageReportTemplate="`{first} ${translations['to']} {last} ${translations['of']} {totalRecords}`">
        <template #header>
          <div class="flex justify-end">
            <PrimeIconField>
              <PrimeInputIcon>
                <i class="pi pi-search" />
              </PrimeInputIcon>
              <PrimeInputText v-model="search" :placeholder="translations['keyword_search']" />
            </PrimeIconField>
          </div>
        </template>
        <template #empty> {{ translations['no_customer'] }} </template>
        <template #loading> {{ translations['wait_loading'] }} </template>

        <PrimeColumn field="name" :header="translations['name']" sortable>
          <template #body="slotProps">
            <a class="hover:underline"
            :href="`/filters/${slotProps.data.name.replace('/','%2F')}`">{{slotProps.data.name}}</a>
          </template>
        </PrimeColumn>
        <PrimeColumn field="filter" :header="translations['filter']" sortable></PrimeColumn>
        <PrimeColumn field="name" :header="translations['delete']">
          <template #body="slotProps">
            <PrimeButton @click="confirmDelete(slotProps.data.name)" severity="danger">{{ translations['delete'] }}</PrimeButton>
          </template>
        </PrimeColumn>
        <PrimeColumn field="name" :header="translations['update']">
          <template #body="slotProps">
            <PrimeButton @click="openUpdateDialog(slotProps.data.name)" severity="info">{{ translations['update'] }}</PrimeButton>
          </template>
        </PrimeColumn>
      </PrimeDataTable>
    </div>
    <PrimeToast></PrimeToast>
    <PrimeDialog v-model:visible="updateDialogVisible" :header="translations['update_filter_name']">
      <div>
        <label>{{ translations['new_filter_name'] }}</label>
        <PrimeInputText v-model="newFilterName" />
      </div>
      <div class="flex justify-end mt-4">
        <PrimeButton @click="updateFilterName" severity="info">{{ translations['update'] }}</PrimeButton>
      </div>
    </PrimeDialog>
  </div>
</template>

<script lang="ts" setup>
import { type ModelType } from '@/components/widgets/VisualizePage/OptionsPanel.vue';
import { FilterMatchMode } from '@primevue/core/api';
import LZString from "lz-string";
import { useConfirm } from "primevue/useconfirm";
import { useToast } from "primevue/usetoast";
import getTranslations from '@/utils/translations';
import { ref, computed, onMounted } from 'vue';

const language = useCookie('language');
const translations: any = await getTranslations('filters', language.value);

const search = ref<string>();
const config = useRuntimeConfig()
const token = useCookie('token')

const data = ref<any>(null);
const loading = ref(true);
const error = ref(false);

const confirm = useConfirm();
const toast = useToast();

async function fetchFilters() {
  try {
    loading.value = true;
    error.value = false;
    data.value = await $fetch(`${config.public.apiFastApi}/get_filter`, {
      headers: {
        Authorization: `Bearer ${token.value}`
      }
    });
  } catch (err) {
    error.value = true;
    console.error(err);
  } finally {
    loading.value = false;
  }
}

onMounted(() => {
  fetchFilters();
});

const filters = computed(() => {
  if (!data.value) return [];
  
  const keys = Object.keys(data.value);
  const value = Object.values(data.value);
  
  return value.map((item: any, index: number) => {
    return {
      ...item,
      name: keys[index]
    };
  });
});

const encodeState = (state: ModelType) => {
  if (state === null) return "";
  return LZString.compressToBase64(
    JSON.stringify(state, Object.keys(state).sort()),
  );
};

async function toVisualize(index: string) {
  const state = await encodeState(data?.value[index]);
  await navigateTo({
    path: '/filters/' + index
  })
}

async function DeleteFilter(filterName: string) {
  try {
    const response: any = await $fetch(`${config.public.apiFastApi}/delete_filter`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token.value}`
      },
      body: { filterName }
    })
    toast.add({ severity: 'success', summary: translations['success_message'], detail: response.message, life: 3000 });
    await fetchFilters();
  } catch (error: any) {
    console.dir(error);
    toast.add({ severity: 'error', summary: 'Error', detail: 'Failed to delete filter', life: 3000 });
  }
}

const confirmDelete = (key: string) => {
  confirm.require({
    message: `Do you want to delete this filter "${key}"?`,
    header: 'Delete Filter',
    icon: 'pi pi-info-circle',
    rejectLabel: 'Cancel',
    rejectProps: {
      label: 'Cancel',
      severity: 'secondary',
      outlined: true
    },
    acceptProps: {
      label: 'Delete',
      severity: 'danger'
    },
    accept: () => {
      DeleteFilter(key)
    },
    reject: () => {
      toast.add({ severity: 'error', summary: 'Rejected', detail: 'You have rejected', life: 3000 });
    }
  });
};

const updateDialogVisible = ref(false);
const newFilterName = ref('');
const currentFilterName = ref('');

function openUpdateDialog(filterName: string) {
  currentFilterName.value = filterName;
  newFilterName.value = '';
  updateDialogVisible.value = true;
}

async function updateFilterName() {
  try {
    await $fetch(`${config.public.apiFastApi}/update_filter_name`, {
      method: 'PUT',
      body: JSON.stringify({
        old_name: currentFilterName.value,
        new_name: newFilterName.value
      }),
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token.value}`
      }
    });
    toast.add({ severity: 'success', summary: translations['success_message'], detail: 'Filter name updated successfully', life: 3000 });
    updateDialogVisible.value = false;
    await fetchFilters();
  } catch (error: any) {
    toast.add({ severity: 'error', summary: 'Error', detail: 'Failed to update filter name', life: 3000 });
  }
}
</script>

<style></style>