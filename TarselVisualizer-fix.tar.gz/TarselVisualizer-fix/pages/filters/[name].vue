<template>
  <div class="w-full">
    <div class="flex w-full flex-col">
      <div class="flex justify-end gap-4">
        <button @click="openExportModal('csv')"
          class="bg-slate-400 hover:bg-slate-200 transition-all text-gray-950 py-1 px-2 rounded-md border-slate-800 border-[1px] dark:bg-neutral-800 dark:text-neutral-50 dark:border-neutral-50">
          {{ 'Export CSV' }}<span class="pi pi-table pl-2"></span>
        </button>
        <button @click="openExportModal('pdf')"
          class="bg-slate-400 hover:bg-slate-200 transition-all text-gray-950 py-1 px-2 rounded-md border-slate-800 border-[1px] dark:bg-neutral-800 dark:text-neutral-50 dark:border-neutral-50">
          {{ translations['export_pdf'] }}<span class="pi pi-upload pl-2"></span>
        </button>
        <button @click="opSave = true" class="py-1 px-2 mt-4 rounded-md border-[1px]">
          {{ translations['save_new_filter'] }}<span class="pi pi-save pl-2"></span>
        </button>
        <button @click="() => {
          opUpdate = true
          resetName()
        }" class="py-1 px-2 mt-4 rounded-md border-[1px]">
          {{ translations['update_filter'] }}<span class="pi pi-save pl-2"></span>
        </button>
        <button @click="openOptions" class="py-1 px-2 mt-4 mr-4 rounded-md"
          :class="!viewOption ? 'bg-slate-400 text-gray-950 dark:text-neutral-800 dark:bg-neutral-100 dark:border-neutral-50 border-[1px]' : 'bg-slate-900 text-gray-200 dark:text-neutral-900 dark:bg-neutral-400'">
          {{ translations['query'] }}<span class="pi pi-search pl-2"></span>
        </button>
      </div>
      <PrimeDialog v-model:visible="opSave" modal :header="translations['save_new_filter']" :style="{ width: '25rem' }">
        <span class="text-surface-500 dark:text-surface-400 block mb-8">{{ translations['update_info'] }}</span>
        <div class="flex items-center gap-4 mb-4">
          <label for="username" class="font-semibold w-22">{{ translations['filter_name'] }}</label>
          <PrimeInputText id="username" class="flex-auto" autocomplete="off" v-model="newNameFilter" />
        </div>
        <div class="flex justify-end gap-2">
          <PrimeButton type="button" :label="translations['cancel']" severity="secondary" @click="opSave = false">
          </PrimeButton>
          <PrimeButton type="button" :label="translations['save']" @click="() => {
            opSave = false;
            SaveFilter()
          }"></PrimeButton>
        </div>
      </PrimeDialog>
      <PrimeDialog v-model:visible="opUpdate" modal :header="translations['update_filter']" :style="{ width: '25rem' }">
        <span class="text-surface-500 dark:text-surface-400 block mb-8">{{ translations['update_info'] }}</span>
        <div class="flex items-center gap-4 mb-4">
          <label for="username" class="font-semibold w-22">{{ translations['filter_name'] }}</label>
          <PrimeInputText id="username" class="flex-auto" autocomplete="off" v-model="actualNameFilter">
            {{ urlName.value }}
          </PrimeInputText>
        </div>
        <div class="flex justify-end gap-2">
          <PrimeButton type="button" :label="translations['cancel']" severity="secondary" @click="opUpdate = false">
          </PrimeButton>
          <PrimeButton type="button" :label="translations['save']" @click="() => {
            opUpdate = false;
            UpdateFilter()
          }"></PrimeButton>
        </div>
      </PrimeDialog>

      <!-- Modal para nomear arquivos de exportação -->
      <PrimeDialog v-model:visible="exportModal" modal :header="exportType === 'csv' ? 'Export CSV' : 'Export PDF'"
        :style="{ width: '25rem' }">
        <span class="text-surface-500 dark:text-surface-400 block mb-8">
          {{ translations['enter_filename'] || 'Enter filename for export ' }}</span>
        <div class="flex items-center gap-4 mb-4">
          <label for="filename" class="font-semibold w-22">{{ translations['filename'] || 'Filename' }}</label>
          <PrimeInputText id="filename" class="flex-auto" autocomplete="off" v-model="exportFilename" />
        </div>
        <div class="flex justify-end gap-2">
          <PrimeButton type="button" :label="translations['cancel']" severity="secondary" @click="exportModal = false">
          </PrimeButton>
          <PrimeButton type="button" :label="translations['export'] || 'Export'" @click="confirmExport">
          </PrimeButton>
        </div>
      </PrimeDialog>

      <div class="flex h-full w-full flex-col lg:flex-row-reverse">
        <OptionsPanel v-if="state" v-model="state" :loading="false" class="print:hidden"
          :view="(state) => viewFlow = state" :open="viewOption" />
        <div ref="pdfContent" class="grow overflow-y-auto bg-white dark:bg-zinc-800">
          <WidgetGraphLine :state="state" @update:fetchedData="fetchedData = $event" />
        </div>
      </div>
      <div class="flex" v-if="state.graphType != 'sankey'">
        <WidgetGraphPie class="w-[33%] h-fit" :state="decodeState(data[route.params.name]?.code)"
          :dimensions="['SrcCountry']" :title="nameDimensions['SrcCountry']" />
        <WidgetGraphPie class="w-[33%] h-fit" :state="decodeState(data[route.params.name]?.code)"
          :dimensions="['Proto']" :title="nameDimensions['Proto']" />
        <WidgetGraphPie class="w-[33%] h-fit" :state="decodeState(data[route.params.name]?.code)"
          :dimensions="['InIfDescription']" :title="nameDimensions['InIfDescription']" />
      </div>
      <div class="flex" v-if="state.graphType != 'sankey'">
        <WidgetGraphPie v-for="(item, index) in data[route.params.name]?.dimensions" :key="index" class="w-[33%] h-fit"
          :state="decodeState(data[route.params.name]?.code)" :dimensions="[item]" title="other" />
      </div>
    </div>
    <PrimeToast></PrimeToast>
  </div>
</template>

<script lang="ts" setup>
import WidgetGraphPie from '@/components/widgets/FilterPage/WidgetGraphPie.vue';
import WidgetGraphLine from '@/components/widgets/FilterPage/WidgetGraphLine.vue';
import { type ModelType } from '@/components/widgets/VisualizePage/OptionsPanel.vue';
import { Date as SugarDate } from "sugar-date";
import { isEqual, omit, pick } from 'lodash-es';
import { nameDimensions } from "@/utils/dimensions";
import LZString from "lz-string";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import getTranslations from '@/utils/translations';
import { useToast } from 'primevue/usetoast';
import { formatXps } from '@/utils';
import { changeDimensionsNames } from '@/utils/dimensions';
import { ThemeKey } from "~/components/ThemeProvider.vue";

const language = useCookie('language');
const translations: any = await getTranslations('visualize', language.value);
const translations_visualize: any = await getTranslations('visualize', language.value);
const config = useRuntimeConfig()
const nuxtApp = useNuxtApp();
const { isDark, toggleDark } = inject(await ThemeKey)!;
const viewFlow = ref();
const viewOption = ref(false);
const loading = ref(false);
const state = ref<ModelType | null>(null);
const opSave = ref<boolean>(false);
const opUpdate = ref<boolean>(false);
const newNameFilter = ref<string>('');
const actualNameFilter = ref<string>('');
const toast = useToast();
const cookieToken = useCookie('token');
const code = ref();
const urlName = ref();
const fetchedData = ref(null);
const pdfContent = ref(null);
const exportModal = ref(false);
const exportType = ref('');
const exportFilename = ref('');

nuxtApp.hook("page:start", () => {
  loading.value = true;
});
nuxtApp.hook("page:finish", () => {
  loading.value = false;
});

function openOptions() {
  viewOption.value = !viewOption.value
}

function openExportModal(type: 'csv' | 'pdf') {
  exportType.value = type;
  exportFilename.value = `data_${new Date().toISOString().slice(0, 10)}`;
  exportModal.value = true;
}

function confirmExport() {
  exportModal.value = false;
  if (exportType.value === 'csv') {
    generateCSV();
  } else if (exportType.value === 'pdf') {
    generatePDF();
  }
}

const route = await useRoute();
urlName.value = route.fullPath.split('/')[route.fullPath.split('/').length - 1]

const resetName = () => {
  actualNameFilter.value = urlName.value;
  actualNameFilter.value = actualNameFilter.value.replace(/%20/g, ' ');
}
resetName();

const decodeState = (serialized: string | undefined): ModelType | null => {
  try {
    if (!serialized) {
      console.debug("no state");
      return null;
    }
    const unserialized = LZString.decompressFromBase64(serialized);
    if (!unserialized) {
      console.debug("empty state");
      return null;
    }
    return JSON.parse(unserialized);
  } catch (error) {
    console.error("cannot decode state:", error);
    return null;
  }
};

const { data, execute, error } = await useFetch(`${config.public.apiFastApi}/get_filter`, {
  headers:
    { Authorization: `Bearer ${useCookie('token').value}` }
});
watch(data, async () => {
  const url = data.value[route.params.name]?.code;
  let newState = decodeState(url);
  code.value = decodeState(url);

  if (!isEqual(newState, state.value)) {
    newState.start = SugarDate.create(newState?.humanStart).toISOString();
    newState.end = SugarDate.create(newState?.humanEnd).toISOString();
    state.value = newState;
  }
}, { immediate: true });


function formatJSON(obj: any, from: string, to: string) {
  let object: any = {};

  Object.keys(obj).forEach((key: any) => {
    object[key.toString().replace(from, to)] = parseValue(obj[key]);
  });
  return object;
}

function parseValue(value: string | any) {
  if (value === 'true') return true;
  if (value === 'false') return false;
  return value;
}

const encodeState = (state: ModelType) => {
  if (state === null) return "";
  return LZString.compressToBase64(
    JSON.stringify(state, Object.keys(state).sort()),
  );
};
const encodedState = computed(() => encodeState(state.value));

// pt: Função para gerar os detalhes do gráfico do pdf
// es: Función para generar detalles de gráficos en formato PDF
const addAttrPDF = (_pdf: jsPDF, name: string, content: string | string[], linePosition: { value: number }) => {
  const negate = ['truncate-v4', 'truncate-v6', 'units', 'bidirectional', 'previousPeriod'];
  if (negate.includes(name)) { return };

  const lineHeight = 10; // Altura de cada linha
  const pageHeight = _pdf.internal.pageSize.getHeight(); // Altura total da página
  const marginBottom = 10; // Margem inferior para evitar corte
  const pageWidth = _pdf.internal.pageSize.getWidth(); // Largura da página
  const marginLeft = 21; // Margem esquerda

  // Verifica se há espaço suficiente na página para o título
  if (linePosition.value + lineHeight > pageHeight - marginBottom) {
    _pdf.addPage();
    linePosition.value = 20; // Reinicia a posição na nova página
  }

  // Adiciona o título (campo `name`) em negrito
  _pdf.setFont("Helvetica", "bold");
  _pdf.setFontSize(13);
  _pdf.text(21, linePosition.value, `${translations[name]}:`);
  linePosition.value += lineHeight; // Move para a próxima linha

  // Ajusta o conteúdo (valores do campo)
  _pdf.setFont("Helvetica", "normal");

  if (Array.isArray(content)) {
    content.forEach((item) => {
      if (linePosition.value + lineHeight > pageHeight - marginBottom) {
        _pdf.addPage();
        linePosition.value = 20; // Reinicia a posição na nova página
      }

      // Adiciona cada valor com indentação
      if (name === 'dimensions') {
        _pdf.text(marginLeft + 4, linePosition.value, `- ${changeDimensionsNames(item)}`);
      } else {
        _pdf.text(marginLeft + 4, linePosition.value, `- ${item}`);
      }
      linePosition.value += lineHeight; // Move para a próxima linha
    });
  } else {
    // Quebra o texto longo em várias linhas
    const textLines = _pdf.splitTextToSize(content as string, pageWidth - 2 * marginLeft);

    textLines.forEach((line) => {
      if (linePosition.value + lineHeight > pageHeight - marginBottom) {
        _pdf.addPage();
        linePosition.value = 20; // Reinicia a posição na nova página
      }

      // Adiciona cada linha do texto quebrado
      _pdf.text(marginLeft + 4, linePosition.value, line);
      linePosition.value += lineHeight; // Move para a próxima linha
    });
  }
};

async function SaveFilter() {
  try {
    let filter = await formatJSON(state.value, "-", "_")
    filter['filterName'] = await newNameFilter.value
    filter['code'] = await encodedState.value
    const data = await $fetch(`${config.public.apiFastApi}/save_filter`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cookieToken.value}`
      },
      body: filter
    })
    if (data.error) {
      throw data;
    }
    toast.add({ severity: 'success', summary: translations['success_message'], detail: data.message, life: 3000 });
  } catch (error) {
    if (error.error) {
      toast.add({ severity: 'error', summary: translations['error_message'], detail: error.error, life: 3000 });
    } else {
      toast.add({ severity: 'error', summary: translations['error_message'], detail: error.data.detail, life: 3000 });
    }
    console.dir(error);
  }
}

async function UpdateFilter() {
  try {
    let filter = await formatJSON(state.value, "-", "_")
    filter['filterName'] = actualNameFilter.value
    filter['code'] = encodedState.value
    const data = await $fetch(`${config.public.apiFastApi}/update_filter`, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cookieToken.value}`
      },
      body: {
        "filter": filter,
        "filterName": urlName.value
      }
    })
    if (data.error) {
      throw data;
    }
    console.log(data)
    window.history.pushState({}, '', `/filters/${actualNameFilter.value}`);
    toast.add({ severity: 'success', summary: translations['success_message'], detail: data.message, life: 3000 });
  } catch (error) {
    if (error.error) {
      toast.add({ severity: 'error', summary: translations['error_message'], detail: error.error, life: 3000 });
    } else {
      toast.add({ severity: 'error', summary: translations['error_message'], detail: error.data.detail, life: 3000 });
    }
    console.dir(error);
  }
}

const generateCSV = () => {
  if (!fetchedData.value) return;

  const data = fetchedData.value;
  const unit = ["inl2%", "outl2%"].includes(data.units || "bps")
    ? "%"
    : (data.units || "bps").slice(-3);

  const formatValue = (v: number): string =>
    unit === "%" ? `${v.toFixed(0)}%` : `${formatXps(v)}${unit}`;

  let csvContent = '';

  if (data.graphType === 'sankey') {
    // Para gráfico Sankey
    const headers = [...data.dimensions, 'Average'];
    csvContent = headers.join(',') + '\n';

    // Adiciona as linhas de dados
    data.rows.forEach((row, idx) => {
      const line = [...row, formatValue(data.xps[idx])];
      csvContent += line.map(v => `"${v}"`).join(',') + '\n';
    });

    // Adiciona linha de Total
    const totalValues = [
      ...Array(data.dimensions.length).fill('Total'),
      formatValue(data.xps.reduce((ac, v) => ac + v, 0))
    ];
    csvContent += totalValues.map(v => `"${v}"`).join(',') + '\n';

  } else {
    // Para outros tipos de gráfico (line, stacked, etc)
    const headers = [...data.dimensions, 'Min', 'Max', 'Average', '~95th'];
    csvContent = headers.join(',') + '\n';

    // Adiciona as linhas de dados
    data.rows.forEach((row, idx) => {
      const stats = [
        formatValue(data.min[idx]),
        formatValue(data.max[idx]),
        formatValue(data.average[idx]),
        formatValue(data['95th'][idx])
      ];

      const line = [...row, ...stats];
      csvContent += line.map(v => `"${v}"`).join(',') + '\n';
    });

    // Adiciona linha de Total
    const totalLine = data.points[data.points.length - 1];
    const totalValues = [
      ...Array(data.dimensions.length).fill('...'),
      formatValue(Math.min(...totalLine.slice(0, -1))),
      formatValue(Math.max(...totalLine)),
      formatValue(data.average[data.average.length - 1]),
      formatValue(data['95th'][data['95th'].length - 1])
    ];
    csvContent += totalValues.map(v => `"${v}"`).join(',') + '\n';
  }

  // Criar e baixar o arquivo
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', `${exportFilename.value}.csv`);
  link.style.visibility = 'hidden';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  toast.add({
    severity: 'success',
    summary: translations_visualize['success_message'],
    detail: 'CSV exported successfully',
    life: 3000
  });
};
// pt: Função para gerar pdf do gráfico da página visualize
// es: Función para generar PDF a partir del gráfico de página visualize
const generatePDF = async () => {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const linePosition = { value: 35 }; // Controla a posição vertical

  pdf.setFontSize(16);
  pdf.text("Details:", 85, 20);

  pdf.setFontSize(13);

  // Itera sobre os campos do objeto `state.value` e adiciona ao PDF
  for (const key in state.value) {
    // Verifica se a propriedade é uma lista ou um valor único
    if (Array.isArray(state.value[key])) {
      addAttrPDF(pdf, key, state.value[key] as string[], linePosition);
    } else {
      addAttrPDF(pdf, key, state.value[key] as string, linePosition);
    }
  }

  // Adiciona uma nova página em orientação horizontal
  pdf.addPage('a4', 'landscape');

  // Define a margem superior para o conteúdo HTML
  const topMargin = 15;

  // Captura o conteúdo HTML como uma imagem
  let dk = true;
  if (isDark.value) {
    dk = false;
    toggleDark();
  }
  const chartElement = pdfContent.value.querySelector('.echarts');
  const canvas = await html2canvas(chartElement);
  const imgData = canvas.toDataURL('image/png');

  // Calcula as dimensões da imagem
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

  // Verifica se a imagem cabe na página; ajusta se necessário
  const pageHeightLandscape = pdf.internal.pageSize.getHeight();
  const finalImageHeight = pdfHeight > pageHeightLandscape - topMargin ? pageHeightLandscape - topMargin : pdfHeight;

  // Adiciona a imagem na última página
  pdf.addImage(imgData, 'PNG', 0, topMargin, pdfWidth, finalImageHeight);

  // Captura a tabela HTML e a renderiza como imagem
  const tableElement = pdfContent.value.querySelector('table');
  if (tableElement) {
    const tableCanvas = await html2canvas(tableElement);
    const tableImgData = tableCanvas.toDataURL('image/png');

    const tableImgWidth = pdfWidth - 20; // Largura da imagem ajustada à página (com margens)
    const tableImgHeight = (tableCanvas.height * tableImgWidth) / tableCanvas.width;

    let remainingHeight = tableCanvas.height; // Altura restante da tabela em pixels
    let currentY = 10; // Posição inicial para adicionar a tabela no PDF

    // Adiciona a tabela dividida em várias páginas, se necessário
    while (remainingHeight > 0) {
      // Adiciona uma nova página caso não seja a primeira fatia

      pdf.addPage('a4', 'landscape');

      // Define o canvas temporário para a fatia atual
      const canvasSlice = document.createElement('canvas');
      const context = canvasSlice.getContext('2d');

      // Altura do pedaço atual em pixels
      const sliceHeight = Math.min(
        remainingHeight,
        (pageHeightLandscape - topMargin) * (tableCanvas.width / tableImgWidth)
      );

      canvasSlice.width = tableCanvas.width;
      canvasSlice.height = sliceHeight;

      // Copia o pedaço correspondente da tabela para o canvas temporário
      context.drawImage(
        tableCanvas,
        0,
        tableCanvas.height - remainingHeight, // Ponto inicial do corte na tabela original
        tableCanvas.width,
        sliceHeight,
        0,
        0,
        canvasSlice.width,
        canvasSlice.height
      );

      // Converte o pedaço em imagem e adiciona ao PDF
      const sliceImgData = canvasSlice.toDataURL('image/png');
      const sliceHeightInPDF = (sliceHeight * tableImgWidth) / tableCanvas.width;

      pdf.addImage(sliceImgData, 'PNG', 10, currentY, tableImgWidth, sliceHeightInPDF);

      // Atualiza as variáveis para o próximo pedaço
      remainingHeight -= sliceHeight;
    }
  } else {
    pdf.text("Table not found.", 10, 20); // Mensagem de fallback se a tabela não for encontrada
  }

  // Salva o PDF
  pdf.save(`${exportFilename.value}.pdf`);
  if (!dk) {
    toggleDark();
  }
};
</script>

<style></style>