<template>
    <div class="w-full">
        <div class="w-full mt-6 pr-20 flex justify-end">
            <div class="flex flex-row hover:cursor-pointer" @click="toggleModalNewPlan">
                <PlusIcon class="w-5 h-5 mr-1 text-blue-700 dark:text-blue-800" />
                <p class="text-sm">{{ translations['new_plan'] }}</p>
            </div>
        </div>
        <CreateEditPlan :newPlan="openModalNewPlan" :editPlan="openModalEditPlan" :planID="planID" @refresh="(value) => refresh = value" @update:openModalNewPlan="toggleModalNewPlan" @update:openModalEditPlan="openModalEditPlan = false"></CreateEditPlan>
        <Card :refresh="refresh" @update:refresh="(value) => refresh = value" @editModal="handleEditModal"></Card>
        <PrimeToast></PrimeToast>
    </div>   
</template>

<script lang="ts" setup>
import { PlusIcon } from '@heroicons/vue/solid';
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('capacity_planning_page', language.value);

const refresh = ref(false);
const openModalNewPlan= ref(false);
const openModalEditPlan= ref(false);
const planID = ref();

const toggleModalNewPlan =  () => openModalNewPlan.value = !openModalNewPlan.value;
const handleEditModal = (data) => {
    openModalEditPlan.value = data.control;
    planID.value = data.planId;
}
</script>
