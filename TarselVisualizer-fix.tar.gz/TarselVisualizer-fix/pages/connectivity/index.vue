<template>
   <div class="w-full">
    <h1 class="mx-10 p-4 text-lg">{{ translations['router_connectivity'] }}</h1>
     <ModalConnectConfig />
   </div>
</template>

<script lang="ts" setup>
import getTranslations from '@/utils/translations';

const language = useCookie('language');
const translations: any = await getTranslations('connectivity', language.value);
</script>
