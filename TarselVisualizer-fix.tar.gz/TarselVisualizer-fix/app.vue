<template>
  <Providers>
    <NuxtLayout />
  </Providers>
</template>

<script setup lang="ts">
import Providers from "@/provider/Providers.vue";
</script>

<style scoped>
@import '@/assets/css/tailwind.css';
</style>
