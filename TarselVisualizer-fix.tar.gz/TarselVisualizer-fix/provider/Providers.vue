<template>
    <ServerConfigProvider>
        <ThemeProvider>
            <TitleProvider>
                <UserProvider>
                    <div class="h-full bg-white text-gray-900 dark:bg-neutral-800 dark:text-gray-100">
                        <slot />
                    </div>
                </UserProvider>
            </TitleProvider>
        </ThemeProvider>
    </ServerConfigProvider>
</template>

<script setup lang="ts">
import ServerConfigProvider from "../components/ServerConfigProvider.vue";
import ThemeProvider from "../components/ThemeProvider.vue";
import TitleProvider from "../components/TitleProvider.vue";
import UserProvider from "../components/UserProvider.vue";
</script>