import { createRouter, createWebHistory } from "vue-router";import type { RouterConfig } from '@nuxt/schema'

export default <RouterConfig>{
  routes: (_routes) => [
    {
      path: "/visualize",
      name: "Visualize",
      component: () => import('~/pages/visualize/index.vue').then(r => r.default || r),
      meta: { title: "Visualize" },
    },
    {
      path: "/visualize/:state",
      name: "VisualizeWithState",
      component: () => import('~/pages/visualize/index.vue').then(r => r.default || r),
      meta: { title: "Visualize" },
      props: (route) => ({ routeState: route.params.state }),
    },
    {
      path: "/",
      name: "Home",
      component: () => import('~/pages/index.vue').then(r => r.default || r),
      meta: { title: "Home" },
    },
  ],
}
