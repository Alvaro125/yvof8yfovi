export default defineNuxtRouteMiddleware((to, from) => {
  const config = useRuntimeConfig();
  if (to.path == "/") {
    return navigateTo(`${config.public.apiHome}`, { external: true });
  }
});
