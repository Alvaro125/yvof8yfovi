import { color } from "echarts";

export default defineNuxtRouteMiddleware(async (to, from) => {
  const config = useRuntimeConfig();
  const token = useCookie<string>("token");
  const id_client = useCookie<string>("id_client");

  // const { data, error } = await useFetch(
  //   `${config.public.apiFastApi}/get_user`,
  //   {
  //     method: "GET",
  //     headers: {
  //       Authorization: `Bearer ${token.value}`,
  //     },
  //   }
  // );
  // if (error.value) {
  //   console.log(error)
  //   return navigateTo(`${config.public.apiHome}/login_page`, {
  //     external: true,
  //   });
  // }else{
  //   return null
  // }
  return null
});
