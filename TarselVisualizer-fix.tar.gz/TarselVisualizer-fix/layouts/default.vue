<template>
  <div class="h-full bg-white text-gray-900 dark:bg-neutral-800 dark:text-gray-100">
    <NavigationBar class="flex-none print:hidden absolute z-50 top-4 left-4" />
    <main class="relative flex grow overflow-y-auto">
      <NuxtPage />
    </main>
  </div>
</template>

<script setup lang="ts">
import 'primeicons/primeicons.css'
import NavigationBar from "@/components/NavigationBar.vue";
</script>

<style scoped>
@import '@/assets/css/tailwind.css';
@import 'primeicons/primeicons.css'
</style>