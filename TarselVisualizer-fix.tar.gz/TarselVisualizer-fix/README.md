[![Static Badge](https://img.shields.io/badge/lang-es-green)](#proyecto-de-análisis-gráfico)
# Projeto de Análise Gráfica

Este projeto busca criar uma interface analítica de fluxos de flows e dispositivos, através de graficos, tabelas e números.

## Configuração

Para instalar as dependências:

```bash
# npm
npm install

# pnpm
pnpm install

# yarn
yarn install

# bun
bun install
```

Para configurar as dependencias dentro do projeto acesse o arquivo `nuxt.config.ts`

## Servidor de Desenvolvimento

Iniciar o servidor em `http://localhost:3000`:

```bash
# npm
npm run dev

# pnpm
pnpm run dev

# yarn
yarn dev

# bun
bun run dev
```

## Produção

Para build da aplicação para produção:

```bash
# npm
npm run build

# pnpm
pnpm run build

# yarn
yarn build

# bun
bun run build
```

Pré-visualizar a build de produção localmente:

```bash
# npm
npm run preview

# pnpm
pnpm run preview

# yarn
yarn preview

# bun
bun run preview
```

## Informações

A pagina de **Filters** necessita da aplicação back-end rodando para ter acesso a suas API's

---
[![Static Badge](https://img.shields.io/badge/lang-pt-green)](#projeto-de-análise-gráfica)

# Proyecto de Análisis Gráfico

Este proyecto busca crear una interfaz analítica de flujos y dispositivos, a través de gráficos, tablas y números.

## Configuración

Para instalar las dependencias:

```bash
# npm
npm install

# pnpm
pnpm install

# yarn
yarn install

# bun
bun install
```

Para configurar las dependencias dentro del proyecto, acceda al archivo `nuxt.config.ts`.

## Servidor de Desarrollo

Iniciar el servidor en `http://localhost:3000`:

```bash
# npm
npm run dev

# pnpm
pnpm run dev

# yarn
yarn dev

# bun
bun run dev
```

## Producción

Para compilar la aplicación para producción:

```bash
# npm
npm run build

# pnpm
pnpm run build

# yarn
yarn build

# bun
bun run build
```

Previsualizar la compilación de producción localmente:

```bash
# npm
npm run preview

# pnpm
pnpm run preview

# yarn
yarn preview

# bun
bun run preview
```

## Información

La página de **Filters** necesita que la aplicación backend esté ejecutándose para acceder a sus APIs.
