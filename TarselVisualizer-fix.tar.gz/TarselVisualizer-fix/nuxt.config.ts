import Aura from "@primevue/themes/aura";
import { lezer } from "@lezer/generator/rollup";
import { fileURLToPath, URL } from "node:url";
import vue from "rollup-plugin-vue";
import commonjs from "@rollup/plugin-commonjs";
import resolve from "@rollup/plugin-node-resolve";
// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devServer: {
    host: '::', // Ou o IP desejado
    port: 3000,      // Ou a porta desejada
  },
  devtools: { enabled: true },
  build: {
    transpile: (() => {
      const isDev = process.env.NODE_ENV;
      return isDev != "production"
        ? [
            "echarts",
            "zrender",
            "tslib",
            "vue-resizer",
            "resize-detector",
            "vue3-excel-editor",
            "jspdf-autotable"
          ]
        : [
            "echarts",
            "zrender",
            "tslib",
            "vue-resizer",
            "resize-detector",
            "vue3-excel-editor",
            "sugar-date",
            "jspdf-autotable"
          ];
    })(),
  },
  router: {
    options: {
      scrollBehaviorType: "auto",
    },
  },
  routeRules: {
    '/filters': { ssr: false },
    '/filters/**': { ssr: false },
  },
  rollupConfig: {
    plugins: [resolve(), commonjs(), vue()],
  },
  plugins: ['~/plugins/vuedraggable.ts'],
  assetsInclude: ["**/*.grammar"],
  components: [
    {
      path: "~/components",
      pathPrefix: false,
    },
  ],
  primevue: {
    options: {
      theme: {
        preset: Aura,
        options: {darkModeSelector: ".dark"}
      },
    },
    components: {
      prefix: "Prime",
      include: "*",
    },
  },
  modules: [
    "@nuxtjs/tailwindcss",
    "@vueuse/nuxt",
    "@pinia/nuxt",
    "nuxt-headlessui",
    "nuxt-lazy-hydrate",
    "@primevue/nuxt-module",
    "@dargmuesli/nuxt-cookie-control",
  ],
  css: ["~/assets/css/tailwind.css"],
  postcss: {
    plugins: {
      "tailwindcss/nesting": {},
      tailwindcss: {},
      autoprefixer: {},
    },
  },
  alias: {
    pinia: "/node_modules/@pinia/nuxt/node_modules/pinia/dist/pinia.mjs",
  },
  compatibilityDate: "2024-07-25",
  runtimeConfig: {
    apiSecret: process.env.API_SERVER || "http://164.163.236.62:8082",
    wsServer: process.env.WS_SERVER || "ws://localhost:1323",
    goServer: process.env.API_SERVER_GO || "http://localhost:1323",
    goIServer: process.env.API_ISERVER_GO || "http://localhost:1323",
    apiFastApi: process.env.API_SERVER_FASTAPI || "http://localhost:5002",
    apiHome: process.env.API_HOME,
    public: {
      apiFastApi: process.env.API_SERVER_FASTAPI || "http://localhost:5002",
      wsServer: process.env.WS_SERVER || "ws://localhost:1323",
      goServer: process.env.API_SERVER_GO || "http://localhost:1323",
      goIServer: process.env.API_ISERVER_GO || "http://localhost:1323",
      apiBase: process.env.API_SERVER || "http://164.163.236.62:8082",
      apiHome: process.env.API_HOME,
    },
  },
  axios: {
    baseURL: process.env.API_HOME,  // URL base da API do Django
    credentials: true  // Envia cookies automaticamente
  },
  vite: {
    resolve: {
      alias: {
        "@": fileURLToPath(new URL("./", import.meta.url)),
        "@provider": fileURLToPath(new URL("./provider", import.meta.url)),
      },
    },
    plugins: [lezer()],
    build: {
      outDir: "../data/frontend",
      emptyOutDir: true,
      chunkSizeWarningLimit: 2000,
    },
    // server: {
    //   proxy: {
    //     "/api": {
    //       target: "http://164.163.236.62:8082/",
    //       changeOrigin: true,
    //       headers: {
    //         "Remote-User": "alfred",
    //         "Remote-Name": "Alfred Pennyworth",
    //         "Remote-Email": "alfred@dccomics.example.com",
    //         "X-Logout-URL": "https://en.wikipedia.org/wiki/Alfred_Pennyworth",
    //       },
    //     },
    //   },
    // },
  },
});
